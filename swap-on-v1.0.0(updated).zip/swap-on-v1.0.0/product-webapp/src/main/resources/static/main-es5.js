(function () {
  function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

  function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }

  function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    "/ZnB":
    /*!****************************************************************!*\
      !*** ./src/app/chat-service-app/chat-service-app.component.ts ***!
      \****************************************************************/

    /*! exports provided: ChatServiceAppComponent */

    /***/
    function ZnB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatServiceAppComponent", function () {
        return ChatServiceAppComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _model_chat_chat_message_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../model/chat/chat-message.model */
      "ZguD");
      /* harmony import */


      var _model_chat_buyers_chat_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../model/chat/buyers-chat.model */
      "ais6");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _model_chat_message_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../model/chat/message.model */
      "/vyP");
      /* harmony import */


      var _service_chat_chat_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../service/chat/chat.service */
      "75vn");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");

      function ChatServiceAppComponent_div_24_div_5_Template(rf, ctx) {
        if (rf & 1) {
          var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 41);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 42);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ChatServiceAppComponent_div_24_div_5_Template_div_click_2_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);

            var user_r9 = ctx.$implicit;

            var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r10.getBuyerChat(user_r9.buyersChat.buyersEmailId);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var user_r9 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](user_r9.buyersChat.buyersEmailId);
        }
      }

      function ChatServiceAppComponent_div_24_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 35);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 36);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 37);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Chat List");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 38);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ChatServiceAppComponent_div_24_div_5_Template, 4, 1, "div", 39);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.buyersList);
        }
      }

      function ChatServiceAppComponent_div_28_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 43);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r2.displaySellerForBuyerScreen);
        }
      }

      function ChatServiceAppComponent_div_29_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 43);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r3.displayReceiver);
        }
      }

      function ChatServiceAppComponent_div_36_div_1_div_2_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 51);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](msg_r13.message);
        }
      }

      function ChatServiceAppComponent_div_36_div_1_div_4_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](msg_r13.message);
        }
      }

      function ChatServiceAppComponent_div_36_div_1_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 47);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ChatServiceAppComponent_div_36_div_1_div_2_Template, 2, 1, "div", 48);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 49);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ChatServiceAppComponent_div_36_div_1_div_4_Template, 2, 1, "div", 50);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r13 = ctx.$implicit;

          var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", msg_r13.messageSendBy + "@gmail.com" == ctx_r12.displaySender);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", msg_r13.messageSendBy + "@gmail.com" != ctx_r12.displaySender);
        }
      }

      function ChatServiceAppComponent_div_36_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 44);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ChatServiceAppComponent_div_36_div_1_Template, 5, 2, "div", 45);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r4.displayChat);
        }
      }

      function ChatServiceAppComponent_div_37_div_1_div_2_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 51);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](msg_r19.message);
        }
      }

      function ChatServiceAppComponent_div_37_div_1_div_4_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](msg_r19.message);
        }
      }

      function ChatServiceAppComponent_div_37_div_1_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 47);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ChatServiceAppComponent_div_37_div_1_div_2_Template, 2, 1, "div", 48);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 49);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ChatServiceAppComponent_div_37_div_1_div_4_Template, 2, 1, "div", 50);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var msg_r19 = ctx.$implicit;

          var ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", msg_r19.messageSendBy + "@gmail.com" == ctx_r18.buyer);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", msg_r19.messageSendBy + "@gmail.com" != ctx_r18.buyer);
        }
      }

      function ChatServiceAppComponent_div_37_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 44);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ChatServiceAppComponent_div_37_div_1_Template, 5, 2, "div", 45);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r5.sellerChat);
        }
      }

      function ChatServiceAppComponent_div_44_Template(rf, ctx) {
        if (rf & 1) {
          var _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 53);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon", 54);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ChatServiceAppComponent_div_44_Template_mat_icon_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r25);

            var ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r24.sendMessage();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "send");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function ChatServiceAppComponent_div_45_Template(rf, ctx) {
        if (rf & 1) {
          var _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 53);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon", 54);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ChatServiceAppComponent_div_45_Template_mat_icon_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r27);

            var ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r26.sendMessageBuyer();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "send");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var ChatServiceAppComponent = /*#__PURE__*/function () {
        function ChatServiceAppComponent(chatService) {
          _classCallCheck(this, ChatServiceAppComponent);

          this.chatService = chatService;
          this.Users = ["pavan", "srinivas", "debash", "priya", "akash", "aravind", "sahoo", "Karthik", "mudit", "1234"];
          this.sellerEmail = "pavan@gmail.com";
          this.buyerEmail = "saaho@gmail.com";
          this.productId = "102";
          this.MessageObj = new _model_chat_message_model__WEBPACK_IMPORTED_MODULE_4__["Message"]();
          this.msgSent = false;
          this.isChatClicked = false;
          this.sendChatMessage = new _model_chat_chat_message_model__WEBPACK_IMPORTED_MODULE_1__["ChatMessage"]();
          this.sendBuyersChat = new _model_chat_buyers_chat_model__WEBPACK_IMPORTED_MODULE_2__["BuyersChat"]();
          this.sendMsg = new _model_chat_message_model__WEBPACK_IMPORTED_MODULE_4__["Message"]();
          this.buyersList = [];
          this.chatMessageList = [];
        }

        _createClass(ChatServiceAppComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (localStorage.getItem("ROLE") == null) {
              localStorage.setItem("ROLE", "Seller");
            } //console.log("getting not existing one from localstorage gices "+localStorage.getItem("ARAVIND"))
            //localStorage.setItem("ROLE", "Buyer");
            //localStorage.setItem("buyerEmail", "swapper@gmail.com"); //login user's email
            //localStorage.setItem("PRODUCT_ID_FOR_BUYER_UI", "11111");
            //localStorage.setItem("SELLER_EMAIL_FOR_BUYER_CHAT_UI","swap-on@gmail.com");
            //console.log("role is " + localStorage.getItem("ROLE") + "  and email is " + localStorage.getItem("buyerEmail"));


            this.displaySellerForBuyerScreen = localStorage.getItem("SELLER_EMAIL_FOR_BUYER_CHAT_UI");
            this.role = localStorage.getItem("ROLE");
            this.inputMessage = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
              "message": new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])
            });

            if (localStorage.getItem("ROLE") == "Seller") {
              this.getBuyersList();
            }

            if (localStorage.getItem("ROLE") == "Buyer") {
              this.getSellerChat();
            }
          } // buyer varibles

        }, {
          key: "test",
          value: function test() {
            console.log("ngmodel is " + this.message);
          }
        }, {
          key: "getChat",
          value: function getChat(userName) {
            var _this = this;

            this.buyerEmailId = userName + '@gmail.com';
            this.chatService.getChatApi(this.productId, this.buyerEmailId).subscribe(function (tmp) {
              _this.chatFromBackend = tmp;
              _this.buyers = _this.chatFromBackend.buyersChat;
              console.log("no of buyers: " + _this.buyers.length);
              console.log("Backend data is : " + _this.chatFromBackend.buyersChat[0].buyersEmailId);
            });
            console.log("DEBUG:  username is " + userName);
          }
        }, {
          key: "getBuyersList",
          value: function getBuyersList() {
            var _this2 = this;

            console.log("Came into getBuyersList function !!!!!!!!!!!!!!!!!!!!!!");
            this.role = localStorage.getItem("ROLE");
            this.email = localStorage.getItem("buyerEmail");

            if (this.role == "Seller") {
              this.isSeller = true;
              this.isBuyer = false;
              this.chatService.getBuyers(this.email).subscribe(function (response) {
                _this2.buyersList = response;

                for (var i = 0; i < response.length; i++) {
                  console.log("buyer email: " + _this2.buyersList[i].buyersChat.buyersEmailId);
                }

                if (_this2.msgSent) {
                  _this2.msgSent = false;

                  _this2.getBuyerChat(_this2.displayReceiver);
                }
              });
            }
          }
        }, {
          key: "getBuyerChat",
          value: function getBuyerChat(buyerEmailFromUI) {
            this.isChatClicked = false;
            console.log("inside getBuyerChat() functino" + buyerEmailFromUI);
            this.displaySender = localStorage.getItem("buyerEmail");

            for (var i = 0; i < this.buyersList.length; i++) {
              if (this.buyersList[i].buyersChat.buyersEmailId == buyerEmailFromUI) {
                console.log("email " + this.buyersList[i].buyersChat.buyersEmailId);
                this.displayChat = this.buyersList[i].buyersChat.message;
                this.displayReceiver = this.buyersList[i].buyersChat.buyersEmailId;
                this.productId = this.buyersList[i].productId;
              }
            }
          }
        }, {
          key: "getSellerChat",
          value: function getSellerChat() {
            var _this3 = this;

            console.log("Inside getSellerChat Function");
            this.buyer = localStorage.getItem("buyerEmail");
            this.buyerProductId = localStorage.getItem("PRODUCT_ID_FOR_BUYER_UI");
            console.log("productId is " + this.buyerProductId + " buyer is " + this.buyer);
            this.chatService.getSpecificChat(this.buyer, this.buyerProductId).subscribe(function (buyerChat) {
              console.log("getSelerChat");
              _this3.sellerChat = buyerChat.buyersChat[0].message;
              _this3.seller = buyerChat.buyersChat[0].sellerEmailId;
            });
          }
        }, {
          key: "getProductsForBuyer",
          value: function getProductsForBuyer() {
            var _this4 = this;

            console.log("Came into Buyer function !!!!!!!!!!!!!!!!!!!!!!");
            this.role = localStorage.getItem("ROLE");
            this.email = localStorage.getItem("buyerEmail");

            if (this.role == "Buyer") {
              this.isSeller = false;
              this.isBuyer = true;
              this.chatService.getProductsOfBuyer(this.email).subscribe(function (response) {
                _this4.productsList = response;

                for (var i = 0; i < response.length; i++) {
                  console.log("buyer email: " + _this4.productsList[i].productId);
                }
              });
            }
          }
        }, {
          key: "sendMessage",
          value: function sendMessage() {
            var _this5 = this;

            var currentDate = new Date();
            var timestamp = currentDate.getTime();
            console.log("before setting message " + this.inputMessage.value.message);
            this.sendMsg.message = this.inputMessage.value.message;
            this.inputMessage.reset();
            console.log("inside sendmessage after setting message");
            this.sendMsg.messageSendBy = this.displaySender.split("@")[0];
            this.sendMsg.messageSendOn = timestamp;
            this.sendBuyersChat.buyersEmailId = this.displayReceiver;
            this.sendBuyersChat.message = [this.sendMsg];
            this.sendChatMessage.buyersChat = [this.sendBuyersChat];
            this.sendChatMessage.sellerEmail = this.displaySender;
            this.sendChatMessage.productId = this.productId;
            this.chatService.sendMessage(this.sendChatMessage).subscribe(function (tmp) {
              console.log("SendMessage function - " + tmp[0].buyersEmailId); //this.getBuyerChat(this.displayReceiver)

              _this5.msgSent = true;

              _this5.getBuyersList();
            });
            location.reload();
          }
        }, {
          key: "sendMessageBuyer",
          value: function sendMessageBuyer() {
            var _this6 = this;

            var currentDate = new Date();
            var timestamp = currentDate.getTime();
            console.log("before setting message " + this.inputMessage.value.message);
            this.sendMsg.message = this.inputMessage.value.message;
            this.inputMessage.reset();
            console.log("inside sendmessage after setting message");
            this.sendMsg.messageSendBy = this.buyer.split("@")[0];
            this.sendMsg.messageSendOn = timestamp;
            this.sendBuyersChat.buyersEmailId = this.buyer;
            this.sendBuyersChat.message = [this.sendMsg];
            this.sendChatMessage.buyersChat = [this.sendBuyersChat];
            this.sendChatMessage.sellerEmail = this.displaySellerForBuyerScreen;
            this.sendChatMessage.productId = this.buyerProductId;
            this.chatService.sendMessage(this.sendChatMessage).subscribe(function (tmp) {
              //console.log("SendMessage function - "+tmp[0].buyersEmailId)
              //this.getBuyerChat(this.displayReceiver)
              _this6.getSellerChat();
            });
            location.reload();
          }
        }]);

        return ChatServiceAppComponent;
      }();

      ChatServiceAppComponent.ɵfac = function ChatServiceAppComponent_Factory(t) {
        return new (t || ChatServiceAppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_chat_chat_service__WEBPACK_IMPORTED_MODULE_5__["ChatService"]));
      };

      ChatServiceAppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: ChatServiceAppComponent,
        selectors: [["app-chat-service-app"]],
        decls: 49,
        vars: 9,
        consts: [[1, "toolbar"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], [1, "Title"], [1, "spacer"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], [1, "menu"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/profile"], ["mat-menu-item", "", "routerLink", "/myProducts"], ["mat-menu-item", "", "routerLink", "/showProduct"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/login"], ["fxLayout", "column"], ["fxFlex", "0vh"], ["fxFlex", "88vh", "fxLayout", "row"], ["style", "background-color: chartreuse", "fxFlex", "27%", "fxLayout", "column", 4, "ngIf"], ["fxFlex", "100%", "fxLayout", "column", 2, "background-color", "chocolate"], ["fxFlex", "13%", "fxlayout", "row", "fxLayoutAlign", "center center", 1, "chathead", 2, "background-color", "#383A48"], ["fxFlex", "30%", "fxLayout", "row"], ["class", "chat-person", 4, "ngIf"], ["fxFlex", "60%"], ["mat-fab", "", "routerLink", "/videoService", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["fxFlex", "77.7%", "fxFlex", "row"], ["fxLayout", "column", "fxLayoutAlign", "end none", "fxFill", "", 1, "ChatBody", 2, "background-color", "#878B9B"], ["class", "message-item-container-send", "style", "display:block", 4, "ngIf"], ["fxFlex", "8.5%", "fxLayout", "row", 2, "background-color", "rgb(169, 178, 184)"], ["fxFlex", "95%", "fxLayout", "row", 3, "formGroup"], ["fxFlex", "0.3", 2, "background-color", "#878B9B"], ["type", "text", "placeholder", "enter a message", "fxFlex", "99.4%", "formControlName", "message", "matInput", ""], ["fxFlex", "5%", "fxLayout", "row"], ["fxLayoutAlign", "center center", "fxFlex", "91.2", 4, "ngIf"], ["fxFlex", "9", 2, "background-color", "#878B9B"], ["fxFlex", "0.7", 2, "background-color", "#878B9B"], ["fxFlex", "2vh", 2, "background-color", "#555353"], ["fxFlex", "27%", "fxLayout", "column", 2, "background-color", "chartreuse"], ["fxFlex", "13%", "fxLayoutAlign", "center center", 1, "chat-header", 2, "background-color", "#383A48"], [1, "chatlist"], ["fxFlex", "87%", 2, "background-color", "#383A48"], ["class", "chatname", "fxlayout", "column", "fxLayoutAlign", "space-around center", 4, "ngFor", "ngForOf"], ["fxlayout", "column", "fxLayoutAlign", "space-around center", 1, "chatname"], ["fxFlex", "5%"], ["fxFlex", "95%", 2, "margin", "2%", 3, "click"], [1, "chat-person"], [1, "message-item-container-send", 2, "display", "block"], ["fxLayout", "column", "class", "padding5px", 4, "ngFor", "ngForOf"], ["fxLayout", "column", 1, "padding5px"], ["fxLayout", "row", "fxLayoutAlign", "end end"], ["class", "message-content-send padding5px", 4, "ngIf"], ["fxLayout", "row", "fxLayoutAlign", "start start"], ["class", "message-content-receive padding5px", 4, "ngIf"], [1, "message-content-send", "padding5px"], [1, "message-content-receive", "padding5px"], ["fxLayoutAlign", "center center", "fxFlex", "91.2"], [3, "click"]],
        template: function ChatServiceAppComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-icon", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-menu", 6, 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "My Profile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "My Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "All Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "button", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, ChatServiceAppComponent_div_24_Template, 6, 1, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](28, ChatServiceAppComponent_div_28_Template, 2, 1, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, ChatServiceAppComponent_div_29_Template, 2, 1, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "videocam");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](36, ChatServiceAppComponent_div_36_Template, 2, 1, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](37, ChatServiceAppComponent_div_37_Template, 2, 1, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "input", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](44, ChatServiceAppComponent_div_44_Template, 3, 0, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](45, ChatServiceAppComponent_div_45_Template, 3, 0, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](48, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Buyer");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Buyer");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.inputMessage);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.role == "Buyer");
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterLink"], _angular_material_button__WEBPACK_IMPORTED_MODULE_8__["MatButton"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuTrigger"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__["MatIcon"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuItem"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_11__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_11__["DefaultFlexDirective"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgIf"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_11__["DefaultLayoutAlignDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_11__["FlexFillDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgForOf"]],
        styles: [".chat-page[_ngcontent-%COMP%]{\r\n    margin:0%;\r\n    padding-right:0%;\r\n    height:100%;\r\n    width:100%;\r\n    background:rgb(255,255,255);\r\n    overflow:hidden;\r\n    display:none;\r\n}\r\n.chat-group-container1[_ngcontent-%COMP%]{\r\n    background-color:rgb(255,255,255);\r\n    height:100%;\r\n}\r\n.chat-head[_ngcontent-%COMP%]{\r\n    height: 10%;\r\n    position: relative;\r\n    margin-right: 10px;\r\n    color:solid blue;\r\n}\r\n.vertical-center[_ngcontent-%COMP%] {\r\n    color: white;\r\n    font-size: 1.5vw;\r\n    font-family: sans-serif;\r\n    margin: 0;\r\n    position: absolute;\r\n    top: 50%;\r\n    transform: translateY(-50%);\r\n    padding: 4%;\r\n  }\r\n.chat-list[_ngcontent-%COMP%]{\r\n    height:90%;\r\n    background-color:rgb(225,255,225);\r\n    max-height:100%;\r\n    overflow-y:scroll;\r\n  }\r\n.chat-name[_ngcontent-%COMP%]{\r\n    background:rgb(255, 255, 255);\r\n    position:relative;\r\n    height:60px;\r\n  }\r\n.chatClicked[_ngcontent-%COMP%]{\r\n    background:rgb(255, 251, 251);\r\n    position:relative;\r\n    height:60px;\r\n  }\r\n.name[_ngcontent-%COMP%]{\r\n    color:black;\r\n    font-size: 1vw;\r\n    font-family: sans-serif;\r\n    margin: 0;\r\n    padding-left:4%;\r\n    position: absolute;\r\n    top: 50%;\r\n    transform: translateY(-50%); \r\n  }\r\n.chat-group-container2[_ngcontent-%COMP%]{\r\n    background-color: rgb(255, 255, 255);\r\n    height: 100%;\r\n}\r\n.chat70[_ngcontent-%COMP%]{\r\n    height:100%\r\n}\r\n.chat-box[_ngcontent-%COMP%]{\r\n    height:80%;\r\n    background-color: rgb(255,255,255);\r\n    max-height: 100%;\r\n    overflow-y:scroll;\r\n    border-color: black;\r\n}\r\n.user-name[_ngcontent-%COMP%]{\r\n    background: rgb(255,255,255);\r\n    position:relative;\r\n    height:60px;\r\n}\r\n.message-item-container-send[_ngcontent-%COMP%] {\r\n    display: flex;\r\n   \r\n    flex-direction: row-reverse;\r\n    \r\n  }\r\n.padding5px[_ngcontent-%COMP%] {\r\n    padding: 5px;\r\n  }\r\n.message-content-send[_ngcontent-%COMP%]{\r\n\r\n    background-color: rgb(210, 198, 252);\r\n    border-radius: 4px;\r\n    display:inline;\r\n    flex-direction: row;\r\n    font-size: larger;\r\n  }\r\n.message-content-receive[_ngcontent-%COMP%]{\r\n    background-color: rgb(164, 250, 188);\r\n    border-radius: 4px;\r\n    display:flex;\r\n    flex-direction: row;\r\n    font-size: larger;\r\n  }\r\n.message-item-container-receive[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    \r\n    flex-direction: row;\r\n  \r\n  }\r\n.chat-bottom-bar[_ngcontent-%COMP%]{\r\n    height: 15%;\r\n    padding: 1%;\r\n    background-color: cadetblue;\r\n\r\n}\r\n.message-text[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    margin-left: 2%;\r\n    position: relative;\r\n}\r\n.message-send-btn[_ngcontent-%COMP%]{\r\n    background-color: cadetblue;\r\n    margin-right: 2%;\r\n    position: relative;\r\n}\r\n.send-btn[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n    color: blue;\r\n}\r\n.message-input[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    width: 100%;\r\n    padding: 1%;\r\n    border: 0px solid gray;\r\n    \r\n  }\r\n.message-input[_ngcontent-%COMP%]:focus {\r\n    outline:none;\r\n}\r\n\r\ndiv[_ngcontent-%COMP%]   [_ngcontent-%COMP%]::-webkit-scrollbar {\r\n    width: 10px;\r\n  \r\n}\r\n\r\ndiv[_ngcontent-%COMP%]   [_ngcontent-%COMP%]::-webkit-scrollbar-track {\r\n    background: #ffffff; \r\n  }\r\n\r\ndiv[_ngcontent-%COMP%]   [_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\r\n    background: rgb(216, 216, 218); \r\n  }\r\n\r\ndiv[_ngcontent-%COMP%]   [_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover {\r\n    background: #555; \r\n  }\r\n.chat-header[_ngcontent-%COMP%] {\r\n    border-style:ridge;\r\n    font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;\r\n    background-color: cornsilk;\r\n    font-size: x-large;\r\n    color: aquamarine;\r\n    \r\n  }\r\n.chatlist[_ngcontent-%COMP%] {\r\n    font-size: x-large;\r\n  }\r\n.ChatBody[_ngcontent-%COMP%]{\r\n    border: #555;\r\n  }\r\n.chatname[_ngcontent-%COMP%]{\r\n    border-style:ridge;\r\n    font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;\r\n    font-size: large;\r\n    color: rgb(243, 248, 248);\r\n    \r\n\r\n  }\r\n.chathead[_ngcontent-%COMP%] {\r\n    border-style:ridge;\r\n    color: rgb(238, 228, 238);\r\n    font-size: x-large;\r\n  }\r\n.chat-person[_ngcontent-%COMP%] {\r\n    color:rgb(210, 198, 252);\r\n    font-size: x-large;\r\n  }\r\np[_ngcontent-%COMP%]{\r\n    color: bisque;\r\n  }\r\n.chat-box-new[_ngcontent-%COMP%] {\r\n    \r\n    background-color: rgb(255,255,255);\r\n    min-height: 77.7%;\r\n    max-height: 77.7%;\r\n    overflow-y: scroll;\r\n    fill: yellowgreen;\r\n    border-color: black;\r\n}\r\n.spacer[_ngcontent-%COMP%]{\r\n  flex: 1 1 auto;\r\n}\r\n.mat-toolbar-single-row[_ngcontent-%COMP%] {\r\n  height: 76px;\r\n  padding: 0;\r\n}\r\n.mat-toolbar.mat-primary[_ngcontent-%COMP%]{\r\n  background-color: #2e465e;\r\n}\r\n.mat-form-field-appearance-legacy[_ngcontent-%COMP%]   .mat-form-field-wrapper[_ngcontent-%COMP%] {\r\n  padding-bottom: 1.2em;\r\n}\r\n.categ[_ngcontent-%COMP%]{\r\n  margin-left: 10px;\r\n}\r\n.mat-form-field[_ngcontent-%COMP%] {\r\n  font-size: medium;\r\n  \r\n}\r\n.icon[_ngcontent-%COMP%]{\r\n  height:25px;\r\n  display:inline-block;\r\n  font-size: 43px;\r\n  margin-bottom: 20px;\r\n  margin-right: 25px;\r\n  margin-left:-50px;\r\n}\r\n.mat-toolbar[_ngcontent-%COMP%]{\r\n  background-color: #383a48;\r\n  color:#ffffff;\r\n}\r\n.Title[_ngcontent-%COMP%] {\r\n  \r\n  font-size: 150%;\r\n  margin-right: 20px;\r\n  margin-left: 10px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQtc2VydmljZS1hcHAuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFNBQVM7SUFDVCxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLFVBQVU7SUFDViwyQkFBMkI7SUFDM0IsZUFBZTtJQUNmLFlBQVk7QUFDaEI7QUFDQTtJQUNJLGlDQUFpQztJQUNqQyxXQUFXO0FBQ2Y7QUFDQTtJQUNJLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksWUFBWTtJQUNaLGdCQUFnQjtJQUNoQix1QkFBdUI7SUFDdkIsU0FBUztJQUNULGtCQUFrQjtJQUNsQixRQUFRO0lBRVIsMkJBQTJCO0lBQzNCLFdBQVc7RUFDYjtBQUNBO0lBQ0UsVUFBVTtJQUNWLGlDQUFpQztJQUNqQyxlQUFlO0lBQ2YsaUJBQWlCO0VBQ25CO0FBQ0E7SUFDRSw2QkFBNkI7SUFDN0IsaUJBQWlCO0lBQ2pCLFdBQVc7RUFDYjtBQUNBO0lBQ0UsNkJBQTZCO0lBQzdCLGlCQUFpQjtJQUNqQixXQUFXO0VBQ2I7QUFDQTtJQUNFLFdBQVc7SUFDWCxjQUFjO0lBQ2QsdUJBQXVCO0lBQ3ZCLFNBQVM7SUFDVCxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLFFBQVE7SUFFUiwyQkFBMkI7RUFDN0I7QUFDQTtJQUNFLG9DQUFvQztJQUNwQyxZQUFZO0FBQ2hCO0FBQ0E7SUFDSTtBQUNKO0FBQ0E7SUFDSSxVQUFVO0lBQ1Ysa0NBQWtDO0lBQ2xDLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsbUJBQW1CO0FBQ3ZCO0FBQ0E7SUFDSSw0QkFBNEI7SUFDNUIsaUJBQWlCO0lBQ2pCLFdBQVc7QUFDZjtBQUNBO0lBQ0ksYUFBYTs7SUFFYiwyQkFBMkI7O0VBRTdCO0FBQ0E7SUFDRSxZQUFZO0VBQ2Q7QUFFQTs7SUFFRSxvQ0FBb0M7SUFDcEMsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxtQkFBbUI7SUFDbkIsaUJBQWlCO0VBQ25CO0FBQ0E7SUFDRSxvQ0FBb0M7SUFDcEMsa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsaUJBQWlCO0VBQ25CO0FBQ0E7SUFDRSxhQUFhOztJQUViLG1CQUFtQjs7RUFFckI7QUFFQTtJQUNFLFdBQVc7SUFDWCxXQUFXO0lBQ1gsMkJBQTJCOztBQUUvQjtBQUNBO0lBQ0ksV0FBVztJQUNYLGVBQWU7SUFDZixrQkFBa0I7QUFDdEI7QUFFQTtJQUNJLDJCQUEyQjtJQUMzQixnQkFBZ0I7SUFDaEIsa0JBQWtCO0FBQ3RCO0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsUUFBUTtJQUNSLFNBQVM7SUFDVCxnQ0FBZ0M7SUFDaEMsV0FBVztBQUNmO0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsTUFBTTtJQUNOLE9BQU87SUFDUCxRQUFRO0lBQ1IsU0FBUztJQUNULFdBQVc7SUFDWCxXQUFXO0lBQ1gsc0JBQXNCOztFQUV4QjtBQUNBO0lBQ0UsWUFBWTtBQUNoQjtBQUVDLFVBQVU7QUFDVjtJQUNHLFdBQVc7RUFDYixpQkFBaUI7QUFDbkI7QUFHQyxVQUFVO0FBQ1Y7SUFDRyxtQkFBbUI7RUFDckI7QUFFQSxXQUFXO0FBQ1g7SUFDRSw4QkFBOEI7RUFDaEM7QUFFQSxvQkFBb0I7QUFDcEI7SUFDRSxnQkFBZ0I7RUFDbEI7QUFHQTtJQUNFLGtCQUFrQjtJQUNsQixxRUFBcUU7SUFDckUsMEJBQTBCO0lBQzFCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsZ0NBQWdDO0VBQ2xDO0FBRUE7SUFDRSxrQkFBa0I7RUFDcEI7QUFFQTtJQUNFLFlBQVk7RUFDZDtBQUNDO0lBQ0Msa0JBQWtCO0lBQ2xCLHFFQUFxRTtJQUNyRSxnQkFBZ0I7SUFDaEIseUJBQXlCOzs7RUFHM0I7QUFHQTtJQUNFLGtCQUFrQjtJQUNsQix5QkFBeUI7SUFDekIsa0JBQWtCO0VBQ3BCO0FBRUE7SUFDRSx3QkFBd0I7SUFDeEIsa0JBQWtCO0VBQ3BCO0FBRUE7SUFDRSxhQUFhO0VBQ2Y7QUFFQTs7SUFFRSxrQ0FBa0M7SUFDbEMsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLG1CQUFtQjtBQUN2QjtBQUVBO0VBQ0UsY0FBYztBQUNoQjtBQUdBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7QUFDWjtBQUNBO0VBQ0UseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSxxQkFBcUI7QUFDdkI7QUFDQTtFQUNFLGlCQUFpQjtBQUNuQjtBQUVBO0VBQ0UsaUJBQWlCOztBQUVuQjtBQUNBO0VBQ0UsV0FBVztFQUNYLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLHlCQUF5QjtFQUN6QixhQUFhO0FBQ2Y7QUFFQTtFQUNFLDhDQUE4QztFQUM5QyxlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGlCQUFpQjtBQUNuQiIsImZpbGUiOiJjaGF0LXNlcnZpY2UtYXBwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2hhdC1wYWdle1xyXG4gICAgbWFyZ2luOjAlO1xyXG4gICAgcGFkZGluZy1yaWdodDowJTtcclxuICAgIGhlaWdodDoxMDAlO1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIGJhY2tncm91bmQ6cmdiKDI1NSwyNTUsMjU1KTtcclxuICAgIG92ZXJmbG93OmhpZGRlbjtcclxuICAgIGRpc3BsYXk6bm9uZTtcclxufVxyXG4uY2hhdC1ncm91cC1jb250YWluZXIxe1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjpyZ2IoMjU1LDI1NSwyNTUpO1xyXG4gICAgaGVpZ2h0OjEwMCU7XHJcbn1cclxuLmNoYXQtaGVhZHtcclxuICAgIGhlaWdodDogMTAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgY29sb3I6c29saWQgYmx1ZTtcclxufVxyXG4udmVydGljYWwtY2VudGVyIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMS41dnc7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxuICAgIHBhZGRpbmc6IDQlO1xyXG4gIH1cclxuICAuY2hhdC1saXN0e1xyXG4gICAgaGVpZ2h0OjkwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDIyNSwyNTUsMjI1KTtcclxuICAgIG1heC1oZWlnaHQ6MTAwJTtcclxuICAgIG92ZXJmbG93LXk6c2Nyb2xsO1xyXG4gIH1cclxuICAuY2hhdC1uYW1le1xyXG4gICAgYmFja2dyb3VuZDpyZ2IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgIGhlaWdodDo2MHB4O1xyXG4gIH1cclxuICAuY2hhdENsaWNrZWR7XHJcbiAgICBiYWNrZ3JvdW5kOnJnYigyNTUsIDI1MSwgMjUxKTtcclxuICAgIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG4gICAgaGVpZ2h0OjYwcHg7XHJcbiAgfVxyXG4gIC5uYW1le1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbiAgICBmb250LXNpemU6IDF2dztcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZy1sZWZ0OjQlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpOyBcclxuICB9XHJcbiAgLmNoYXQtZ3JvdXAtY29udGFpbmVyMntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG4uY2hhdDcwe1xyXG4gICAgaGVpZ2h0OjEwMCVcclxufVxyXG4uY2hhdC1ib3h7XHJcbiAgICBoZWlnaHQ6ODAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwyNTUsMjU1KTtcclxuICAgIG1heC1oZWlnaHQ6IDEwMCU7XHJcbiAgICBvdmVyZmxvdy15OnNjcm9sbDtcclxuICAgIGJvcmRlci1jb2xvcjogYmxhY2s7XHJcbn1cclxuLnVzZXItbmFtZXtcclxuICAgIGJhY2tncm91bmQ6IHJnYigyNTUsMjU1LDI1NSk7XHJcbiAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgIGhlaWdodDo2MHB4O1xyXG59XHJcbi5tZXNzYWdlLWl0ZW0tY29udGFpbmVyLXNlbmQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgXHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93LXJldmVyc2U7XHJcbiAgICBcclxuICB9XHJcbiAgLnBhZGRpbmc1cHgge1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gIH1cclxuXHJcbiAgLm1lc3NhZ2UtY29udGVudC1zZW5ke1xyXG5cclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMTAsIDE5OCwgMjUyKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGRpc3BsYXk6aW5saW5lO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgIGZvbnQtc2l6ZTogbGFyZ2VyO1xyXG4gIH1cclxuICAubWVzc2FnZS1jb250ZW50LXJlY2VpdmV7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTY0LCAyNTAsIDE4OCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgZm9udC1zaXplOiBsYXJnZXI7XHJcbiAgfVxyXG4gIC5tZXNzYWdlLWl0ZW0tY29udGFpbmVyLXJlY2VpdmUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIFxyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICBcclxuICB9XHJcblxyXG4gIC5jaGF0LWJvdHRvbS1iYXJ7XHJcbiAgICBoZWlnaHQ6IDE1JTtcclxuICAgIHBhZGRpbmc6IDElO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogY2FkZXRibHVlO1xyXG5cclxufVxyXG4ubWVzc2FnZS10ZXh0e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMiU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5tZXNzYWdlLXNlbmQtYnRue1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogY2FkZXRibHVlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAyJTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnNlbmQtYnRue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuICAgIGNvbG9yOiBibHVlO1xyXG59XHJcblxyXG4ubWVzc2FnZS1pbnB1dHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMSU7XHJcbiAgICBib3JkZXI6IDBweCBzb2xpZCBncmF5O1xyXG4gICAgXHJcbiAgfVxyXG4gIC5tZXNzYWdlLWlucHV0OmZvY3VzIHtcclxuICAgIG91dGxpbmU6bm9uZTtcclxufVxyXG5cclxuIC8qIHdpZHRoICovXHJcbiBkaXYgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICB3aWR0aDogMTBweDtcclxuICAvKiB3aWR0aDogMTBweDsgKi9cclxufVxyXG5cclxuXHJcbiAvKiBUcmFjayAqL1xyXG4gZGl2IDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZjsgXHJcbiAgfVxyXG4gICBcclxuICAvKiBIYW5kbGUgKi9cclxuICBkaXYgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2IoMjE2LCAyMTYsIDIxOCk7IFxyXG4gIH1cclxuICBcclxuICAvKiBIYW5kbGUgb24gaG92ZXIgKi9cclxuICBkaXYgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNTU1OyBcclxuICB9XHJcblxyXG5cclxuICAuY2hhdC1oZWFkZXIge1xyXG4gICAgYm9yZGVyLXN0eWxlOnJpZGdlO1xyXG4gICAgZm9udC1mYW1pbHk6Q2FtYnJpYSwgQ29jaGluLCBHZW9yZ2lhLCBUaW1lcywgJ1RpbWVzIE5ldyBSb21hbicsIHNlcmlmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogY29ybnNpbGs7XHJcbiAgICBmb250LXNpemU6IHgtbGFyZ2U7XHJcbiAgICBjb2xvcjogYXF1YW1hcmluZTtcclxuICAgIC8qIGJvcmRlci1yYWRpdXM6IDIlIDIlIDIlIDIlOyAqL1xyXG4gIH1cclxuXHJcbiAgLmNoYXRsaXN0IHtcclxuICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxuICB9XHJcblxyXG4gIC5DaGF0Qm9keXtcclxuICAgIGJvcmRlcjogIzU1NTtcclxuICB9XHJcbiAgIC5jaGF0bmFtZXtcclxuICAgIGJvcmRlci1zdHlsZTpyaWRnZTtcclxuICAgIGZvbnQtZmFtaWx5OkNhbWJyaWEsIENvY2hpbiwgR2VvcmdpYSwgVGltZXMsICdUaW1lcyBOZXcgUm9tYW4nLCBzZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogbGFyZ2U7XHJcbiAgICBjb2xvcjogcmdiKDI0MywgMjQ4LCAyNDgpO1xyXG4gICAgXHJcblxyXG4gIH1cclxuIFxyXG5cclxuICAuY2hhdGhlYWQge1xyXG4gICAgYm9yZGVyLXN0eWxlOnJpZGdlO1xyXG4gICAgY29sb3I6IHJnYigyMzgsIDIyOCwgMjM4KTtcclxuICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxuICB9XHJcbiAgXHJcbiAgLmNoYXQtcGVyc29uIHtcclxuICAgIGNvbG9yOnJnYigyMTAsIDE5OCwgMjUyKTtcclxuICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxuICB9XHJcblxyXG4gIHB7XHJcbiAgICBjb2xvcjogYmlzcXVlO1xyXG4gIH1cclxuXHJcbiAgLmNoYXQtYm94LW5ldyB7XHJcbiAgICBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsMjU1LDI1NSk7XHJcbiAgICBtaW4taGVpZ2h0OiA3Ny43JTtcclxuICAgIG1heC1oZWlnaHQ6IDc3LjclO1xyXG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xyXG4gICAgZmlsbDogeWVsbG93Z3JlZW47XHJcbiAgICBib3JkZXItY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG4uc3BhY2Vye1xyXG4gIGZsZXg6IDEgMSBhdXRvO1xyXG59XHJcblxyXG5cclxuLm1hdC10b29sYmFyLXNpbmdsZS1yb3cge1xyXG4gIGhlaWdodDogNzZweDtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcbi5tYXQtdG9vbGJhci5tYXQtcHJpbWFyeXtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmU0NjVlO1xyXG59XHJcbi5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLWxlZ2FjeSAubWF0LWZvcm0tZmllbGQtd3JhcHBlciB7XHJcbiAgcGFkZGluZy1ib3R0b206IDEuMmVtO1xyXG59XHJcbi5jYXRlZ3tcclxuICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLm1hdC1mb3JtLWZpZWxkIHtcclxuICBmb250LXNpemU6IG1lZGl1bTtcclxuICBcclxufVxyXG4uaWNvbntcclxuICBoZWlnaHQ6MjVweDtcclxuICBkaXNwbGF5OmlubGluZS1ibG9jaztcclxuICBmb250LXNpemU6IDQzcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDI1cHg7XHJcbiAgbWFyZ2luLWxlZnQ6LTUwcHg7XHJcbn1cclxuLm1hdC10b29sYmFye1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMzODNhNDg7XHJcbiAgY29sb3I6I2ZmZmZmZjtcclxufVxyXG5cclxuLlRpdGxlIHtcclxuICAvKiBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlOyAqL1xyXG4gIGZvbnQtc2l6ZTogMTUwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbn0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ChatServiceAppComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-chat-service-app',
            templateUrl: './chat-service-app.component.html',
            styleUrls: ['./chat-service-app.component.scss']
          }]
        }], function () {
          return [{
            type: _service_chat_chat_service__WEBPACK_IMPORTED_MODULE_5__["ChatService"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "/vyP":
    /*!*********************************************!*\
      !*** ./src/app/model/chat/message.model.ts ***!
      \*********************************************/

    /*! exports provided: Message */

    /***/
    function vyP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Message", function () {
        return Message;
      });

      var Message = /*#__PURE__*/_createClass(function Message() {
        _classCallCheck(this, Message);
      });
      /***/

    },

    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! C:\Users\acer\Desktop\New folder (2)\swap-on\product-webapp\webapp\src\main.ts */
      "zUnb");
      /***/
    },

    /***/
    "3mgE":
    /*!****************************************!*\
      !*** ./src/app/service/app.service.ts ***!
      \****************************************/

    /*! exports provided: AppService */

    /***/
    function mgE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppService", function () {
        return AppService;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");

      var AppService = /*#__PURE__*/function () {
        function AppService(http) {
          _classCallCheck(this, AppService);

          this.http = http;
        } //  bashUrl : "https://swapon.stackroute.io" ;
        //  bashUrl : "http://localhost:8080" ;
        // registerApi(regData: UserRegistration) {
        //   return this.http.post<any>(
        //     this.bashUrl+"/authentication-service/api/v1/register",
        //     regData
        //   );
        // }
        // loginApi(loginData: User) {
        //   return this.http.post<any>(
        //     "http://localhost:8080/authentication-service/api/v1/login",
        //     loginData
        //   );
        // }
        // getbyEmailApi(emailId) {
        //   return this.http.get(
        //     "http://localhost:8080/authentication-serviceapi/v1/product/sellerEmail/" +
        //       emailId
        //   );
        // }
        // postProduct(data) {
        //   return this.http.post(
        //     "http://localhost:8080/product-service/api/v1/addproduct",
        //     data
        //   );
        // }
        // getproducts() {
        //   return this.http.get<any>(
        //     "http://localhost:8080/product-service/api/v1/product"
        //   );
        // }
        // getDetail() {
        //   return this.http.get(
        //     "http://localhost:8080/product-service/api/v1/product/productId/" +
        //       localStorage.getItem("productId")
        //   );
        // }
        // getMyProducts() {
        //   return this.http.get<any>(
        //     "http://localhost:8080/product-service/api/v1/product/sellerEmail/" +
        //       localStorage.getItem("buyerEmail")
        //   );
        // }
        // deleteMyProduct(productId: any) {
        //   return this.http.delete<any>(
        //     "http://localhost:8080/product-service/api/v1/delete/" + productId
        //   );
        // }
        // getByFilter() {
        //   return this.http.get<any>(
        //     "http://localhost:8080/recommendation-service/api/v1/productByStateAndCategory/" +
        //       localStorage.getItem("sellerState") +
        //       "/" +
        //       localStorage.getItem("category")
        //   );
        // }
        // getAllProduct() {
        //   return this.http.get(
        //     "http://localhost:8080/recommendation-service/api/v1/productByCategory/" +
        //       localStorage.getItem("catagory")
        //   );
        // }
        // getByCategory(category) {
        //   return this.http.get(
        //     "http://localhost:8080/product-serviceapi/v1/productByCategory/" +
        //       category
        //   );
        // }
        // getByProductCategory() {
        //   return this.http.get(
        //     "http://localhost:8080/product-service/api/v1/productByCategory/" +
        //       localStorage.getItem("category")
        //   );
        // }


        _createClass(AppService, [{
          key: "registerApi",
          value: function registerApi(regData) {
            return this.http.post("https://swapon.stackroute.io/authentication-service/api/v1/register", regData);
          }
        }, {
          key: "loginApi",
          value: function loginApi(loginData) {
            return this.http.post("https://swapon.stackroute.io/authentication-service/api/v1/login", loginData);
          }
        }, {
          key: "getbyEmailApi",
          value: function getbyEmailApi(emailId) {
            return this.http.get("https://swapon.stackroute.io/authentication-serviceapi/v1/product/sellerEmail/" + emailId);
          }
        }, {
          key: "postProduct",
          value: function postProduct(data) {
            return this.http.post("https://swapon.stackroute.io/product-service/api/v1/addproduct", data);
          }
        }, {
          key: "getproducts",
          value: function getproducts() {
            return this.http.get("https://swapon.stackroute.io/product-service/api/v1/product");
          }
        }, {
          key: "getDetail",
          value: function getDetail() {
            return this.http.get("https://swapon.stackroute.io/product-service/api/v1/product/productId/" + localStorage.getItem("productId"));
          }
        }, {
          key: "getMyProducts",
          value: function getMyProducts() {
            return this.http.get("https://swapon.stackroute.io/product-service/api/v1/product/sellerEmail/" + localStorage.getItem("buyerEmail"));
          }
        }, {
          key: "deleteMyProduct",
          value: function deleteMyProduct(productId) {
            return this.http["delete"]("https://swapon.stackroute.io/product-service/api/v1/delete/" + productId);
          }
        }, {
          key: "getByFilter",
          value: function getByFilter() {
            return this.http.get("https://swapon.stackroute.io/recommendation-service/api/v1/productByStateAndCategory/" + localStorage.getItem("sellerState") + "/" + localStorage.getItem("category"));
          }
        }, {
          key: "getAllProduct",
          value: function getAllProduct() {
            return this.http.get("https://swapon.stackroute.io/recommendation-service/api/v1/productByCategory/" + localStorage.getItem("catagory"));
          }
        }, {
          key: "getByCategory",
          value: function getByCategory(category) {
            return this.http.get("https://swapon.stackroute.io/product-serviceapi/v1/productByCategory/" + category);
          }
        }, {
          key: "getByProductCategory",
          value: function getByProductCategory() {
            return this.http.get("https://swapon.stackroute.io/product-service/api/v1/productByCategory/" + localStorage.getItem("category"));
          }
        }]);

        return AppService;
      }();

      AppService.ɵfac = function AppService_Factory(t) {
        return new (t || AppService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]));
      };

      AppService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
        token: AppService,
        factory: AppService.ɵfac,
        providedIn: "root"
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppService, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
          args: [{
            providedIn: "root"
          }]
        }], function () {
          return [{
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "75vn":
    /*!**********************************************!*\
      !*** ./src/app/service/chat/chat.service.ts ***!
      \**********************************************/

    /*! exports provided: ChatService */

    /***/
    function vn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatService", function () {
        return ChatService;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");

      var ChatService = /*#__PURE__*/function () {
        function ChatService(http) {
          _classCallCheck(this, ChatService);

          this.http = http;
          this.apiBaseurl = "https://swapon.stackroute.io/chat-service/chats/";
        } // apiBaseurl = "http://localhost:8084/chats/"


        _createClass(ChatService, [{
          key: "getChatApi",
          value: function getChatApi(productId, sellerEmail) {
            return this.http.get(this.apiBaseurl + 'message/' + productId + "/" + sellerEmail);
          }
        }, {
          key: "getBuyers",
          value: function getBuyers(sellerEmail) {
            return this.http.get(this.apiBaseurl + 'seller/' + sellerEmail);
          }
        }, {
          key: "getProductsOfBuyer",
          value: function getProductsOfBuyer(buyerEmail) {
            return this.http.get(this.apiBaseurl + "buyer/" + buyerEmail);
          }
        }, {
          key: "getSpecificChat",
          value: function getSpecificChat(buyerEmail, productId) {
            console.log("sending http request to back-end with URL " + this.apiBaseurl + buyerEmail + '/' + productId);
            return this.http.get(this.apiBaseurl + buyerEmail + '/' + productId);
          }
        }, {
          key: "sendMessage",
          value: function sendMessage(chatMessage) {
            return this.http.post(this.apiBaseurl + "message", chatMessage);
          }
        }, {
          key: "videoApi",
          value: function videoApi() {
            return this.http.get("http://127.0.0.1:62719/video-chat.component.html");
          }
        }]);

        return ChatService;
      }();

      ChatService.ɵfac = function ChatService_Factory(t) {
        return new (t || ChatService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]));
      };

      ChatService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
        token: ChatService,
        factory: ChatService.ɵfac,
        providedIn: 'root'
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ChatService, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
          args: [{
            providedIn: 'root'
          }]
        }], function () {
          return [{
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false,
        VIDEOSDK_API_KEY: 'e7af44ff-b8c4-4b28-8a98-25acfc5b8a70',
        local: 'local',
        apiBaseUrl: 'https://SwapOn.stackroute.io',
        localUrl: 'http://localhost:8080'
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "FJfR":
    /*!******************************************************!*\
      !*** ./src/app/my-products/my-products.component.ts ***!
      \******************************************************/

    /*! exports provided: MyProductsComponent */

    /***/
    function FJfR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MyProductsComponent", function () {
        return MyProductsComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/paginator */
      "5QHs");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../chat-bot/chat-bot.component */
      "wY5D");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/tooltip */
      "ZFy/");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");

      function MyProductsComponent_div_26_Template(rf, ctx) {
        if (rf & 1) {
          var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card", 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MyProductsComponent_div_26_Template_mat_card_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var productdata_r2 = ctx.$implicit;

            var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r3.saveData(productdata_r2);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 20);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 21);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 22);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 23);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MyProductsComponent_div_26_Template_mat_icon_click_6_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var productdata_r2 = ctx.$implicit;

            var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r5.deleteItem(productdata_r2.productId);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "delete");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "mat-card-content", 25);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "strong", 27);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "strong", 28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "mat-divider", 29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 31);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "mat-icon", 32);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, " location_on");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 31);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "date_range");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 33);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](29, "date");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var productdata_r2 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("matToolTip", productdata_r2.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", productdata_r2.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" \u20B9", productdata_r2.productPrice, "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r2.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r2.sellerState);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](29, 6, productdata_r2.productdate));
        }
      }

      var _c0 = function _c0() {
        return [5, 10, 20, 30];
      };

      var MyProductsComponent = /*#__PURE__*/function () {
        function MyProductsComponent(rs) {
          _classCallCheck(this, MyProductsComponent);

          this.rs = rs;
          this.product = [];
          this.showIcon = true;
          this.lowValue = 0;
          this.highValue = 10;
        }

        _createClass(MyProductsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this7 = this;

            this.rs.getMyProducts().subscribe(function (response) {
              console.log(response);
              var size = response.length;

              for (var i = 0; i < size; i++) {
                // console.log(response.productId[i])
                _this7.product.push(response[i]);

                _this7.product[i].image = "data:image/jpeg;base64," + _this7.product[i].image;
                console.log(_this7.product[0].productId);
                localStorage.setItem("productId", _this7.product[0].productId);
              } //  for(var i=0;i<this.product.length;i++)
              //   {
              //     this.product[i].image = 'data:image/jpeg;base64,' + this.product[i].image;
              //   }


              console.log(_this7.product);
            }, function (error) {
              console.log("Error Occured" + error);
            });
          }
        }, {
          key: "saveData",
          value: function saveData(data) {
            localStorage.setItem("productId", data.productId);
            localStorage.setItem("productCategory", data.productCategory);
            localStorage.setItem("productCity", data.city);
          }
        }, {
          key: "changeIcon",
          value: function changeIcon() {
            this.showIcon = !this.showIcon;
          }
        }, {
          key: "ngOnChanges",
          value: function ngOnChanges() {
            window.location.reload();
          } // used to build a slice of papers relevant at any given time

        }, {
          key: "getPaginatorData",
          value: function getPaginatorData(event) {
            this.lowValue = event.pageIndex * event.pageSize;
            this.highValue = this.lowValue + event.pageSize;
            return event;
          }
        }, {
          key: "deleteItem",
          value: function deleteItem(items) {
            console.log(items);
            this.rs.deleteMyProduct(items).subscribe(function (resp) {
              return console.log(resp);
            });
            console.log("product Deleted seccessfully");
            location.reload();
          }
        }]);

        return MyProductsComponent;
      }();

      MyProductsComponent.ɵfac = function MyProductsComponent_Factory(t) {
        return new (t || MyProductsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]));
      };

      MyProductsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: MyProductsComponent,
        selectors: [["app-my-products"]],
        features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
        decls: 30,
        vars: 9,
        consts: [[1, "toolbar"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], [1, "Title"], [1, "spacer"], ["mat-fab", "", "routerLink", "/addProduct", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["mat-raised-button", "", "routerLink", "/addProduct", "color", "primary", 1, "sellc"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], [1, "menu"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/profile"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/showProduct"], ["mat-menu-item", "", "routerLink", "/login"], ["routerLink", "/myProducts", 1, "body"], ["pageSize", "10", "showFirstLastButtons", "false", 2, "background-color", "inherit", "padding", "30px 30px 0px 30px", 3, "length", "pageSizeOptions", "page"], ["fxLayout", "row wrap", "fxLayoutGap", "20px grid", "fxLayoutAlign", "start center", "routerLink", "/myProducts", 1, "con"], ["fxFlex", "20%", "fxFlex.xs", "100%", "fxFlex.sm", "50%", 4, "ngFor", "ngForOf"], ["fxFlex", "20%", "fxFlex.xs", "100%", "fxFlex.sm", "50%"], [1, "example-card", 3, "matToolTip", "click"], ["fxLayout", "row", "fxLayoutGap", "10px;"], ["fxFlex", "90%", "fxLayoutAlign", "center center"], ["mat-card-image", "", "alt", "Pic of Mobile", 1, "img", 3, "src"], ["fxFlex", "10%", "routerLink", "/myProducts"], ["matTooltip", "delete", 3, "click"], [1, "text"], ["id", "title", "fxLayout", "column", "fxLayoutAlign", "center start"], [2, "font-size", "25px"], [2, "color", "#9E9E9E"], [1, "divider"], ["fxLayout", "row", "fxLayoutAlign", "space-between", 1, "locationAndDate"], ["fxLayout", "row", "fxLayoutAlign", "center center"], ["matTooltip", "location"], [2, "padding-left", "5px"]],
        template: function MyProductsComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "add");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "a", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "SELL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mat-icon", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "mat-menu", 8, 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "My Profile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "button", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "All Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-paginator", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("page", function MyProductsComponent_Template_mat_paginator_page_24_listener($event) {
              return ctx.getPaginatorData($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](26, MyProductsComponent_div_26_Template, 30, 8, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](27, "slice");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "app-chat-bot");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("length", ctx.product.length)("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](8, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind3"](27, 4, ctx.product, ctx.lowValue, ctx.highValue));
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLink"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButton"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkWithHref"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_6__["MatMenuTrigger"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_6__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_6__["MatMenuItem"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutGapDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutAlignDirective"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_10__["ChatBotComponent"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultFlexDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardImage"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_12__["MatTooltip"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardContent"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_13__["MatDivider"]],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["SlicePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["DatePipe"]],
        styles: [".toolbar[_ngcontent-%COMP%]{\r\n    background-color: #383a48;\r\n  width: 100%;\r\n  color: whitesmoke;\r\n  height: 76px;\r\n  }\r\n.body[_ngcontent-%COMP%]{\r\n  width: 100%;\r\n  \r\n}\r\n.con[_ngcontent-%COMP%]{\r\n  margin-left:20px;\r\n  width: 100%;\r\n  padding: 30px;\r\n}\r\n.filterDiv[_ngcontent-%COMP%]{\r\n  background-color: white;\r\n}\r\n.example-card[_ngcontent-%COMP%] {\r\n  border: black 2px solid;\r\n  border-radius: 10px;\r\n \r\n  }\r\n.img[_ngcontent-%COMP%]{\r\n    max-width: 200px;\r\n    width: auto;\r\n    height:150px;\r\n    size: auto;\r\n    margin: auto;\r\n    text-align: center;\r\n    padding: 10px;\r\n  }\r\n.locationAndDate[_ngcontent-%COMP%]{\r\n  padding-top: 35px;\r\n  font-size: 15px;\r\n}\r\n.filter[_ngcontent-%COMP%]{\r\n  width:13vw;\r\n  \r\n}\r\n.filterSort[_ngcontent-%COMP%]{\r\n margin:20px;\r\n \r\n}\r\n#button[_ngcontent-%COMP%]{\r\n  margin-bottom:15px;\r\n}\r\n#title[_ngcontent-%COMP%]{\r\n  height:20px;\r\n  justify-content: center;\r\n}\r\n.divider[_ngcontent-%COMP%]{\r\n  margin-top: 25px;\r\n}\r\n.locDate[_ngcontent-%COMP%]{\r\n  padding-right: 15px;\r\n}\r\n.text[_ngcontent-%COMP%]{\r\n  padding-top:30px;\r\n}\r\n.navbar-brand[_ngcontent-%COMP%] {\r\n  cursor: pointer;\r\n  margin-left: 10px;\r\n  margin-right: 0px;\r\n}\r\n.Title[_ngcontent-%COMP%] {\r\n  \r\n  font-size: 150%;\r\n  margin-left: 10px;\r\n}\r\n.spacer[_ngcontent-%COMP%]{\r\n  flex:1 1 auto;\r\n}\r\n.icon[_ngcontent-%COMP%]{\r\n  height:20px;\r\n  display:inline-block;\r\n  font-size: 43px;\r\n  margin-bottom: 20px;\r\n  margin-right: 20px;\r\n}\r\n.sellicon[_ngcontent-%COMP%]{\r\n  margin-right:1px;\r\n  z-index: 1;\r\n}\r\n.sellc[_ngcontent-%COMP%]{\r\n  right: 6px;\r\n  \r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LXByb2R1Y3RzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx5QkFBeUI7RUFDM0IsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1o7QUFDRjtFQUNFLFdBQVc7O0FBRWI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsYUFBYTtBQUNmO0FBQ0E7RUFDRSx1QkFBdUI7QUFDekI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixtQkFBbUI7O0VBRW5CO0FBQ0E7SUFDRSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLFlBQVk7SUFDWixVQUFVO0lBQ1YsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixhQUFhO0VBQ2Y7QUFFRjtFQUNFLGlCQUFpQjtFQUNqQixlQUFlO0FBQ2pCO0FBQ0E7RUFDRSxVQUFVOztBQUVaO0FBQ0E7Q0FDQyxXQUFXOztBQUVaO0FBQ0E7RUFDRSxrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLFdBQVc7RUFDWCx1QkFBdUI7QUFDekI7QUFDQTtFQUNFLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7QUFFQTtFQUNFLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsaUJBQWlCO0FBQ25CO0FBRUE7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLGlCQUFpQjtBQUNuQjtBQUVBO0VBQ0UsYUFBYTtBQUNmO0FBRUE7RUFDRSxXQUFXO0VBQ1gsb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsa0JBQWtCO0FBQ3BCO0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsVUFBVTtBQUNaO0FBRUE7RUFDRSxVQUFVOztBQUVaIiwiZmlsZSI6Im15LXByb2R1Y3RzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzODNhNDg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgY29sb3I6IHdoaXRlc21va2U7XHJcbiAgaGVpZ2h0OiA3NnB4O1xyXG4gIH1cclxuLmJvZHl7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgXHJcbn1cclxuLmNvbntcclxuICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDMwcHg7XHJcbn1cclxuLmZpbHRlckRpdntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4uZXhhbXBsZS1jYXJkIHtcclxuICBib3JkZXI6IGJsYWNrIDJweCBzb2xpZDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gXHJcbiAgfVxyXG4gIC5pbWd7XHJcbiAgICBtYXgtd2lkdGg6IDIwMHB4O1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICBzaXplOiBhdXRvO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICB9XHJcblxyXG4ubG9jYXRpb25BbmREYXRle1xyXG4gIHBhZGRpbmctdG9wOiAzNXB4O1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4uZmlsdGVye1xyXG4gIHdpZHRoOjEzdnc7XHJcbiAgXHJcbn1cclxuLmZpbHRlclNvcnR7XHJcbiBtYXJnaW46MjBweDtcclxuIFxyXG59XHJcbiNidXR0b257XHJcbiAgbWFyZ2luLWJvdHRvbToxNXB4O1xyXG59XHJcbiN0aXRsZXtcclxuICBoZWlnaHQ6MjBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4uZGl2aWRlcntcclxuICBtYXJnaW4tdG9wOiAyNXB4O1xyXG59XHJcbi5sb2NEYXRle1xyXG4gIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbn1cclxuLnRleHR7XHJcbiAgcGFkZGluZy10b3A6MzBweDtcclxufVxyXG5cclxuLm5hdmJhci1icmFuZCB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMHB4O1xyXG59XHJcblxyXG4uVGl0bGUge1xyXG4gIC8qIGZvbnQtZmFtaWx5OiAnUnViaWsgRGlzdHJlc3NlZCcsIGN1cnNpdmU7ICovXHJcbiAgZm9udC1zaXplOiAxNTAlO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG4uc3BhY2Vye1xyXG4gIGZsZXg6MSAxIGF1dG87XHJcbn1cclxuXHJcbi5pY29ue1xyXG4gIGhlaWdodDoyMHB4O1xyXG4gIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogNDNweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxufVxyXG5cclxuLnNlbGxpY29ue1xyXG4gIG1hcmdpbi1yaWdodDoxcHg7XHJcbiAgei1pbmRleDogMTtcclxufVxyXG5cclxuLnNlbGxje1xyXG4gIHJpZ2h0OiA2cHg7XHJcbiAgXHJcbn0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MyProductsComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-my-products",
            templateUrl: "./my-products.component.html",
            styleUrls: ["./my-products.component.css"]
          }]
        }], function () {
          return [{
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "MvdQ":
    /*!**********************************************************!*\
      !*** ./src/app/register-user/register-user.component.ts ***!
      \**********************************************************/

    /*! exports provided: RegisterUserComponent */

    /***/
    function MvdQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterUserComponent", function () {
        return RegisterUserComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _service_register_user_registration__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../service/register/user-registration */
      "du5m");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/grid-list */
      "40+f");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");

      function RegisterUserComponent_mat_error_30_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.getErrorMessage());
        }
      }

      function RegisterUserComponent_mat_error_33_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Password must have at least ", ctx_r1.minPw, " characters and a special character");
        }
      }

      function RegisterUserComponent_mat_error_34_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Password must have at least ", ctx_r2.minPw, " characters");
        }
      }

      function RegisterUserComponent_mat_error_40_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Passwords don't match");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function RegisterUserComponent_mat_error_41_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Passwords don't match");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var RegisterUserComponent = /*#__PURE__*/function () {
        function RegisterUserComponent(registerService, router, formBuilder) {
          _classCallCheck(this, RegisterUserComponent);

          this.registerService = registerService;
          this.router = router;
          this.formBuilder = formBuilder;
          this.user = new _service_register_user_registration__WEBPACK_IMPORTED_MODULE_1__["UserRegistration"]();
          this.errorMessage = "";
          this.registerForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            firstname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            contactNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            cpassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
          });
          this.minPw = 8;
          this.checked = false;
          this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]);
          this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
          this.cpassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
          this.RememberMe = false;
          this.hide = true;
          this.languages = [{
            value: "HINDI-1",
            viewValue: "HINDI"
          }, {
            value: "ENGLISH-0",
            viewValue: "ENGLISH"
          }, {
            value: "HINDI-1",
            viewValue: "HINDI"
          }];
          this.emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
          this.passwordPattern = new RegExp(/(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,10}/);
        }

        _createClass(RegisterUserComponent, [{
          key: "getErrorMessage",
          value: function getErrorMessage() {
            if (this.email.hasError("required")) {
              return "You must enter a valid Email";
            }

            return this.email.hasError("email") ? "Not a valid email" : "";
          } // registerForm= new FormGroup({
          //   firstname: new FormControl('',Validators.required),
          //   lastname: new FormControl('',Validators.required),
          //   email: new FormControl('',Validators.required),
          //   password: new FormControl('',Validators.required),
          //   cpassword: new FormControl('',Validators.required),
          // });

        }, {
          key: "ngOnInit",
          value: function ngOnInit() {// this.formGroup = this.formBuilder.group({
            //   password: ['', [Validators.required, Validators.minLength(this.minPw)]],
            //   cpassword: ['', [Validators.required]]
            // },
            // // {validator: passwordMatchValidator}
            // );
          } // get password() { return this.formGroup.get('password'); }
          // get cpassword() { return this.formGroup.get('cpassword'); }
          // onPasswordInput() {
          //   if (this.formGroup.hasError('passwordMismatch'))
          //     this.cpassword.setErrors([{'passwordMismatch': true}]);
          //   else
          //     this.cpassword.setErrors(null);
          // }

        }, {
          key: "onRegister",
          value: function onRegister() {
            var _this8 = this;

            console.log(this.registerForm.value);
            this.registerData = this.registerForm.value;
            this.registerService.registerApi(this.registerData).subscribe(function (Response) {
              console.log("registeration successful");

              _this8.router.navigate(["/login"]);
            });
          }
        }]);

        return RegisterUserComponent;
      }();

      RegisterUserComponent.ɵfac = function RegisterUserComponent_Factory(t) {
        return new (t || RegisterUserComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]));
      };

      RegisterUserComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: RegisterUserComponent,
        selectors: [["app-register-user"]],
        decls: 51,
        vars: 18,
        consts: [["color", "primary", 1, "navbar-expand-lg", "navbar", "fixed-top"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], ["routerLink", "", 1, "Title"], ["name", "viewport", "content", "width=device-width, initial-scale=1.0"], ["type", "button", "routerLink", "", 1, "btn", "btn-light"], [1, "col-lg-5", "col-md-5", "col-sm-5", "col-12"], ["src", "assets/Objects.png", "width", "50", "height", "50", "alt", "", 1, "d-inline-block"], ["cols", "2", "rowHeight", "90vh"], ["mat-card-image", "", "src", "assets/handshake.webp", "alt", "img", "width", "90%", "height", "80%", 1, "handshake-image"], [2, "background-color", "rgb(252, 250, 250)"], [1, "container", "col-md-6", 2, "background-color", "rgb(252, 250, 250)"], ["fxLayoutAlign", "center center", "fxLayout.xs", "column", 1, "main-div"], ["fxFlex", "100"], ["color", "primary"], [1, "signup"], ["fxLayoutAlign", "stretch", "fxLayout", "column", 1, "login-form", 3, "formGroup", "ngSubmit"], ["appearance", "fill", 1, "example-full-wid"], ["matInput", "", "type", "text", "formControlName", "firstname", "name", "firstname", "placeholder", "Name", 1, "form-control"], ["matPrefix", ""], ["type", "tel", "matInput", "", "formControlName", "contactNo", "name", "contactNo", "minlength", "10", "maxlength", "10", "placeholder", "XXXXXXXXXX", 1, "form-control"], ["matSuffix", ""], ["appearance", "fill"], ["matInput", "", "type", "email", "formControlName", "email", "name", "email", "placeholder", "Email", 1, "form-control", 3, "pattern"], [4, "ngIf"], ["matInput", "", "name", "password", "formControlName", "password", "placeholder", "Password", 1, "form-control", 3, "type", "pattern"], ["mat-icon-button", "", "matSuffix", "", 3, "click"], ["matInput", "", "name", "cpassword", "formControlName", "cpassword", "placeholder", "Confirm Password", 1, "form-control", 3, "type", "pattern"], ["mat-raised-button", "", "color", "primary", "type", "submit", "name", "submit-reg", 3, "disabled"], [1, "signin"], ["routerLink", "/login"]],
        template: function RegisterUserComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "head");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "meta", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-grid-list", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-grid-tile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "img", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "mat-grid-tile", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-card", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-toolbar", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-label", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Sign Up");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "form", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function RegisterUserComponent_Template_form_ngSubmit_19_listener() {
              return ctx.onRegister();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-form-field", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "input", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "mat-form-field", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "span", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "+91 \xA0");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "mat-icon", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "mode_edit");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "mat-form-field", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "input", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](30, RegisterUserComponent_mat_error_30_Template, 2, 1, "mat-error", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "mat-form-field", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "input", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](33, RegisterUserComponent_mat_error_33_Template, 2, 1, "mat-error", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](34, RegisterUserComponent_mat_error_34_Template, 2, 1, "mat-error", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "button", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RegisterUserComponent_Template_button_click_35_listener() {
              return ctx.hide = !ctx.hide;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "mat-form-field", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](39, "input", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](40, RegisterUserComponent_mat_error_40_Template, 2, 0, "mat-error", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](41, RegisterUserComponent_mat_error_41_Template, 2, 0, "mat-error", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "button", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RegisterUserComponent_Template_button_click_42_listener() {
              return ctx.hide = !ctx.hide;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "button", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "Sign Up");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "p", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Already have an account? ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "a", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50, "Sign In");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.registerForm);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pattern", ctx.emailPattern);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.email.invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("type", ctx.hide ? "password" : "text")("pattern", ctx.passwordPattern);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.password.hasError("required"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.password.hasError("minlength"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-label", "Hide password")("aria-pressed", ctx.hide);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.hide ? "visibility_off" : "visibility");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("type", ctx.hide ? "password" : "text")("pattern", ctx.passwordPattern);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpassword.hasError("required"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpassword.invalid && !ctx.cpassword.hasError("required"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-label", "Hide password")("aria-pressed", ctx.hide);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.hide ? "visibility_off" : "visibility");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.registerForm.valid);
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLink"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__["MatGridList"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__["MatGridTile"], _angular_material_card__WEBPACK_IMPORTED_MODULE_7__["MatCardImage"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutAlignDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_7__["MatCard"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultFlexDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatLabel"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormField"], _angular_material_input__WEBPACK_IMPORTED_MODULE_10__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControlName"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatPrefix"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MinLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MaxLengthValidator"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIcon"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatSuffix"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["PatternValidator"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgIf"], _angular_material_button__WEBPACK_IMPORTED_MODULE_13__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLinkWithHref"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatError"]],
        styles: [".fcontainer[_ngcontent-%COMP%]{\n\n  height: 100vh;\n  display: flex;\n  \n  \n  \n  \n  \n  flex-wrap: wrap; \n  \n  flex-flow: column wrap; \n  \n  \n}\n\n.fitem[_ngcontent-%COMP%]{\n  \n\n  float: right;\n  width: 50%;\n  height: 100%;\n}\n\n.item1[_ngcontent-%COMP%]{\n  flex:1 ;\n  \n   flex-shrink: 2; \n\n}\n\n.item2[_ngcontent-%COMP%]{\n  width: 40%;\n  height: 100%;\n  \n  \n}\n\n\n\n.form-check[_ngcontent-%COMP%] {\n  display: block;\n  min-height: 1.5rem;\n  padding-left: 0em;\n  margin-bottom: 0.125rem;\n  margin-top: 1.5rem;\n}\n\n.mat-body[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .mat-body-1[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .mat-typography[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  \n  margin:12px;\n}\n\n.signin[_ngcontent-%COMP%]{\n  margin-top: 1.5rem;\n}\n\n.bttn[_ngcontent-%COMP%]{\n  margin-top: 1.5rem;\n}\n\n.handshake-image[_ngcontent-%COMP%]{\n  width:100%;\n  height: auto;\n}\n\n.main-div[_ngcontent-%COMP%]   mat-card[_ngcontent-%COMP%]{\n  padding: 0px;\n  \n}\n\n.example-form[_ngcontent-%COMP%] {\n  min-width: 150px;\n  max-width: 500px;\n  width: 100%;\n}\n\n.login-form[_ngcontent-%COMP%]{\n  padding: 20px;\n}\n\n.lang[_ngcontent-%COMP%]{\n  margin-left:80px;\n}\n\n.spacer[_ngcontent-%COMP%]{\n  flex: 1 1 auto;\n}\n\n.mat-toolbar-single-row[_ngcontent-%COMP%] {\n  height: 76px;\n  padding: 0;\n}\n\n.mat-toolbar.mat-primary[_ngcontent-%COMP%]{\n  background-color: #383a48;\n}\n\n.mat-form-field-appearance-legacy[_ngcontent-%COMP%]   .mat-form-field-wrapper[_ngcontent-%COMP%] {\n  padding-bottom: 1.2em;\n}\n\n.categ[_ngcontent-%COMP%]{\n  margin-left: 10px;\n}\n\n.mat-form-field[_ngcontent-%COMP%] {\n  font-size: medium;\n\n}\n\n.navbar[_ngcontent-%COMP%] {\n\n  display: flex;\n  position: fixed;\n\n}\n\n.sell-button[_ngcontent-%COMP%]{\n  margin-right: 10px;\n  padding:0px 20px 0px 20px;\n}\n\n.reg-button[_ngcontent-%COMP%]{\n  margin-left:9px;\n}\n\n.Title[_ngcontent-%COMP%] {\n  \n  font-size: 150%;\n  margin-left: 10px;\n}\n\n.navbar-brand[_ngcontent-%COMP%] {\n  cursor: pointer;\n  margin-left: 10px;\n  margin-right: 0px;\n}\n\n.example-form[_ngcontent-%COMP%] {\n  min-width: 250px;\n  max-width: 500px;\n  width: 100%;\n}\n\n.example-full-width[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-left: 55px;\n  margin-bottom: 5px;\n}\n\n.example-input[_ngcontent-%COMP%] {\n  max-width: 100%;\n  width: 200px;\n}\n\n.example-full-wid[_ngcontent-%COMP%]{\n  margin: block end 10px; ;\n}\n\n.signup[_ngcontent-%COMP%]{\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLXVzZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7RUFFRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLG9DQUFvQztFQUNwQywrQkFBK0I7RUFDL0IsaUNBQWlDO0VBQ2pDLDZCQUE2QjtFQUM3Qjs7NEJBRTBCO0VBQzFCLGVBQWU7RUFDZiw2QkFBNkI7RUFDN0Isc0JBQXNCOzs7QUFHeEI7O0FBRUE7OztFQUdFLFlBQVk7RUFDWixVQUFVO0VBQ1YsWUFBWTtBQUNkOztBQUVBO0VBQ0UsT0FBTztFQUNQLGtCQUFrQjtHQUNqQixjQUFjOztBQUVqQjs7QUFFQTtFQUNFLFVBQVU7RUFDVixZQUFZO0VBQ1osa0JBQWtCOztBQUVwQjs7QUFDQTs7O0dBR0c7O0FBRUg7RUFDRSxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQix1QkFBdUI7RUFDdkIsa0JBQWtCO0FBQ3BCOztBQUVBOztFQUVFLFdBQVc7QUFDYjs7QUFDQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFDQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLFVBQVU7RUFDVixZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxZQUFZOztBQUVkOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxjQUFjO0FBQ2hCOztBQUdBO0VBQ0UsWUFBWTtFQUNaLFVBQVU7QUFDWjs7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjs7QUFDQTtFQUNFLHFCQUFxQjtBQUN2Qjs7QUFDQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGlCQUFpQjs7QUFFbkI7O0FBQ0E7O0VBRUUsYUFBYTtFQUNiLGVBQWU7O0FBRWpCOztBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLHlCQUF5QjtBQUMzQjs7QUFDQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixZQUFZO0FBQ2Q7O0FBR0E7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxpQkFBaUI7QUFDbkIiLCJmaWxlIjoicmVnaXN0ZXItdXNlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZjb250YWluZXJ7XG5cbiAgaGVpZ2h0OiAxMDB2aDtcbiAgZGlzcGxheTogZmxleDtcbiAgLyogZmxleC1kaXJlY3Rpb246IGNvbHVtbi1yZXZlcnNlOyAqL1xuICAvKiBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kOyAqL1xuICAvKiBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7ICovXG4gIC8qIGp1c3RpZnktY29udGVudDogY2VudGVyOyAqL1xuICAvKiBhbGlnbi1pdGVtczogY2VudGVyO1xuICBhbGlnbi1pdGVtczogZmxleC1lbmQ7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0OyAqL1xuICBmbGV4LXdyYXA6IHdyYXA7IFxuICAvKiBmbGV4LXdyYXA6IHdyYXAtcmV2ZXJzZTsgKi9cbiAgZmxleC1mbG93OiBjb2x1bW4gd3JhcDsgXG4gIFxuICBcbn1cblxuLmZpdGVte1xuICBcblxuICBmbG9hdDogcmlnaHQ7XG4gIHdpZHRoOiA1MCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLml0ZW0xe1xuICBmbGV4OjEgO1xuICAvKiBmbGV4LWdyb3c6IDM7ICovXG4gICBmbGV4LXNocmluazogMjsgXG5cbn1cblxuLml0ZW0ye1xuICB3aWR0aDogNDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIC8qIGZsZXgtZ3JvdzogMjsgKi9cbiAgXG59XG4vKiAuVGl0bGUge1xuICBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlO1xuICBmb250LXNpemU6IDE1MCU7XG59ICovXG5cbi5mb3JtLWNoZWNrIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1pbi1oZWlnaHQ6IDEuNXJlbTtcbiAgcGFkZGluZy1sZWZ0OiAwZW07XG4gIG1hcmdpbi1ib3R0b206IDAuMTI1cmVtO1xuICBtYXJnaW4tdG9wOiAxLjVyZW07XG59XG5cbi5tYXQtYm9keSBwLCAubWF0LWJvZHktMSBwLCAubWF0LXR5cG9ncmFwaHkgcCB7XG4gIFxuICBtYXJnaW46MTJweDtcbn1cbi5zaWduaW57XG4gIG1hcmdpbi10b3A6IDEuNXJlbTtcbn1cbi5idHRue1xuICBtYXJnaW4tdG9wOiAxLjVyZW07XG59XG5cbi5oYW5kc2hha2UtaW1hZ2V7XG4gIHdpZHRoOjEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLm1haW4tZGl2IG1hdC1jYXJke1xuICBwYWRkaW5nOiAwcHg7XG4gIFxufVxuXG4uZXhhbXBsZS1mb3JtIHtcbiAgbWluLXdpZHRoOiAxNTBweDtcbiAgbWF4LXdpZHRoOiA1MDBweDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5sb2dpbi1mb3Jte1xuICBwYWRkaW5nOiAyMHB4O1xufVxuXG4ubGFuZ3tcbiAgbWFyZ2luLWxlZnQ6ODBweDtcbn1cblxuLnNwYWNlcntcbiAgZmxleDogMSAxIGF1dG87XG59XG5cblxuLm1hdC10b29sYmFyLXNpbmdsZS1yb3cge1xuICBoZWlnaHQ6IDc2cHg7XG4gIHBhZGRpbmc6IDA7XG59XG4ubWF0LXRvb2xiYXIubWF0LXByaW1hcnl7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzODNhNDg7XG59XG4ubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1sZWdhY3kgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMS4yZW07XG59XG4uY2F0ZWd7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubWF0LWZvcm0tZmllbGQge1xuICBmb250LXNpemU6IG1lZGl1bTtcblxufVxuLm5hdmJhciB7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgcG9zaXRpb246IGZpeGVkO1xuXG59XG4uc2VsbC1idXR0b257XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgcGFkZGluZzowcHggMjBweCAwcHggMjBweDtcbn1cbi5yZWctYnV0dG9ue1xuICBtYXJnaW4tbGVmdDo5cHg7XG59XG5cbi5UaXRsZSB7XG4gIC8qIGZvbnQtZmFtaWx5OiAnUnViaWsgRGlzdHJlc3NlZCcsIGN1cnNpdmU7ICovXG4gIGZvbnQtc2l6ZTogMTUwJTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5uYXZiYXItYnJhbmQge1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDBweDtcbn1cblxuLmV4YW1wbGUtZm9ybSB7XG4gIG1pbi13aWR0aDogMjUwcHg7XG4gIG1heC13aWR0aDogNTAwcHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uZXhhbXBsZS1mdWxsLXdpZHRoIHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbi1sZWZ0OiA1NXB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5cbi5leGFtcGxlLWlucHV0IHtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICB3aWR0aDogMjAwcHg7XG59XG5cblxuLmV4YW1wbGUtZnVsbC13aWR7XG4gIG1hcmdpbjogYmxvY2sgZW5kIDEwcHg7IDtcbn1cblxuLnNpZ251cHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59Il19 */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](RegisterUserComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-register-user",
            templateUrl: "./register-user.component.html",
            styleUrls: ["./register-user.component.css"]
          }]
        }], function () {
          return [{
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
          }, {
            type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "iInd");

      var AppComponent = /*#__PURE__*/_createClass(function AppComponent() {
        _classCallCheck(this, AppComponent);

        this.title = 'Learnzilla';
      });

      AppComponent.ɵfac = function AppComponent_Factory(t) {
        return new (t || AppComponent)();
      };

      AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AppComponent,
        selectors: [["app-root"]],
        decls: 1,
        vars: 0,
        template: function AppComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
          }
        },
        directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]],
        styles: [".mat-stepper-horizontal[_ngcontent-%COMP%] {\n    margin-top: 8px;\n  }\n  \n  .mat-mdc-form-field[_ngcontent-%COMP%] {\n    margin-top: 16px;\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZUFBZTtFQUNqQjs7RUFFQTtJQUNFLGdCQUFnQjtFQUNsQiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtc3RlcHBlci1ob3Jpem9udGFsIHtcbiAgICBtYXJnaW4tdG9wOiA4cHg7XG4gIH1cbiAgXG4gIC5tYXQtbWRjLWZvcm0tZmllbGQge1xuICAgIG1hcmdpbi10b3A6IDE2cHg7XG4gIH0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-root',
            templateUrl: './app.component.html',
            styleUrls: ['./app.component.css']
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "UBkm":
    /*!*************************************!*\
      !*** ./src/app/model/login/user.ts ***!
      \*************************************/

    /*! exports provided: User */

    /***/
    function UBkm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "User", function () {
        return User;
      });

      var User = /*#__PURE__*/_createClass(function User() {
        _classCallCheck(this, User);
      });
      /***/

    },

    /***/
    "WGIg":
    /*!******************************************************!*\
      !*** ./src/app/add-product/add-product.component.ts ***!
      \******************************************************/

    /*! exports provided: AddProductComponent */

    /***/
    function WGIg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddProductComponent", function () {
        return AddProductComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! sweetalert2 */
      "PSD3");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_2__);
      /* harmony import */


      var _service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../service/my-profile/my-profile.service */
      "iYH4");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/stepper */
      "hzfI");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/material/tooltip */
      "ZFy/");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! @angular/material/datepicker */
      "TN/R");
      /* harmony import */


      var _angular_material_select__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! @angular/material/select */
      "ZTz/");
      /* harmony import */


      var _angular_material_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! @angular/material/core */
      "UhP/");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");

      function AddProductComponent_mat_error_37_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Product Name is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_45_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Product Price is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_51_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Product Brand is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_82_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Category is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_111_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Product Condition is required ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_124_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Product Description is required ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_150_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller Name is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_158_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller City is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_166_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller Pincode is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_228_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller State is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_236_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller Email is required");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AddProductComponent_mat_error_244_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Seller Mobile Number is required ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var AddProductComponent = /*#__PURE__*/function () {
        function AddProductComponent(myProfile, _formBuilder, http, productService) {
          _classCallCheck(this, AddProductComponent);

          this.myProfile = myProfile;
          this._formBuilder = _formBuilder;
          this.http = http;
          this.productService = productService;
          this.today = new Date();
          this.url = "";
          this.allProducts = [];
          this.productsList = [];
          this.isEditable = true;
          this.addProduct = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            productName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            productPrice: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            productBrand: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            purchaseDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required)
          });
          this.addProductDescription = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            productCondition: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            productDetails: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            productDesc: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(700)]),
            file: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("")
          });
          this.sellerDetails = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            sellerName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]({
              disabled: true
            }, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            sellerPincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            sellerState: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
            sellerEmail: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]({
              disabled: true
            }, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email]),
            sellerMobile: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]({
              disabled: true
            }, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]),
            city: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required)
          });
        }

        _createClass(AddProductComponent, [{
          key: "myProfileDetails",
          value: function myProfileDetails() {
            var _this9 = this;

            this.myProfile.userProfile().subscribe(function (response) {
              console.log("This is logged in User Details", response);
              _this9.details = response;
              console.log(_this9.details);

              _this9.sellerDetails.patchValue({
                sellerEmail: _this9.details.email,
                sellerMobile: _this9.details.contactNo,
                sellerName: _this9.details.firstname
              });
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.myProfileDetails();
          }
        }, {
          key: "productName",
          get: function get() {
            return this.addProduct.controls["productName"];
          }
        }, {
          key: "productPrice",
          get: function get() {
            return this.addProduct.controls["productPrice"];
          }
        }, {
          key: "productBrand",
          get: function get() {
            return this.addProduct.controls["productBrand"];
          }
        }, {
          key: "purchaseDate",
          get: function get() {
            return this.addProduct.controls["productDate"];
          }
        }, {
          key: "category",
          get: function get() {
            return this.addProduct.controls["category"];
          }
        }, {
          key: "productCondition",
          get: function get() {
            return this.addProductDescription.controls["productCondition"];
          }
        }, {
          key: "productDetails",
          get: function get() {
            return this.addProductDescription.controls["productDetails"];
          }
        }, {
          key: "productDesc",
          get: function get() {
            return this.addProductDescription.controls["productDesc"];
          }
        }, {
          key: "file",
          get: function get() {
            return this.addProductDescription.controls["file"];
          }
        }, {
          key: "sellerName",
          get: function get() {
            return this.sellerDetails.controls["sellerName"];
          }
        }, {
          key: "sellerPincode",
          get: function get() {
            return this.sellerDetails.controls["sellerPincode"];
          }
        }, {
          key: "sellerState",
          get: function get() {
            return this.sellerDetails.controls["sellerState"];
          }
        }, {
          key: "sellerEmail",
          get: function get() {
            return this.sellerDetails.controls["sellerEmail"];
          }
        }, {
          key: "sellerMobile",
          get: function get() {
            return this.sellerDetails.controls["sellerMobile"];
          }
        }, {
          key: "city",
          get: function get() {
            return this.sellerDetails.controls["city"];
          }
        }, {
          key: "myFile",
          value: function myFile(data) {
            this.selectedFile = data.target.files[0];
          }
        }, {
          key: "saveData",
          value: function saveData() {
            console.log(this.addProduct.value);
            console.log(this.addProductDescription.value);
            console.log(this.sellerDetails.value);
          }
        }, {
          key: "postProducts",
          value: function postProducts() {
            this.product = {
              productName: this.addProduct.value.productName,
              productPrice: this.addProduct.value.productPrice,
              purchaseDate: this.addProduct.value.purchaseDate,
              productCondition: this.addProductDescription.value.productCondition,
              additionalDetails: this.addProductDescription.value.productDetails,
              productDescription: this.addProductDescription.value.productDesc,
              sellerName: this.sellerDetails.value.sellerName,
              pincode: this.sellerDetails.value.sellerPincode,
              sellerEmail: this.sellerDetails.value.sellerEmail,
              sellerState: this.sellerDetails.value.sellerState,
              sellerMobile: this.sellerDetails.value.sellerMobile,
              brand: this.addProduct.value.productBrand,
              category: this.addProduct.value.category,
              city: this.sellerDetails.value.city
            };
            this.productsList.push(this.product);
            this.proImage = {
              file: this.selectedFile
            };
            this.productsList.push(this.proImage);
          }
        }, {
          key: "postImage",
          value: function postImage() {}
        }, {
          key: "OnSubmit",
          value: function OnSubmit() {
            this.postProducts();
            var formData = new FormData();
            formData.append("image", this.selectedFile);
            formData.append("Product", JSON.stringify(this.product));
            this.productService.postProduct(formData).subscribe(function (a) {
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire("Successfully done !!", "Product is Added ", "success");
              console.log(a);
              location.reload();
            });
          }
        }, {
          key: "getUserDetails",
          value: function getUserDetails(email) {
            var _this10 = this;

            this.myProfile.updateProfile(email).subscribe(function (response) {
              console.log("This is user", response);
              console.log(response[0].name);
              _this10.details = response;

              _this10.sellerDetails.patchValue({
                email: _this10.details[0].email,
                firstname: _this10.details[0].firstname,
                contactNo: _this10.details[0].contactNo
              });
            });
          }
        }]);

        return AddProductComponent;
      }();

      AddProductComponent.ɵfac = function AddProductComponent_Factory(t) {
        return new (t || AddProductComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__["MyProfileService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_5__["AppService"]));
      };

      AddProductComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AddProductComponent,
        selectors: [["app-add-product"]],
        decls: 251,
        vars: 27,
        consts: [[1, "toolbar"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], [1, "Title"], [1, "spacer"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], [1, "menu"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/profile"], ["mat-menu-item", "", "routerLink", "/myProducts"], ["mat-menu-item", "", "routerLink", "/showProduct"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/login"], ["linear", "", 1, "addProduct"], ["stepper", ""], ["label", "Add product", 3, "stepControl", "editable"], [3, "formGroup"], [1, "example-card"], ["fxLayout", "column", "fxLayoutAlign", "space-around center"], ["id", "heading"], [1, "form-group"], ["matTooltip", "Product Name", "appearance", "fill", 2, "width", "50vw"], ["for", "productName"], ["matSuffix", ""], ["name", "productName", "formControlName", "productName", "type", "text", "matInput", "", "required", ""], [4, "ngIf"], ["appearance", "fill", "matTooltip", "Product Price", 2, "width", "50vw"], ["for", "productPrice"], ["id", "productPrice", "name", "productPrice", "formControlName", "productPrice", "type", "number", "matInput", "", "required", ""], ["appearance", "fill", "matTooltip", "Product Brand", 2, "width", "50vw"], ["for", "productBrand"], ["id", "productBrand", "name", "productBrand", "formControlName", "productBrand", "type", "text", "matInput", "", "required", ""], ["appearance", "fill", "matTooltip", "Product Purchase Date", 2, "width", "50vw"], ["for", "purchaseDate"], ["id", "productDate", "name", "purchaseDate", "formControlName", "purchaseDate", "matInput", "", 3, "max", "matDatepicker"], ["matSuffix", "", 3, "for"], ["datepicker", ""], ["mat-button", "", "matDatepickerCancel", ""], ["mat-raised-button", "", "color", "primary", "matDatepickerApply", ""], ["appearance", "fill", "id", "category", "matTooltip", "Category"], ["for", "category"], ["name", "category", "formControlName", "category", "required", ""], ["value", "Mobile"], ["value", "Laptops"], ["value", "Tablets"], ["value", "Tv"], ["value", "Refridgerators"], ["value", "WashingMachine"], ["id", "button", "matTooltip", "Save and Continue", "mat-raised-button", "", "color", "primary", "matStepperNext", "", 3, "disabled", "click"], ["label", "Add Product Description", 3, "stepControl", "editable"], ["appearance", "fill", "matTooltip", "Product Condition", 2, "width", "50vw"], ["for", "productCondition"], ["name", "productCondition", "formControlName", "productCondition", "required", ""], ["value", "Brand new"], ["value", "Refurbished"], ["value", "Slightly Used"], ["value", "heavily Used"], ["value", "Unboxed"], ["appearance", "fill", "id", "condition", "matTooltip", "Additional Details"], ["for", "productDetails"], ["name", "productDetails", "formControlName", "productDetails", "type", "text", "matInput", ""], ["appearance", "fill", "id", "conditionText", "matTooltip", "Product Description"], ["for", "productDesc"], ["name", "productDesc", "formControlName", "productDesc", "type", "text", "matInput", "", "maxlength", "700", "id", "textArea", "required", ""], ["message", ""], [1, "AddPhotos"], [2, "padding-right", "10px"], ["type", "file", "formControlName", "file", "matTooltip", "Upload Image", "placeholder", "Upload Image", 3, "change"], ["id", "button", "matTooltip", "Previous", "mat-raised-button", "", "matStepperPrevious", ""], ["id", "button", "matTooltip", "Save and Continue", "type", "submit", "mat-raised-button", "", "color", "primary", "matStepperNext", "", 3, "disabled", "click"], ["label", "Add Seller details"], ["matTooltip", "Seller Name", "appearance", "fill", 2, "width", "50vw"], ["for", "sellerName"], ["name", "sellerName", "formControlName", "sellerName", "type", "text", "value", "", "matInput", "", "required", ""], ["appearance", "fill", "matTooltip", "city", 2, "width", "50vw"], ["for", "city"], ["name", "city", "formControlName", "city", "type", "text", "matInput", "", "required", ""], ["matTooltip", "Seller Pincode", "appearance", "fill", 2, "width", "50vw"], ["for", "sellerPincode"], ["name", "sellerPincode", "formControlName", "sellerPincode", "type", "number", "maxlength", "6", "minlength", "6", "matInput", "", "required", ""], ["matTooltip", "Seller State", "appearance", "fill", 2, "width", "50vw"], ["for", "sellerState"], ["name", "sellerState", "formControlName", "sellerState", "required", ""], ["value", "AndhraPradesh"], ["value", "ArunachalPradesh"], ["value", "Assam"], ["value", "Bihar"], ["value", "Chhattisgarh"], ["value", "Delhi"], ["value", "Goa"], ["value", "Gujarat"], ["value", "Haryana"], ["value", "Jharkhand"], ["value", "Karnataka"], ["value", "Kerala"], ["value", "MadhyaPradesh"], ["value", "Maharashtra"], ["value", "Manipur"], ["value", "Meghalaya"], ["value", "Mizoram"], ["value", "nagaland"], ["value", "Odisha"], ["value", "Punjab"], ["value", "Rajasthan"], ["value", "Sikkim"], ["value", "TamilNadu"], ["value", "Telangana"], ["value", "Tripura"], ["value", "UttarPradesh"], ["value", "Uttarakhand"], ["value", "WestBengal"], ["appearance", "fill", "matTooltip", "Seller Email", 2, "width", "50vw"], ["for", "sellerEmail"], ["name", "sellerEmail", "formControlName", "sellerEmail", "type", "email", "matInput", "", "required", ""], ["appearance", "fill", "matTooltip", "Seller Mobile", 2, "width", "50vw"], ["for", "sellerMobile"], ["name", "sellerMobile", "formControlName", "sellerMobile", "type", "number", "matInput", "", "required", "", "minlength", "10", "maxlength", "10"], ["id", "button", "matTooltip", "Submit", "routerLink", "/showProduct", "type", "submit", "mat-raised-button", "", "color", "primary", 3, "disabled", "click"]],
        template: function AddProductComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "mat-menu", 6, 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "My Profile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "My Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "All Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "button", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "button", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-horizontal-stepper", 13, 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "mat-step", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "form", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-card", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "mat-card-content");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Add product");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "mat-form-field", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "mat-label", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Product Name");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "add_circle_outline");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "input", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](37, AddProductComponent_mat_error_37_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "mat-form-field", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "mat-label", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Product Price");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, " attach_money");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](44, "input", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](45, AddProductComponent_mat_error_45_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "mat-form-field", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "mat-label", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "Product Brand");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](50, "input", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](51, AddProductComponent_mat_error_51_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "mat-form-field", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "mat-label", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](55, "Choose the purchase date");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](56, "input", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](57, "mat-datepicker-toggle", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "mat-datepicker", null, 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "mat-datepicker-actions");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "button", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "Cancel");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "button", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](64, "Apply");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "mat-form-field", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "mat-label", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](68, "Category");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "mat-select", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "mat-option", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](71, "Mobile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "mat-option", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Laptops");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "mat-option", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](75, "Tablets");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "mat-option", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](77, "TV");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "mat-option", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](79, "Refridgerators");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "mat-option", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, "Washing Machine");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](82, AddProductComponent_mat_error_82_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](84, "mat-divider");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "button", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddProductComponent_Template_button_click_86_listener() {
              return ctx.postProducts();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](87, "Save and Continue");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "mat-step", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "form", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "mat-card", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "mat-card-content");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "p", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](95, "Add Product Description");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "mat-form-field", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "mat-label", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, "Product Condition");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "mat-select", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "mat-option", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](102, "Brand new");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "mat-option", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](104, "Refurbished");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "mat-option", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](106, "Slightly Used");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "mat-option", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](108, "Heavily Used");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "mat-option", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](110, "Unboxed");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](111, AddProductComponent_mat_error_111_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "mat-form-field", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "mat-label", 59);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](115, "Aditional details");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](116, "input", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "mat-form-field", 61);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "mat-label", 62);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Product Description");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](120, "textarea", 63, 64);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "mat-hint");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](124, AddProductComponent_mat_error_124_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 65);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "mat-label", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "strong");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](128, "Add Product Images");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "input", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AddProductComponent_Template_input_change_129_listener($event) {
              return ctx.myFile($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](131, "mat-divider");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "button", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](134, "Previous");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "button", 69);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddProductComponent_Template_button_click_135_listener() {
              return ctx.postProducts();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](136, "Save and Continue");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "mat-step", 70);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "form", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "mat-card", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "mat-card-content");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "p", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](144, "Add Seller Details");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](146, "mat-form-field", 71);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "mat-label", 72);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](148, "Seller Name");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](149, "input", 73);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](150, AddProductComponent_mat_error_150_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "mat-form-field", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "mat-label", 75);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](154, "City");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](156, "location_city");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](157, "input", 76);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](158, AddProductComponent_mat_error_158_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "mat-form-field", 77);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](161, "mat-label", 78);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](162, "Pincode");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](163, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](164, " location_on");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](165, "input", 79);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](166, AddProductComponent_mat_error_166_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](168, "mat-form-field", 80);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](169, "mat-label", 81);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](170, "Seller State");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](171, "mat-select", 82);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](172, "mat-option", 83);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](173, "Andhra Pradesh");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](174, "mat-option", 84);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](175, "Arunachal Pradesh");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](176, "mat-option", 85);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](177, "Assam");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](178, "mat-option", 86);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](179, "Bihar");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](180, "mat-option", 87);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](181, "Chhattisgarh");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](182, "mat-option", 88);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](183, "Delhi");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](184, "mat-option", 89);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](185, "Goa");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](186, "mat-option", 90);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](187, "Gujarat");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](188, "mat-option", 91);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](189, "Haryana");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](190, "mat-option", 92);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](191, "Jharkhand");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](192, "mat-option", 93);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](193, "Karnataka");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](194, "mat-option", 94);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](195, "Kerala");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](196, "mat-option", 95);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](197, "Madhya Pradesh");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](198, "mat-option", 96);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](199, "Maharashtra");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](200, "mat-option", 97);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](201, "Manipur");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](202, "mat-option", 98);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](203, "Meghalaya");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](204, "mat-option", 99);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](205, "Mizoram");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](206, "mat-option", 100);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](207, "Nagaland");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](208, "mat-option", 101);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](209, "Odisha");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](210, "mat-option", 102);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](211, "Punjab");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](212, "mat-option", 103);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](213, "Rajasthan");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](214, "mat-option", 104);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](215, "Sikkim");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](216, "mat-option", 105);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](217, "Tamil Nadu");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](218, "mat-option", 106);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](219, "Telangana");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](220, "mat-option", 107);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](221, "Tripura");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](222, "mat-option", 108);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](223, "Uttar Pradesh");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](224, "mat-option", 109);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](225, "Uttarakhand");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](226, "mat-option", 110);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](227, "West Bengal");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](228, AddProductComponent_mat_error_228_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](229, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](230, "mat-form-field", 111);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](231, "mat-label", 112);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](232, "Email");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](233, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](234, " email");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](235, "input", 113);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](236, AddProductComponent_mat_error_236_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](237, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](238, "mat-form-field", 114);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](239, "mat-label", 115);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](240, "Mobile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](241, "mat-icon", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](242, " phone");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](243, "input", 116);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](244, AddProductComponent_mat_error_244_Template, 2, 0, "mat-error", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](245, "mat-divider");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](246, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](247, "button", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](248, "Previous");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](249, "button", 117);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddProductComponent_Template_button_click_249_listener() {
              return ctx.OnSubmit();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](250, "Submit");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](9);

            var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](59);

            var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](121);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("stepControl", ctx.addProduct)("editable", ctx.isEditable);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.addProduct);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProduct.get("productName").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProduct.get("productPrice").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProduct.get("productBrand").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("max", ctx.today)("matDatepicker", _r5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("for", _r5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProduct.get("category").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.addProduct.invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("stepControl", ctx.addProductDescription)("editable", ctx.isEditable);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.addProductDescription);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProductDescription.get("productCondition").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", _r8.value.length, "/700");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.addProductDescription.get("productDesc").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.addProductDescription.invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.sellerDetails);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("sellerName").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("city").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("sellerPincode").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](62);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("sellerState").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("sellerEmail").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.sellerDetails.get("sellerMobile").invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.sellerDetails.invalid);
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterLink"], _angular_material_button__WEBPACK_IMPORTED_MODULE_8__["MatButton"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuTrigger"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__["MatIcon"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuItem"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_11__["MatHorizontalStepper"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_11__["MatStep"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_12__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_12__["MatCardContent"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultLayoutAlignDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatFormField"], _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_15__["MatTooltip"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatLabel"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatSuffix"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_material_input__WEBPACK_IMPORTED_MODULE_16__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["RequiredValidator"], _angular_common__WEBPACK_IMPORTED_MODULE_17__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NumberValueAccessor"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerInput"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerToggle"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepicker"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerActions"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerCancel"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerApply"], _angular_material_select__WEBPACK_IMPORTED_MODULE_19__["MatSelect"], _angular_material_core__WEBPACK_IMPORTED_MODULE_20__["MatOption"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_21__["MatDivider"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_11__["MatStepperNext"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["MaxLengthValidator"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatHint"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_11__["MatStepperPrevious"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["MinLengthValidator"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatError"]],
        styles: [".toolbar[_ngcontent-%COMP%]{\r\n  background-color: #383a48;\r\nwidth: 100%;\r\ncolor: whitesmoke;\r\n}\r\n.addProduct[_ngcontent-%COMP%]{\r\n  margin:auto;\r\n  width:100%;\r\n}\r\n.example-card[_ngcontent-%COMP%] {\r\n    border-style: solid;\r\n    border: #000 1px solid;\r\n    text-align: center;\r\n    border-radius: 10px;\r\n    width:60vw;\r\n    border:black 2px solid;\r\n    margin:auto;\r\n    padding: 30px;\r\n  }\r\n#heading[_ngcontent-%COMP%]{\r\n    text-align: center;\r\n    font-size: 20px;\r\n  }\r\n[_nghost-%COMP%] {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: flex-start;\r\n    color: black;\r\n  }\r\n#date[_ngcontent-%COMP%]{\r\n   width:inherit;\r\n   \r\n }\r\n#price[_ngcontent-%COMP%]{\r\n  width:20vw;\r\n  padding-right: 10px;\r\n }\r\n#category[_ngcontent-%COMP%]{\r\n   width:50vw;\r\n }\r\n#button[_ngcontent-%COMP%]{\r\n   margin:20px;\r\n }\r\n#condition[_ngcontent-%COMP%]{\r\n  width:50vw;\r\n}\r\n#conditionText[_ngcontent-%COMP%]{\r\n  width:50vw;\r\n}\r\n#textArea[_ngcontent-%COMP%]{\r\nheight: 200px;\r\n}\r\n.AddPhotos[_ngcontent-%COMP%]{\r\n  width:100%;\r\n  padding:20px;\r\n  text-align: center;\r\n}\r\n#imageInput[_ngcontent-%COMP%]{\r\n  padding-left:30px;\r\n}\r\n.spacer[_ngcontent-%COMP%]{\r\n  flex:1 1 auto;\r\n}\r\n.sell-button[_ngcontent-%COMP%]{\r\n  margin-right: 10px;\r\n  padding:0px 20px 0px 20px;\r\n}\r\n.icon[_ngcontent-%COMP%]{\r\n  height:20px;\r\n  display:inline-block;\r\n  font-size: 43px;\r\n  margin-bottom: 20px;\r\n  margin-right: 20px;\r\n}\r\n.Title[_ngcontent-%COMP%] {\r\n  \r\n  font-size: 150%;\r\n  margin-right: 20px;\r\n  margin-left: 10px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1wcm9kdWN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBeUI7QUFDM0IsV0FBVztBQUNYLGlCQUFpQjtBQUNqQjtBQUNBO0VBQ0UsV0FBVztFQUNYLFVBQVU7QUFDWjtBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLFVBQVU7SUFDVixzQkFBc0I7SUFDdEIsV0FBVztJQUNYLGFBQWE7RUFDZjtBQUNBO0lBQ0Usa0JBQWtCO0lBQ2xCLGVBQWU7RUFDakI7QUFDRjtJQUNJLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsdUJBQXVCO0lBQ3ZCLFlBQVk7RUFDZDtBQUVEO0dBQ0UsYUFBYTs7Q0FFZjtBQUNBO0VBQ0MsVUFBVTtFQUNWLG1CQUFtQjtDQUNwQjtBQUNBO0dBQ0UsVUFBVTtDQUNaO0FBRUE7R0FDRSxXQUFXO0NBQ2I7QUFDRDtFQUNFLFVBQVU7QUFDWjtBQUVBO0VBQ0UsVUFBVTtBQUNaO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtFQUNFLFVBQVU7RUFDVixZQUFZO0VBQ1osa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFFQTtFQUNFLGFBQWE7QUFDZjtBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLHlCQUF5QjtBQUMzQjtBQUVBO0VBQ0UsV0FBVztFQUNYLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLGtCQUFrQjtBQUNwQjtBQUVBO0VBQ0UsOENBQThDO0VBQzlDLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsaUJBQWlCO0FBQ25CIiwiZmlsZSI6ImFkZC1wcm9kdWN0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzgzYTQ4O1xyXG53aWR0aDogMTAwJTtcclxuY29sb3I6IHdoaXRlc21va2U7XHJcbn1cclxuLmFkZFByb2R1Y3R7XHJcbiAgbWFyZ2luOmF1dG87XHJcbiAgd2lkdGg6MTAwJTtcclxufVxyXG5cclxuLmV4YW1wbGUtY2FyZCB7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyOiAjMDAwIDFweCBzb2xpZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB3aWR0aDo2MHZ3O1xyXG4gICAgYm9yZGVyOmJsYWNrIDJweCBzb2xpZDtcclxuICAgIG1hcmdpbjphdXRvO1xyXG4gICAgcGFkZGluZzogMzBweDtcclxuICB9XHJcbiAgI2hlYWRpbmd7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgfVxyXG46aG9zdCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gIH0gIFxyXG4gIFxyXG4gI2RhdGV7XHJcbiAgIHdpZHRoOmluaGVyaXQ7XHJcbiAgIFxyXG4gfVxyXG4gI3ByaWNle1xyXG4gIHdpZHRoOjIwdnc7XHJcbiAgcGFkZGluZy1yaWdodDogMTBweDtcclxuIH1cclxuICNjYXRlZ29yeXtcclxuICAgd2lkdGg6NTB2dztcclxuIH1cclxuXHJcbiAjYnV0dG9ue1xyXG4gICBtYXJnaW46MjBweDtcclxuIH1cclxuI2NvbmRpdGlvbntcclxuICB3aWR0aDo1MHZ3O1xyXG59XHJcblxyXG4jY29uZGl0aW9uVGV4dHtcclxuICB3aWR0aDo1MHZ3O1xyXG59XHJcbiN0ZXh0QXJlYXtcclxuaGVpZ2h0OiAyMDBweDtcclxufVxyXG4uQWRkUGhvdG9ze1xyXG4gIHdpZHRoOjEwMCU7XHJcbiAgcGFkZGluZzoyMHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4jaW1hZ2VJbnB1dHtcclxuICBwYWRkaW5nLWxlZnQ6MzBweDtcclxufVxyXG5cclxuLnNwYWNlcntcclxuICBmbGV4OjEgMSBhdXRvO1xyXG59XHJcblxyXG4uc2VsbC1idXR0b257XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIHBhZGRpbmc6MHB4IDIwcHggMHB4IDIwcHg7XHJcbn1cclxuXHJcbi5pY29ue1xyXG4gIGhlaWdodDoyMHB4O1xyXG4gIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogNDNweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxufVxyXG5cclxuLlRpdGxlIHtcclxuICAvKiBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlOyAqL1xyXG4gIGZvbnQtc2l6ZTogMTUwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbn0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AddProductComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-add-product",
            templateUrl: "./add-product.component.html",
            styleUrls: ["./add-product.component.css"]
          }]
        }], function () {
          return [{
            type: _service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__["MyProfileService"]
          }, {
            type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]
          }, {
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
          }, {
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_5__["AppService"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/slide-toggle */
      "jMqV");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/paginator */
      "5QHs");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _angular_material_select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/select */
      "ZTz/");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/grid-list */
      "40+f");
      /* harmony import */


      var _angular_material_list__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/list */
      "SqCe");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_material_table__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/material/table */
      "OaSA");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "omvX");
      /* harmony import */


      var _product_categories_product_categories_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! ./product-categories/product-categories.component */
      "g1F2");
      /* harmony import */


      var _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! ./product-details/product-details.component */
      "ylPK");
      /* harmony import */


      var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
      /*! @angular/material/sidenav */
      "q7Ft");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");
      /* harmony import */


      var _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
      /*! ./chat-service-app/chat-service-app.component */
      "/ZnB");
      /* harmony import */


      var _add_product_add_product_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
      /*! ./add-product/add-product.component */
      "WGIg");
      /* harmony import */


      var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
      /*! @angular/flex-layout */
      "u9T3");
      /* harmony import */


      var _login_login_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
      /*! ./login/login.component */
      "vtpD");
      /* harmony import */


      var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
      /*! @angular/material/tabs */
      "M9ds");
      /* harmony import */


      var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
      /*! @angular/material/stepper */
      "hzfI");
      /* harmony import */


      var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
      /*! @angular/material/tooltip */
      "ZFy/");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
      /*! @angular/material/checkbox */
      "pMoy");
      /* harmony import */


      var _register_user_register_user_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
      /*! ./register-user/register-user.component */
      "MvdQ");
      /* harmony import */


      var _my_profile_my_profile_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
      /*! ./my-profile/my-profile.component */
      "kMBp");
      /* harmony import */


      var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
      /*! @angular/material/datepicker */
      "TN/R");
      /* harmony import */


      var _angular_material_core__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
      /*! @angular/material/core */
      "UhP/");
      /* harmony import */


      var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(
      /*! @angular/material/autocomplete */
      "vrAh");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(
      /*! @angular/material/dialog */
      "iELJ");
      /* harmony import */


      var _add_product_dialog_example_dialog_example_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(
      /*! ./add-product/dialog-example/dialog-example.component */
      "ofsS");
      /* harmony import */


      var _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(
      /*! ./landing-page/landing-page.component */
      "mSt+");
      /* harmony import */


      var _my_products_my_products_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(
      /*! ./my-products/my-products.component */
      "FJfR");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(
      /*! ./chat-bot/chat-bot.component */
      "wY5D");
      /* harmony import */


      var _filter_pipe__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(
      /*! ./filter.pipe */
      "i6q1");
      /* harmony import */


      var _video_service_video_service_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(
      /*! ./video-service/video-service.component */
      "jo2m");

      var AppModule = /*#__PURE__*/_createClass(function AppModule() {
        _classCallCheck(this, AppModule);
      });

      AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
        type: AppModule,
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_17__["AppComponent"]]
      });
      AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
        factory: function AppModule_Factory(t) {
          return new (t || AppModule)();
        },
        providers: [],
        imports: [[_angular_material_tooltip__WEBPACK_IMPORTED_MODULE_29__["MatTooltipModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_37__["MatDialogModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatNativeDateModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatRippleModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_34__["MatDatepickerModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_28__["MatStepperModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_27__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_14__["MatInputModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatFormFieldModule"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__["MatDividerModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_9__["MatSelectModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCardModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbarModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_3__["MatButtonModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__["MatSlideToggleModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__["MatMenuModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_12__["MatListModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_16__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__["BrowserAnimationsModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginatorModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_21__["MatSidenavModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_31__["MatCheckboxModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_36__["MatAutocompleteModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_15__["MatTableModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, {
          declarations: [_app_component__WEBPACK_IMPORTED_MODULE_17__["AppComponent"], _product_categories_product_categories_component__WEBPACK_IMPORTED_MODULE_19__["ProductCategoriesComponent"], _login_login_component__WEBPACK_IMPORTED_MODULE_26__["LoginComponent"], _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_23__["ChatServiceAppComponent"], _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_20__["ProductDetailsComponent"], _register_user_register_user_component__WEBPACK_IMPORTED_MODULE_32__["RegisterUserComponent"], _add_product_add_product_component__WEBPACK_IMPORTED_MODULE_24__["AddProductComponent"], _my_profile_my_profile_component__WEBPACK_IMPORTED_MODULE_33__["MyProfileComponent"], _add_product_dialog_example_dialog_example_component__WEBPACK_IMPORTED_MODULE_38__["DialogExampleComponent"], _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_39__["LandingPageComponent"], _my_products_my_products_component__WEBPACK_IMPORTED_MODULE_40__["MyProductsComponent"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_41__["ChatBotComponent"], _filter_pipe__WEBPACK_IMPORTED_MODULE_42__["FilterPipe"], _video_service_video_service_component__WEBPACK_IMPORTED_MODULE_43__["VideoServiceComponent"]],
          imports: [_angular_material_tooltip__WEBPACK_IMPORTED_MODULE_29__["MatTooltipModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_37__["MatDialogModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatNativeDateModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatRippleModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_34__["MatDatepickerModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_28__["MatStepperModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_27__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_14__["MatInputModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatFormFieldModule"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__["MatDividerModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_9__["MatSelectModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCardModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbarModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_3__["MatButtonModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__["MatSlideToggleModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__["MatMenuModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_12__["MatListModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_16__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__["BrowserAnimationsModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginatorModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_21__["MatSidenavModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_31__["MatCheckboxModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_36__["MatAutocompleteModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_15__["MatTableModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
          args: [{
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_17__["AppComponent"], _product_categories_product_categories_component__WEBPACK_IMPORTED_MODULE_19__["ProductCategoriesComponent"], _login_login_component__WEBPACK_IMPORTED_MODULE_26__["LoginComponent"], _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_23__["ChatServiceAppComponent"], _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_20__["ProductDetailsComponent"], _register_user_register_user_component__WEBPACK_IMPORTED_MODULE_32__["RegisterUserComponent"], _add_product_add_product_component__WEBPACK_IMPORTED_MODULE_24__["AddProductComponent"], _my_profile_my_profile_component__WEBPACK_IMPORTED_MODULE_33__["MyProfileComponent"], _add_product_dialog_example_dialog_example_component__WEBPACK_IMPORTED_MODULE_38__["DialogExampleComponent"], _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_39__["LandingPageComponent"], _my_products_my_products_component__WEBPACK_IMPORTED_MODULE_40__["MyProductsComponent"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_41__["ChatBotComponent"], _filter_pipe__WEBPACK_IMPORTED_MODULE_42__["FilterPipe"], _video_service_video_service_component__WEBPACK_IMPORTED_MODULE_43__["VideoServiceComponent"]],
            entryComponents: [_add_product_dialog_example_dialog_example_component__WEBPACK_IMPORTED_MODULE_38__["DialogExampleComponent"]],
            imports: [_angular_material_tooltip__WEBPACK_IMPORTED_MODULE_29__["MatTooltipModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_37__["MatDialogModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatNativeDateModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_35__["MatRippleModule"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_34__["MatDatepickerModule"], _angular_material_stepper__WEBPACK_IMPORTED_MODULE_28__["MatStepperModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_27__["MatTabsModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_14__["MatInputModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_13__["MatFormFieldModule"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_22__["MatDividerModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_9__["MatSelectModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"], _angular_material_card__WEBPACK_IMPORTED_MODULE_4__["MatCardModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbarModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_3__["MatButtonModule"], _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__["MatSlideToggleModule"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_11__["MatGridListModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_30__["MatMenuModule"], _angular_material_list__WEBPACK_IMPORTED_MODULE_12__["MatListModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_16__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__["BrowserAnimationsModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginatorModule"], _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_21__["MatSidenavModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_31__["MatCheckboxModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_25__["FlexLayoutModule"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_36__["MatAutocompleteModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_15__["MatTableModule"]],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_17__["AppComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "ZguD":
    /*!**************************************************!*\
      !*** ./src/app/model/chat/chat-message.model.ts ***!
      \**************************************************/

    /*! exports provided: ChatMessage */

    /***/
    function ZguD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatMessage", function () {
        return ChatMessage;
      });

      var ChatMessage = /*#__PURE__*/_createClass(function ChatMessage() {
        _classCallCheck(this, ChatMessage);
      });
      /***/

    },

    /***/
    "ais6":
    /*!*************************************************!*\
      !*** ./src/app/model/chat/buyers-chat.model.ts ***!
      \*************************************************/

    /*! exports provided: BuyersChat */

    /***/
    function ais6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BuyersChat", function () {
        return BuyersChat;
      });

      var BuyersChat = /*#__PURE__*/_createClass(function BuyersChat() {
        _classCallCheck(this, BuyersChat);
      });
      /***/

    },

    /***/
    "du5m":
    /*!*******************************************************!*\
      !*** ./src/app/service/register/user-registration.ts ***!
      \*******************************************************/

    /*! exports provided: UserRegistration */

    /***/
    function du5m(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserRegistration", function () {
        return UserRegistration;
      });

      var UserRegistration = /*#__PURE__*/_createClass(function UserRegistration() {
        _classCallCheck(this, UserRegistration);
      });
      /***/

    },

    /***/
    "g1F2":
    /*!********************************************************************!*\
      !*** ./src/app/product-categories/product-categories.component.ts ***!
      \********************************************************************/

    /*! exports provided: ProductCategoriesComponent */

    /***/
    function g1F2(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductCategoriesComponent", function () {
        return ProductCategoriesComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/paginator */
      "5QHs");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../chat-bot/chat-bot.component */
      "wY5D");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");
      /* harmony import */


      var _filter_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ../filter.pipe */
      "i6q1");

      function ProductCategoriesComponent_div_35_div_1_Template(rf, ctx) {
        if (rf & 1) {
          var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card", 27);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ProductCategoriesComponent_div_35_div_1_Template_mat_card_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);

            var productdata_r5 = ctx.$implicit;

            var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r6.saveData(productdata_r5);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 31);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "check_circle");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "mat-card-content", 32);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 33);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "strong", 34);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "strong", 35);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "mat-divider", 36);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 37);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 38);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, " location_on");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 38);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "date_range");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 39);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](29, "date");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var productdata_r5 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("matToolTip", productdata_r5.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", productdata_r5.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" \u20B9", productdata_r5.productPrice, "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r5.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r5.sellerState);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](29, 6, productdata_r5.productdate));
        }
      }

      function ProductCategoriesComponent_div_35_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ProductCategoriesComponent_div_35_div_1_Template, 30, 8, "div", 25);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "filter");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "slice");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind3"](3, 4, ctx_r1.product, ctx_r1.lowValue, ctx_r1.highValue), ctx_r1.searchText));
        }
      }

      function ProductCategoriesComponent_ng_template_38_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("No results found for \"", ctx_r3.searchText, "\".");
        }
      }

      var _c0 = function _c0() {
        return [5, 10, 20, 30];
      };

      var ProductCategoriesComponent = /*#__PURE__*/function () {
        function ProductCategoriesComponent(rs, route, router) {
          _classCallCheck(this, ProductCategoriesComponent);

          this.rs = rs;
          this.route = route;
          this.router = router;
          this.search = "";
          this.product = [];
          this.lowValue = 0;
          this.highValue = 10;
        }

        _createClass(ProductCategoriesComponent, [{
          key: "refresh",
          value: function refresh() {
            this.router.routeReuseStrategy.shouldReuseRoute = function () {
              return false;
            };
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this11 = this;

            this.rs.getproducts().subscribe(function (response) {
              console.log(response);
              var size = response.length;

              for (var i = 0; i < size; i++) {
                // console.log(response.productId[i])
                _this11.product.push(response[i]);

                _this11.product[i].image = "data:image/jpeg;base64," + _this11.product[i].image;
                console.log(_this11.product[0].productId);
                localStorage.setItem("productId", _this11.product[0].productId);
              } //  for(var i=0;i<this.product.length;i++)
              //   {
              //     this.product[i].image = 'data:image/jpeg;base64,' + this.product[i].image;
              //   }


              console.log(_this11.product);
            }, function (error) {
              console.log("Error Occured" + error);
            }); // this.refresh();
          }
        }, {
          key: "saveData",
          value: function saveData(data) {
            localStorage.setItem("sellerEmail", data.sellerEmail);
            localStorage.setItem("productId", data.productId);
            localStorage.setItem("category", data.category);
          } // used to build a slice of papers relevant at any given time

        }, {
          key: "getPaginatorData",
          value: function getPaginatorData(event) {
            this.lowValue = event.pageIndex * event.pageSize;
            this.highValue = this.lowValue + event.pageSize;
            return event;
          }
        }]);

        return ProductCategoriesComponent;
      }();

      ProductCategoriesComponent.ɵfac = function ProductCategoriesComponent_Factory(t) {
        return new (t || ProductCategoriesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]));
      };

      ProductCategoriesComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: ProductCategoriesComponent,
        selectors: [["app-product-categories"]],
        decls: 42,
        vars: 14,
        consts: [[1, "navbar", "navbar", "fixed-top"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], [1, "Title"], [1, "spacer"], [1, "example-form"], [1, "example-full-width"], ["matPrefix", ""], ["type", "tel", "matInput", "", "placeholder", "Search for a product", "name", "search", 3, "ngModel", "ngModelChange"], ["matSuffix", "", "mat-button", ""], ["mat-fab", "", "routerLink", "/addProduct", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["mat-raised-button", "", "routerLink", "/addProduct", "color", "primary", 1, "sellc"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], [1, "menu"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/profile"], ["mat-menu-item", "", "routerLink", "/myProducts"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/login"], [1, "body"], ["pageSize", "10", "showFirstLastButtons", "false", 2, "padding-bottom", "0px", "padding-top", "80px", "background-color", "inherit", "padding-right", "30px", 3, "length", "pageSizeOptions", "page"], ["fxLayout", "row wrap", "fxLayoutGap", "20px grid", "class", "con", "fxLayoutAlign", "start center", 4, "ngIf", "ngIfElse"], ["pageSize", "10", "showFirstLastButtons", "false", 2, "background-color", "inherit", "padding-right", "30px", 3, "length", "pageSizeOptions", "page"], ["noResults", ""], ["fxLayout", "row wrap", "fxLayoutGap", "20px grid", "fxLayoutAlign", "start center", 1, "con"], ["fxFlex", "20%", "fxFlex.xs", "100%", "fxFlex.sm", "50%", 4, "ngFor", "ngForOf"], ["fxFlex", "20%", "fxFlex.xs", "100%", "fxFlex.sm", "50%"], ["routerLink", "/details", 1, "example-card", 3, "matToolTip", "click"], ["fxLayout", "row", "fxLayoutGap", "10px;"], ["fxFlex", "90%", "fxLayoutAlign", "center center"], ["mat-card-image", "", "alt", "Pic of Mobile", 1, "img", 3, "src"], ["fxFlex", "10%"], [1, "text"], ["id", "title", "fxLayout", "column", "fxLayoutAlign", "center start"], [2, "font-size", "25px"], [2, "color", "#9E9E9E"], [1, "divider"], ["fxLayout", "row", "fxLayoutAlign", "space-between", 1, "locationAndDate"], ["fxLayout", "row", "fxLayoutAlign", "center center"], [2, "padding-left", "5px"]],
        template: function ProductCategoriesComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "form", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-form-field", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "span", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "input", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ProductCategoriesComponent_Template_input_ngModelChange_8_listener($event) {
              return ctx.searchText = $event;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "search ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "add");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "a", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "SELL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-icon", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "mat-menu", 13, 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "My Profile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "button", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "My Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "button", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "mat-paginator", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("page", function ProductCategoriesComponent_Template_mat_paginator_page_34_listener($event) {
              return ctx.getPaginatorData($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](35, ProductCategoriesComponent_div_35_Template, 4, 8, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](36, "filter");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "mat-paginator", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("page", function ProductCategoriesComponent_Template_mat_paginator_page_37_listener($event) {
              return ctx.getPaginatorData($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](38, ProductCategoriesComponent_ng_template_38_Template, 2, 1, "ng-template", null, 23, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "app-chat-bot");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](24);

            var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.searchText);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.search, " ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("length", ctx.product.length)("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](12, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](36, 9, ctx.product, ctx.searchText).length > 0)("ngIfElse", _r2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("length", ctx.product.length)("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](13, _c0));
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLink"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatPrefix"], _angular_material_input__WEBPACK_IMPORTED_MODULE_6__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatSuffix"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLinkWithHref"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuTrigger"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuItem"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_10__["MatPaginator"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["NgIf"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_12__["ChatBotComponent"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultLayoutGapDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultLayoutAlignDirective"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["NgForOf"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_13__["DefaultFlexDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_14__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_14__["MatCardImage"], _angular_material_card__WEBPACK_IMPORTED_MODULE_14__["MatCardContent"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_15__["MatDivider"]],
        pipes: [_filter_pipe__WEBPACK_IMPORTED_MODULE_16__["FilterPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["SlicePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["DatePipe"]],
        styles: [".navbar[_ngcontent-%COMP%]{\r\n  background-color: #383a48;\r\nwidth: 100%;\r\ncolor: whitesmoke;\r\ndisplay: flex;\r\n  position: fixed;\r\n}\r\n\r\n.body[_ngcontent-%COMP%]{\r\n  width: 100%;\r\n \r\n  \r\n}\r\n\r\n.con[_ngcontent-%COMP%]{\r\n  margin-left:20px;\r\n  width: 100%;\r\n  padding: 30px;\r\n}\r\n\r\n.example-card[_ngcontent-%COMP%] {\r\n  border: black 2px solid;\r\n  border-radius: 10px;\r\n \r\n  }\r\n\r\n.img[_ngcontent-%COMP%]{\r\n    max-width: 200px;\r\n    width: auto;\r\n    height:150px;\r\n    size: auto;\r\n    margin: auto;\r\n    text-align: center;\r\n    padding: 10px;\r\n  }\r\n\r\n.locationAndDate[_ngcontent-%COMP%]{\r\n  padding-top: 35px;\r\n  font-size: 15px;\r\n}\r\n\r\n.filter[_ngcontent-%COMP%]{\r\n  width:13vw;\r\n  \r\n}\r\n\r\n.filterSort[_ngcontent-%COMP%]{\r\n background-color: white;\r\n padding:30px 30px 0px 30px\r\n}\r\n\r\n#button[_ngcontent-%COMP%]{\r\n  margin-bottom:15px;\r\n}\r\n\r\n#title[_ngcontent-%COMP%]{\r\n  height:20px;\r\n  justify-content: center;\r\n}\r\n\r\n.divider[_ngcontent-%COMP%]{\r\n  margin-top: 25px;\r\n}\r\n\r\n.locDate[_ngcontent-%COMP%]{\r\n  padding-right: 15px;\r\n}\r\n\r\n.text[_ngcontent-%COMP%]{\r\n  padding-top:30px;\r\n}\r\n\r\n.mat-toolbar-single-row[_ngcontent-%COMP%] {\r\n  height: 76px;\r\n  padding: 0;\r\n}\r\n\r\n.mat-toolbar.mat-primary[_ngcontent-%COMP%]{\r\n  background-color: #383a48;\r\n}\r\n\r\n.mat-form-field-appearance-legacy[_ngcontent-%COMP%]   .mat-form-field-wrapper[_ngcontent-%COMP%] {\r\n  padding-bottom: 1.2em;\r\n}\r\n\r\n.categ[_ngcontent-%COMP%]{\r\n  margin-left: 10px;\r\n}\r\n\r\n.mat-form-field[_ngcontent-%COMP%] {\r\n  font-size: medium;\r\n  \r\n}\r\n\r\n\r\n\r\n.navbar-brand[_ngcontent-%COMP%] {\r\n  cursor: pointer;\r\n  margin-left: 10px;\r\n  margin-right: 0px;\r\n}\r\n\r\n.sell-button[_ngcontent-%COMP%]{\r\n  margin-right: 10px;\r\n  padding:0px 20px 0px 20px;\r\n}\r\n\r\n.reg-button[_ngcontent-%COMP%]{\r\n  margin-left:9px;\r\n}\r\n\r\n.example-form[_ngcontent-%COMP%] {\r\n  min-width: 250px;\r\n  max-width: 500px;\r\n  width: 100%;\r\n}\r\n\r\n.example-full-width[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  margin-left: 55px;\r\n  right: 100px;\r\n  margin-bottom: 5px;\r\n}\r\n\r\n.example-input[_ngcontent-%COMP%] {\r\n  max-width: 100%;\r\n  width: 400px;\r\n}\r\n\r\n.example-full-width[_ngcontent-%COMP%]{\r\n  margin: block end 10px; ;\r\n}\r\n\r\n.spacer[_ngcontent-%COMP%]{\r\n  flex:1 1 auto;\r\n}\r\n\r\n.icon[_ngcontent-%COMP%]{\r\n  height:25px;\r\n  display:inline-block;\r\n  font-size: 43px;\r\n  margin-bottom: 20px;\r\n  margin-right: 25px;\r\n  margin-left:-50px;\r\n}\r\n\r\n.menu[_ngcontent-%COMP%]{\r\n    margin-left: 10px;\r\n}\r\n\r\n.Title[_ngcontent-%COMP%] {\r\n  \r\n  font-size: 150%;\r\n  margin-left: 10px;\r\n}\r\n\r\n.sign-button[_ngcontent-%COMP%]{\r\n  margin-right:20px;\r\n  margin-left: -35px;\r\n  \r\n}\r\n\r\n.sellicon[_ngcontent-%COMP%]{\r\n  margin-right:60px;\r\n  z-index: 1;\r\n}\r\n\r\n.sellc[_ngcontent-%COMP%]{\r\n  right: 65px;\r\n  \r\n}\r\n\r\nmat-icon[_ngcontent-%COMP%]{\r\n  margin: 2px;\r\n  cursor:pointer;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtY2F0ZWdvcmllcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UseUJBQXlCO0FBQzNCLFdBQVc7QUFDWCxpQkFBaUI7QUFDakIsYUFBYTtFQUNYLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxXQUFXOzs7QUFHYjs7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsYUFBYTtBQUNmOztBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLG1CQUFtQjs7RUFFbkI7O0FBQ0E7SUFDRSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLFlBQVk7SUFDWixVQUFVO0lBQ1YsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixhQUFhO0VBQ2Y7O0FBRUY7RUFDRSxpQkFBaUI7RUFDakIsZUFBZTtBQUNqQjs7QUFDQTtFQUNFLFVBQVU7O0FBRVo7O0FBQ0E7Q0FDQyx1QkFBdUI7Q0FDdkI7QUFDRDs7QUFDQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFDQTtFQUNFLFdBQVc7RUFDWCx1QkFBdUI7QUFDekI7O0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBQ0E7RUFDRSxtQkFBbUI7QUFDckI7O0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBT0E7RUFDRSxZQUFZO0VBQ1osVUFBVTtBQUNaOztBQUNBO0VBQ0UseUJBQXlCO0FBQzNCOztBQUNBO0VBQ0UscUJBQXFCO0FBQ3ZCOztBQUNBO0VBQ0UsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsaUJBQWlCOztBQUVuQjs7QUFDQTs7Ozs7R0FLRzs7QUFFSDtFQUNFLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsaUJBQWlCO0FBQ25COztBQUdBO0VBQ0Usa0JBQWtCO0VBQ2xCLHlCQUF5QjtBQUMzQjs7QUFDQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLFdBQVc7QUFDYjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsWUFBWTtFQUNaLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixZQUFZO0FBQ2Q7O0FBR0E7RUFDRSxzQkFBc0I7QUFDeEI7O0FBQ0E7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtBQUNuQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQjs7QUFFQTtFQUNFLDhDQUE4QztFQUM5QyxlQUFlO0VBQ2YsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGtCQUFrQjs7QUFFcEI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsVUFBVTtBQUNaOztBQUVBO0VBQ0UsV0FBVzs7QUFFYjs7QUFDQTtFQUNFLFdBQVc7RUFDWCxjQUFjO0FBQ2hCIiwiZmlsZSI6InByb2R1Y3QtY2F0ZWdvcmllcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5hdmJhcntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzgzYTQ4O1xyXG53aWR0aDogMTAwJTtcclxuY29sb3I6IHdoaXRlc21va2U7XHJcbmRpc3BsYXk6IGZsZXg7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG59XHJcblxyXG4uYm9keXtcclxuICB3aWR0aDogMTAwJTtcclxuIFxyXG4gIFxyXG59XHJcbi5jb257XHJcbiAgbWFyZ2luLWxlZnQ6MjBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAzMHB4O1xyXG59XHJcblxyXG4uZXhhbXBsZS1jYXJkIHtcclxuICBib3JkZXI6IGJsYWNrIDJweCBzb2xpZDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gXHJcbiAgfVxyXG4gIC5pbWd7XHJcbiAgICBtYXgtd2lkdGg6IDIwMHB4O1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBoZWlnaHQ6MTUwcHg7XHJcbiAgICBzaXplOiBhdXRvO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICB9XHJcblxyXG4ubG9jYXRpb25BbmREYXRle1xyXG4gIHBhZGRpbmctdG9wOiAzNXB4O1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4uZmlsdGVye1xyXG4gIHdpZHRoOjEzdnc7XHJcbiAgXHJcbn1cclxuLmZpbHRlclNvcnR7XHJcbiBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuIHBhZGRpbmc6MzBweCAzMHB4IDBweCAzMHB4XHJcbn1cclxuI2J1dHRvbntcclxuICBtYXJnaW4tYm90dG9tOjE1cHg7XHJcbn1cclxuI3RpdGxle1xyXG4gIGhlaWdodDoyMHB4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbi5kaXZpZGVye1xyXG4gIG1hcmdpbi10b3A6IDI1cHg7XHJcbn1cclxuLmxvY0RhdGV7XHJcbiAgcGFkZGluZy1yaWdodDogMTVweDtcclxufVxyXG4udGV4dHtcclxuICBwYWRkaW5nLXRvcDozMHB4O1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbi5tYXQtdG9vbGJhci1zaW5nbGUtcm93IHtcclxuICBoZWlnaHQ6IDc2cHg7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG4ubWF0LXRvb2xiYXIubWF0LXByaW1hcnl7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM4M2E0ODtcclxufVxyXG4ubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1sZWdhY3kgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXIge1xyXG4gIHBhZGRpbmctYm90dG9tOiAxLjJlbTtcclxufVxyXG4uY2F0ZWd7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgZm9udC1zaXplOiBtZWRpdW07XHJcbiAgXHJcbn1cclxuLyogLm5hdmJhciB7XHJcbiAgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgXHJcbn0gKi9cclxuXHJcbi5uYXZiYXItYnJhbmQge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBtYXJnaW4tbGVmdDogMTBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDBweDtcclxufVxyXG5cclxuXHJcbi5zZWxsLWJ1dHRvbntcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgcGFkZGluZzowcHggMjBweCAwcHggMjBweDtcclxufVxyXG4ucmVnLWJ1dHRvbntcclxuICBtYXJnaW4tbGVmdDo5cHg7XHJcbn1cclxuXHJcbi5leGFtcGxlLWZvcm0ge1xyXG4gIG1pbi13aWR0aDogMjUwcHg7XHJcbiAgbWF4LXdpZHRoOiA1MDBweDtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmV4YW1wbGUtZnVsbC13aWR0aCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDU1cHg7XHJcbiAgcmlnaHQ6IDEwMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG5cclxuLmV4YW1wbGUtaW5wdXQge1xyXG4gIG1heC13aWR0aDogMTAwJTtcclxuICB3aWR0aDogNDAwcHg7XHJcbn1cclxuXHJcblxyXG4uZXhhbXBsZS1mdWxsLXdpZHRoe1xyXG4gIG1hcmdpbjogYmxvY2sgZW5kIDEwcHg7IDtcclxufVxyXG4uc3BhY2Vye1xyXG4gIGZsZXg6MSAxIGF1dG87XHJcbn1cclxuXHJcbi5pY29ue1xyXG4gIGhlaWdodDoyNXB4O1xyXG4gIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogNDNweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjVweDtcclxuICBtYXJnaW4tbGVmdDotNTBweDtcclxufVxyXG5cclxuLm1lbnV7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLlRpdGxlIHtcclxuICAvKiBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlOyAqL1xyXG4gIGZvbnQtc2l6ZTogMTUwJTtcclxuICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLnNpZ24tYnV0dG9ue1xyXG4gIG1hcmdpbi1yaWdodDoyMHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAtMzVweDtcclxuICBcclxufVxyXG5cclxuLnNlbGxpY29ue1xyXG4gIG1hcmdpbi1yaWdodDo2MHB4O1xyXG4gIHotaW5kZXg6IDE7XHJcbn1cclxuXHJcbi5zZWxsY3tcclxuICByaWdodDogNjVweDtcclxuICBcclxufVxyXG5tYXQtaWNvbntcclxuICBtYXJnaW46IDJweDtcclxuICBjdXJzb3I6cG9pbnRlcjtcclxufSJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProductCategoriesComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-product-categories",
            templateUrl: "./product-categories.component.html",
            styleUrls: ["./product-categories.component.css"]
          }]
        }], function () {
          return [{
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "i6q1":
    /*!********************************!*\
      !*** ./src/app/filter.pipe.ts ***!
      \********************************/

    /*! exports provided: FilterPipe */

    /***/
    function i6q1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FilterPipe", function () {
        return FilterPipe;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var FilterPipe = /*#__PURE__*/function () {
        function FilterPipe() {
          _classCallCheck(this, FilterPipe);
        }

        _createClass(FilterPipe, [{
          key: "transform",
          value: function transform(items, searchText) {
            if (!items) return [];
            if (!searchText) return items;
            return items.filter(function (item) {
              return Object.keys(item).some(function (key) {
                return String(item[key]).toLowerCase().includes(searchText.toLowerCase());
              });
            });
          }
        }]);

        return FilterPipe;
      }();

      FilterPipe.ɵfac = function FilterPipe_Factory(t) {
        return new (t || FilterPipe)();
      };

      FilterPipe.ɵpipe = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
        name: "filter",
        type: FilterPipe,
        pure: true
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FilterPipe, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"],
          args: [{
            name: 'filter'
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "iYH4":
    /*!**********************************************************!*\
      !*** ./src/app/service/my-profile/my-profile.service.ts ***!
      \**********************************************************/

    /*! exports provided: MyProfileService */

    /***/
    function iYH4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MyProfileService", function () {
        return MyProfileService;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");

      var MyProfileService = /*#__PURE__*/function () {
        function MyProfileService(httpClient) {
          _classCallCheck(this, MyProfileService);

          this.httpClient = httpClient;
        }

        _createClass(MyProfileService, [{
          key: "userProfile",
          value: function userProfile() {
            return this.httpClient.get("https://swapon.stackroute.io/authentication-service/api/v1/byEmail/" + localStorage.getItem("buyerEmail"));
          }
        }, {
          key: "updateProfile",
          value: function updateProfile(regData) {
            return this.httpClient.put("https://swapon.stackroute.io/authentication-service/api/v1/update/" + localStorage.getItem("buyerEmail"), regData);
          }
        }]);

        return MyProfileService;
      }();

      MyProfileService.ɵfac = function MyProfileService_Factory(t) {
        return new (t || MyProfileService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]));
      };

      MyProfileService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
        token: MyProfileService,
        factory: MyProfileService.ɵfac,
        providedIn: "root"
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MyProfileService, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
          args: [{
            providedIn: "root"
          }]
        }], function () {
          return [{
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "jo2m":
    /*!**********************************************************!*\
      !*** ./src/app/video-service/video-service.component.ts ***!
      \**********************************************************/

    /*! exports provided: VideoServiceComponent */

    /***/
    function jo2m(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "VideoServiceComponent", function () {
        return VideoServiceComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _videosdk_live_rtc_js_prebuilt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @videosdk.live/rtc-js-prebuilt */
      "WhQE");
      /* harmony import */


      var _videosdk_live_rtc_js_prebuilt__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_videosdk_live_rtc_js_prebuilt__WEBPACK_IMPORTED_MODULE_2__);
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../app.component */
      "Sy1n");

      var VideoServiceComponent = /*#__PURE__*/function () {
        function VideoServiceComponent() {
          _classCallCheck(this, VideoServiceComponent);
        }

        _createClass(VideoServiceComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
              var apiKey, meetingId, name, config, meeting;
              return _regeneratorRuntime().wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      apiKey = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].VIDEOSDK_API_KEY;
                      meetingId = 'milk';
                      name = '';
                      config = {
                        name: name,
                        meetingId: meetingId,
                        apiKey: apiKey,
                        region: "sg001",
                        containerId: null,
                        redirectOnLeave: "https://www.videosdk.live/",
                        micEnabled: true,
                        webcamEnabled: true,
                        participantCanToggleSelfWebcam: true,
                        participantCanToggleSelfMic: true,
                        participantCanLeave: true,
                        chatEnabled: true,
                        screenShareEnabled: true,
                        pollEnabled: true,
                        whiteboardEnabled: true,
                        raiseHandEnabled: true,
                        recording: {
                          autoStart: true,
                          enabled: true,
                          webhookUrl: "https://www.videosdk.live/callback",
                          awsDirPath: "/meeting-recordings/".concat(meetingId, "/")
                        },
                        livestream: {
                          autoStart: true,
                          enabled: true
                        },
                        layout: {
                          type: "SPOTLIGHT",
                          priority: "PIN"
                        },
                        branding: {
                          enabled: true,
                          logoURL: "https://www.citypng.com/public/uploads/preview/video-camera-recording-purple-icon-png-11640206827sxkoh6wwgk.png",
                          name: "SwapOn",
                          poweredBy: false
                        },
                        permissions: {
                          pin: true,
                          askToJoin: false,
                          toggleParticipantMic: true,
                          toggleParticipantWebcam: true,
                          drawOnWhiteboard: true,
                          toggleWhiteboard: true,
                          toggleRecording: true,
                          toggleLivestream: true,
                          removeParticipant: true,
                          endMeeting: true,
                          changeLayout: true
                        },
                        joinScreen: {
                          visible: true,
                          title: "Meeting Link",
                          meetingUrl: window.location.href
                        },
                        leftScreen: {
                          // visible when redirect on leave not provieded
                          actionButton: {
                            // optional action button
                            label: "Video SDK Live",
                            href: "https://videosdk.live/"
                          }
                        },
                        notificationSoundEnabled: true,
                        debug: true,
                        maxResolution: "sd"
                      };
                      meeting = new _videosdk_live_rtc_js_prebuilt__WEBPACK_IMPORTED_MODULE_2__["VideoSDKMeeting"]();
                      meeting.init(config);

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee);
            }));
          }
        }]);

        return VideoServiceComponent;
      }();

      VideoServiceComponent.ɵfac = function VideoServiceComponent_Factory(t) {
        return new (t || VideoServiceComponent)();
      };

      VideoServiceComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
        type: VideoServiceComponent,
        selectors: [["app-video-services"]],
        decls: 10,
        vars: 0,
        consts: [["lang", "en"], ["charset", "utf-8"], ["href", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtrustConstantResourceUrl"]("/")], ["name", "viewport", "content", "width=device-width, initial-scale=1"], ["rel", "icon", "type", "image/x-icon", "href", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtrustConstantResourceUrl"]("favicon.ico")]],
        template: function VideoServiceComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "html", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "head");

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "meta", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "title");

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Chat Video Service");

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "base", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "meta", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "link", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "body");

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "app-root");

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          }
        },
        directives: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aWRlby1zZXJ2aWNlLmNvbXBvbmVudC5jc3MifQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](VideoServiceComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
          args: [{
            selector: 'app-video-services',
            templateUrl: './video-service.component.html',
            styleUrls: ['./video-service.component.css']
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "kMBp":
    /*!****************************************************!*\
      !*** ./src/app/my-profile/my-profile.component.ts ***!
      \****************************************************/

    /*! exports provided: MyProfileComponent */

    /***/
    function kMBp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MyProfileComponent", function () {
        return MyProfileComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _service_register_user_registration__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../service/register/user-registration */
      "du5m");
      /* harmony import */


      var _service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../service/my-profile/my-profile.service */
      "iYH4");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ../chat-bot/chat-bot.component */
      "wY5D");

      var MyProfileComponent = /*#__PURE__*/function () {
        function MyProfileComponent(myProfile, formBuilder, dom) {
          _classCallCheck(this, MyProfileComponent);

          this.myProfile = myProfile;
          this.formBuilder = formBuilder;
          this.dom = dom;
          this.search = "";
          this.reg = new _service_register_user_registration__WEBPACK_IMPORTED_MODULE_2__["UserRegistration"]();
          this.profileFormGroup = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            image: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            firstname: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            contactNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            street: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            city: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            state: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
            pincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("")
          });
        }

        _createClass(MyProfileComponent, [{
          key: "myProfileDetails",
          value: function myProfileDetails() {
            var _this12 = this;

            this.myProfile.userProfile().subscribe(function (response) {
              console.log("This is logged in User Details", response);
              _this12.details = response;
              console.log(_this12.details);

              _this12.profileFormGroup.patchValue({
                email: _this12.details.email,
                firstname: _this12.details.firstname,
                contactNo: _this12.details.contactNo,
                street: _this12.details.street,
                city: _this12.details.city,
                state: _this12.details.state,
                pincode: _this12.details.pincode
              }); // this.profile.image=this.dom.bypassSecurityTrustResourceUrl('data:image/jepg;base64,'+this.profile.image);

            });
          }
        }, {
          key: "onProfile",
          value: function onProfile() {
            console.log(this.profileFormGroup.value);
            console.log(this.profileFormGroup.value.email);
            this.profileForm = this.profileFormGroup.value;
            this.reg.firstname = this.profileFormGroup.value.firstname;
            this.reg.contactNo = this.profileFormGroup.value.contactNo;
            this.reg.email = this.profileFormGroup.value.email;
            this.reg.street = this.profileFormGroup.value.street;
            this.reg.city = this.profileFormGroup.value.city;
            this.reg.state = this.profileFormGroup.value.state;
            this.reg.pincode = this.profileFormGroup.value.pincode;
            console.log(this.reg.email);
            this.myProfile.updateProfile(this.reg).subscribe(function (response) {
              console.log(response);
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.myProfileDetails();
          }
        }, {
          key: "ngOnChanges",
          value: function ngOnChanges() {
            window.location.reload();
          }
        }, {
          key: "getUserDetails",
          value: function getUserDetails(email) {
            var _this13 = this;

            this.myProfile.updateProfile(email).subscribe(function (response) {
              console.log("This is user", response);
              console.log(response[0].name);
              _this13.details = response;

              _this13.profileFormGroup.patchValue({
                email: _this13.details[0].email,
                firstname: _this13.details[0].firstname,
                contactNo: _this13.details[0].contactNo,
                street: _this13.details[0].street,
                city: _this13.details[0].city,
                state: _this13.details[0].state,
                pincode: _this13.details[0].pincode
              });
            });
          }
        }]);

        return MyProfileComponent;
      }();

      MyProfileComponent.ɵfac = function MyProfileComponent_Factory(t) {
        return new (t || MyProfileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__["MyProfileService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"]));
      };

      MyProfileComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: MyProfileComponent,
        selectors: [["app-my-profile"]],
        features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
        decls: 78,
        vars: 3,
        consts: [["fxLayout", "row wrap", "fxLayout.xs", "column", "fxLayoutAlign", "center center", 1, "content"], [1, "navbar", "navbar", "fixed-top"], ["fxLayoutAlign", "space-between center"], ["mat-button", "", 3, "routerLink"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], ["routerLink", "/", 1, "Title"], [1, "spacer"], ["mat-fab", "", "routerLink", "/addProduct", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["mat-raised-button", "", "routerLink", "/addProduct", "color", "primary", 1, "sellc"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/showProduct"], ["mat-menu-item", "", "routerLink", "/myProducts"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/login"], [1, "container"], ["fxlayout", "row wrap", "fxLayout.xs", "column", "fxLayoutAlign", "space-around center", "fxLayoutGap", "10px grid"], ["fxFlex", "50%", 1, "A1"], [1, "text-center"], ["src", "./assets/images/profile.jpg", "alt", "Add profile Photo", 1, "profile-image"], [1, "mt20", "text-center", "name"], ["fxFlex", "50%", 1, "A2"], ["fxLayout", "column", 1, "example-form", "text-center", 3, "formGroup", "ngSubmit"], [1, "mt20", "text-center"], [1, "example-full-width"], ["matInput", "", "formControlName", "firstname", "placeholder", "Name"], ["disabled", "true", "matInput", "", "formControlName", "email", "placeholder", "Email"], ["matInput", "", "formControlName", "contactNo", "placeholder", "ContactNo"], ["matInput", "", "formControlName", "street", "placeholder", "your Street"], ["matInput", "", "formControlName", "city", "placeholder", "Your City"], ["matInput", "", "formControlName", "state", "placeholder", "Your State"], ["matInput", "", "formControlName", "pincode", "placeholder", "Your Pincode"], ["type", "submit", "mat-raised-button", ""]],
        template: function MyProfileComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-toolbar", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-toolbar-row", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "add");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "a", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "SELL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-icon", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "mat-menu", null, 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "All Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "My Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "button", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "img", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "h1", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " Profile Photo ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "mat-card");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "form", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function MyProfileComponent_Template_form_ngSubmit_38_listener() {
              return ctx.onProfile();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "h1", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "i");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "u");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Personal Details");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Name");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "input", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "email");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](50, "input", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "contactNo");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](54, "input", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "h1", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "i");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "u");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58, " Address Details ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "Street");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](62, "input", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65, "City");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](66, "input", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](69, "State");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "input", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "mat-form-field", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Pincode");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "input", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "button", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](76, "Submit");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](77, "app-chat-bot");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", "/");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.profileFormGroup);
          }
        },
        directives: [_angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_5__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_5__["DefaultLayoutAlignDirective"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__["MatToolbar"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_6__["MatToolbarRow"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["RouterLink"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["RouterLinkWithHref"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_10__["MatMenuTrigger"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_10__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_10__["MatMenuItem"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_5__["DefaultLayoutGapDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_5__["DefaultFlexDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCard"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_13__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_14__["ChatBotComponent"]],
        styles: [".Title[_ngcontent-%COMP%] {\r\n    \r\n    font-size: 220%;\r\n    \r\n    \r\n  }\r\n.navbar[_ngcontent-%COMP%]{\r\n    background: #383a48;\r\n    \r\n    \r\n    color: white;\r\n}\r\n.content[_ngcontent-%COMP%]{\r\n    margin-top:5rem;\r\n  }\r\n.logo[_ngcontent-%COMP%]{\r\n      padding: 0px 5px;\r\n      font-size: 20px;\r\n  }\r\n.flex[_ngcontent-%COMP%]{\r\n      margin-bottom: 1rem;\r\n      \r\n  }\r\n\r\n.image[_ngcontent-%COMP%]{\r\n      margin-top: 3rem;\r\n      margin-left: 1rem;\r\n      align-items: center;\r\n      -o-object-fit: cover;\r\n         object-fit: cover;\r\n      width: 80%;\r\n      height: 100%;\r\n  }\r\n.cardi[_ngcontent-%COMP%]{\r\n      margin-top: 1rem;\r\n      align-items: center;\r\n      -o-object-fit: cover;\r\n         object-fit: cover;\r\n      width: 100%;\r\n      height: 100%;\r\n  }\r\nmat-card[_ngcontent-%COMP%]{\r\n  \r\n      align-items: center;\r\n      background: rgb(248, 242, 242);\r\n      \r\n  }\r\n.sell-button[_ngcontent-%COMP%]{\r\n    margin-right: 2rem;\r\n  }\r\n\r\n.profile-image[_ngcontent-%COMP%]{\r\n    max-width: 350px;\r\n    max-height:350px;\r\n    border: 2px solid #383a48;\r\n    border-radius: 50%;\r\n}\r\n.table[_ngcontent-%COMP%]{\r\n    width:100%\r\n    \r\n}\r\n.table[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{\r\n    padding:15px 10px;\r\n    \r\n    border-collapse: collapse;\r\n    font-size: 150%;\r\n}\r\n.name[_ngcontent-%COMP%]{\r\n    font-size: 200%;\r\n    margin-top: 10px;\r\n}\r\n.icon[_ngcontent-%COMP%]{\r\n  height:25px;\r\n  display:inline-block;\r\n  font-size: 43px;\r\n  margin-bottom: 20px;\r\n  margin-right: 25px;\r\n  margin-left:-50px;\r\n}\r\n.example-form[_ngcontent-%COMP%]{\r\n    margin-left: 20px;\r\n  }\r\n.example-form[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{\r\n    font-size: 150%;\r\n  }\r\n.A2[_ngcontent-%COMP%]{\r\n    margin-top: 2rem;\r\n  }\r\n.button[_ngcontent-%COMP%]{\r\n    background: #383a48;\r\n    color: white;\r\n    font-size: 20px;\r\n  }\r\n.sign-button[_ngcontent-%COMP%]{\r\n    margin-right:20px;\r\n    margin-left: -35px;\r\n    \r\n  }\r\n.sellicon[_ngcontent-%COMP%]{\r\n    margin-right:60px;\r\n    z-index: 1;\r\n  }\r\n.sellc[_ngcontent-%COMP%]{\r\n    right: 65px;\r\n    \r\n  }\r\nmat-icon[_ngcontent-%COMP%]{\r\n    margin: 2px;\r\n    cursor:pointer;\r\n  }\r\n.mat-button[_ngcontent-%COMP%]{\r\n    padding:0;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LXByb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0E7SUFDSSw4Q0FBOEM7SUFDOUMsZUFBZTtJQUNmLHdCQUF3QjtJQUN4QixzQkFBc0I7RUFDeEI7QUFDRjtJQUNJLG1CQUFtQjtJQUNuQixpQkFBaUI7SUFDakIscUJBQXFCO0lBQ3JCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLGVBQWU7RUFDakI7QUFDQTtNQUNJLGdCQUFnQjtNQUNoQixlQUFlO0VBQ25CO0FBR0E7TUFDSSxtQkFBbUI7TUFDbkIsZ0JBQWdCO0VBQ3BCO0FBQ0E7O0tBRUc7QUFDSDtNQUNJLGdCQUFnQjtNQUNoQixpQkFBaUI7TUFDakIsbUJBQW1CO01BQ25CLG9CQUFpQjtTQUFqQixpQkFBaUI7TUFDakIsVUFBVTtNQUNWLFlBQVk7RUFDaEI7QUFDQTtNQUNJLGdCQUFnQjtNQUNoQixtQkFBbUI7TUFDbkIsb0JBQWlCO1NBQWpCLGlCQUFpQjtNQUNqQixXQUFXO01BQ1gsWUFBWTtFQUNoQjtBQUNBOztNQUVJLG1CQUFtQjtNQUNuQiw4QkFBOEI7TUFDOUI7cUJBQ2U7RUFDbkI7QUFDQTtJQUNFLGtCQUFrQjtFQUNwQjtBQUVBLGdCQUFnQjtBQUVoQjtJQUNFLGdCQUFnQjtJQUNoQixnQkFBZ0I7SUFDaEIseUJBQXlCO0lBQ3pCLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0k7O0FBRUo7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixpQ0FBaUM7SUFDakMseUJBQXlCO0lBQ3pCLGVBQWU7QUFDbkI7QUFDQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7QUFDcEI7QUFDQTtFQUNFLFdBQVc7RUFDWCxvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsaUJBQWlCO0FBQ25CO0FBQ0U7SUFDRSxpQkFBaUI7RUFDbkI7QUFDQTtJQUNFLGVBQWU7RUFDakI7QUFDQTtJQUNFLGdCQUFnQjtFQUNsQjtBQUNBO0lBQ0UsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixlQUFlO0VBQ2pCO0FBRUE7SUFDRSxpQkFBaUI7SUFDakIsa0JBQWtCOztFQUVwQjtBQUVBO0lBQ0UsaUJBQWlCO0lBQ2pCLFVBQVU7RUFDWjtBQUVBO0lBQ0UsV0FBVzs7RUFFYjtBQUNBO0lBQ0UsV0FBVztJQUNYLGNBQWM7RUFDaEI7QUFDQTtJQUNFLFNBQVM7RUFDWCIsImZpbGUiOiJteS1wcm9maWxlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLlRpdGxlIHtcclxuICAgIC8qIGZvbnQtZmFtaWx5OiAnUnViaWsgRGlzdHJlc3NlZCcsIGN1cnNpdmU7ICovXHJcbiAgICBmb250LXNpemU6IDIyMCU7XHJcbiAgICAvKiBtYXJnaW4tcmlnaHQ6IDIwcHg7ICovXHJcbiAgICAvKiBtYXJnaW4tbGVmdDogMHB4OyAqL1xyXG4gIH1cclxuLm5hdmJhcntcclxuICAgIGJhY2tncm91bmQ6ICMzODNhNDg7XHJcbiAgICAvKiB3aWR0aDogMTAwJTsgKi9cclxuICAgIC8qIG1hcmdpbi1sZWZ0OiAwcHggKi9cclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uY29udGVudHtcclxuICAgIG1hcmdpbi10b3A6NXJlbTtcclxuICB9XHJcbiAgLmxvZ297XHJcbiAgICAgIHBhZGRpbmc6IDBweCA1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICB9XHJcblxyXG4gIFxyXG4gIC5mbGV4e1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG4gICAgICAvKiB3aWR0aDogOTAlOyAqL1xyXG4gIH1cclxuICAvKiBwe1xyXG4gICAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgfSAqL1xyXG4gIC5pbWFnZXtcclxuICAgICAgbWFyZ2luLXRvcDogM3JlbTtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICB3aWR0aDogODAlO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgfVxyXG4gIC5jYXJkaXtcclxuICAgICAgbWFyZ2luLXRvcDogMXJlbTtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgfVxyXG4gIG1hdC1jYXJke1xyXG4gIFxyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBiYWNrZ3JvdW5kOiByZ2IoMjQ4LCAyNDIsIDI0Mik7XHJcbiAgICAgIC8qIHdpZHRoOiAxMDAlO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7ICovXHJcbiAgfVxyXG4gIC5zZWxsLWJ1dHRvbntcclxuICAgIG1hcmdpbi1yaWdodDogMnJlbTtcclxuICB9XHJcblxyXG4gIC8qIGxhc3QgZGVzaWduICovXHJcblxyXG4gIC5wcm9maWxlLWltYWdle1xyXG4gICAgbWF4LXdpZHRoOiAzNTBweDtcclxuICAgIG1heC1oZWlnaHQ6MzUwcHg7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMzgzYTQ4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcbi50YWJsZXtcclxuICAgIHdpZHRoOjEwMCVcclxuICAgIFxyXG59XHJcblxyXG4udGFibGUgdHIgdGR7XHJcbiAgICBwYWRkaW5nOjE1cHggMTBweDtcclxuICAgIC8qIGJvcmRlcjogMC40cHggc29saWQgIzM4M2E0ODsgKi9cclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICBmb250LXNpemU6IDE1MCU7XHJcbn1cclxuLm5hbWV7XHJcbiAgICBmb250LXNpemU6IDIwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcbi5pY29ue1xyXG4gIGhlaWdodDoyNXB4O1xyXG4gIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogNDNweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjVweDtcclxuICBtYXJnaW4tbGVmdDotNTBweDtcclxufVxyXG4gIC5leGFtcGxlLWZvcm17XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICB9XHJcbiAgLmV4YW1wbGUtZm9ybSBpbnB1dHtcclxuICAgIGZvbnQtc2l6ZTogMTUwJTtcclxuICB9XHJcbiAgLkEye1xyXG4gICAgbWFyZ2luLXRvcDogMnJlbTtcclxuICB9XHJcbiAgLmJ1dHRvbntcclxuICAgIGJhY2tncm91bmQ6ICMzODNhNDg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgfVxyXG5cclxuICAuc2lnbi1idXR0b257XHJcbiAgICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMzVweDtcclxuICAgIFxyXG4gIH1cclxuICBcclxuICAuc2VsbGljb257XHJcbiAgICBtYXJnaW4tcmlnaHQ6NjBweDtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgfVxyXG4gIFxyXG4gIC5zZWxsY3tcclxuICAgIHJpZ2h0OiA2NXB4O1xyXG4gICAgXHJcbiAgfVxyXG4gIG1hdC1pY29ue1xyXG4gICAgbWFyZ2luOiAycHg7XHJcbiAgICBjdXJzb3I6cG9pbnRlcjtcclxuICB9XHJcbiAgLm1hdC1idXR0b257XHJcbiAgICBwYWRkaW5nOjA7XHJcbiAgfSJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MyProfileComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-my-profile",
            templateUrl: "./my-profile.component.html",
            styleUrls: ["./my-profile.component.css"]
          }]
        }], function () {
          return [{
            type: _service_my_profile_my_profile_service__WEBPACK_IMPORTED_MODULE_3__["MyProfileService"]
          }, {
            type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]
          }, {
            type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "l2D2":
    /*!**************************************************************************!*\
      !*** ./src/app/service/recommendation/recommendation-service.service.ts ***!
      \**************************************************************************/

    /*! exports provided: RecommendationServiceService */

    /***/
    function l2D2(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RecommendationServiceService", function () {
        return RecommendationServiceService;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");

      var RecommendationServiceService = /*#__PURE__*/function () {
        function RecommendationServiceService(httpClient) {
          _classCallCheck(this, RecommendationServiceService);

          this.httpClient = httpClient;
        }

        _createClass(RecommendationServiceService, [{
          key: "getAllProduct",
          value: function getAllProduct() {
            return this.httpClient.get('http://localhost:8085/api/v1/productByCategory/' + localStorage.getItem("category"));
          }
        }]);

        return RecommendationServiceService;
      }();

      RecommendationServiceService.ɵfac = function RecommendationServiceService_Factory(t) {
        return new (t || RecommendationServiceService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]));
      };

      RecommendationServiceService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
        token: RecommendationServiceService,
        factory: RecommendationServiceService.ɵfac,
        providedIn: 'root'
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](RecommendationServiceService, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
          args: [{
            providedIn: 'root'
          }]
        }], function () {
          return [{
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "mSt+":
    /*!********************************************************!*\
      !*** ./src/app/landing-page/landing-page.component.ts ***!
      \********************************************************/

    /*! exports provided: LandingPageComponent */

    /***/
    function mSt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LandingPageComponent", function () {
        return LandingPageComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../chat-bot/chat-bot.component */
      "wY5D");

      var LandingPageComponent = /*#__PURE__*/function () {
        function LandingPageComponent() {
          _classCallCheck(this, LandingPageComponent);

          this.control = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('');
          this.languages = [{
            value: 'HINDI-1',
            viewValue: 'HINDI'
          }, {
            value: 'ENGLISH-0',
            viewValue: 'ENGLISH'
          }, {
            value: 'HINDI-1',
            viewValue: 'HINDI'
          }];
          this.color = "accent";
          this.color1 = "accent";
          this.color2 = "accent";
        }

        _createClass(LandingPageComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "scrollToTop",
          value: function scrollToTop() {
            window.scroll({
              top: 0,
              left: 0,
              behavior: 'smooth'
            });
          }
        }, {
          key: "scrollToDown",
          value: function scrollToDown() {
            window.scroll({
              top: 5000,
              left: 0,
              behavior: 'smooth'
            });
          }
        }, {
          key: "scrollToBottom",
          value: function scrollToBottom() {
            window.scroll({
              top: 1650,
              left: 0,
              behavior: 'smooth'
            });
          }
        }]);

        return LandingPageComponent;
      }();

      LandingPageComponent.ɵfac = function LandingPageComponent_Factory(t) {
        return new (t || LandingPageComponent)();
      };

      LandingPageComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: LandingPageComponent,
        selectors: [["app-landing-page"]],
        decls: 257,
        vars: 1,
        consts: [["data-spy", "scroll", "data-target", ".navbar", "data-offset", "50"], [1, "navbar", "navbar", "fixed-top"], ["fxLayoutAlign", "space-between center"], ["mat-button", "", 3, "routerLink"], ["src", "assets/obj1.png", "routerLink", "", "width", "45", "height", "45", "alt", "logo", 1, "d-inline-block", "navbar-brand"], ["routerLink", "", 1, "Title"], [1, "example-button-row"], ["mat-button", "", "href", "#", 2, "font-size", "13px", 3, "click"], [1, "spacer"], ["mat-fab", "", "routerLink", "/login", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["mat-raised-button", "", "routerLink", "/login", "color", "primary", 1, "sellc1"], ["mat-raised-button", "", "routerLink", "/login", "color", "primary", 1, "sellc"], ["data-ride", "carousel", 1, "carousel", "slide"], ["id", "header-carousel", "data-bs-ride", "carousel", 1, "carousel", "slide", "carousel-fade"], [1, "carousel-inner"], [1, "carousel-item", "active"], ["src", "assets/img2.webp", "alt", "Image", 1, "w-100", 2, "height", "80vh"], [1, "carousel-caption", "d-flex", "flex-column", "align-items-center", "justify-content-center"], [1, "p-3", 2, "max-width", "900px"], [1, "display-1", "text-white", "mb-md-4", "animated", "zoomIn", "heading"], [1, "text-white", "text-uppercase", "mb-3", "animated", "slideInDown"], [1, "carousel-item"], ["src", "assets/img1.jpeg", "alt", "Image", 1, "w-100", 2, "height", "80vh"], ["src", "assets/b2.jpg", "alt", "Image", 1, "w-100", 2, "height", "80vh"], ["src", "assets/b6.jpg", "alt", "Image", 1, "w-100", 2, "height", "80vh"], ["type", "button", "data-bs-target", "#header-carousel", "data-bs-slide", "prev", 1, "carousel-control-prev"], ["aria-hidden", "true", 1, "carousel-control-prev-icon"], [1, "visually-hidden"], ["type", "button", "data-bs-target", "#header-carousel", "data-bs-slide", "next", 1, "carousel-control-next"], ["aria-hidden", "true", 1, "carousel-control-next-icon"], [1, "container", "d-flex", "justify-content-center", "mt-50", "mb-50"], [1, "row"], [1, "col-md-4", "mt-2"], [1, "card"], [1, "card-body"], [1, "card-img-actions"], ["src", "assets/gad7.avif", "width", "96", "height", "100", "alt", "", 1, "card-img", "img-fluid"], [1, "card-body", "bg-light", "text-center"], [1, "mb-2"], [1, "font-weight-semibold", "mb-2"], ["href", "#", "data-abc", "true", 1, "text-default", "mb-2"], ["href", "#", "data-abc", "true", 1, "text-muted"], [1, "mb-0", "font-weight-semibold"], [1, "text-muted", "mb-3"], ["routerLink", "login", "type", "button", 1, "btn", "bg-cart"], ["aria-hidden", "true", 1, "fa", "fa-phone-square"], ["src", "assets/gad9.avif", "width", "96", "height", "300", "alt", "", 1, "card-img", "img-fluid"], ["src", "assets/iphone.avif", "width", "96", "height", "350", "alt", "", 1, "card-img", "img-fluid"], ["src", "assets/gad5.avif", "width", "96", "height", "350", "alt", "", 1, "card-img", "img-fluid"], ["src", "assets/gad4.avif", "width", "96", "height", "350", "alt", "", 1, "card-img", "img-fluid"], ["src", "assets/gad6.avif", "width", "96", "height", "350", "alt", "", 1, "card-img", "img-fluid"], [1, "container"], [1, "row", "bg-light"], [1, "row", "bg-light", "hover-4", "boxes"], [1, "col-md-6", "description", "hover-1"], [1, "col-md-6", "image-box"], ["src", "assets/chat.jpeg", "width", "200", "height", "200", 1, "img-fluid"], [1, "row", "hover-4", "content-mid-body"], [1, "col-md-6", "order-md-1", "order-2", "image-box"], ["src", "assets/mail1.png", "width", "200", "height", "200", 1, "img-fluid"], [1, "col-md-6", "order-md-12", "description", "order-1"], [1, "row", "bg-light", "hover-4"], ["src", "assets/video.jpg", "width", "200", "height", "200", 1, "img-fluid"], ["src", "assets/Coins.jpeg", "width", "200", "height", "200", 1, "img-fluid"], [1, "bg-dark", "text-center", "text-white"], [1, "container", "p-4"], ["fxLayout", "row", "fxLayoutAlign", "space-between center"], [2, "margin-left", "30px"], ["href", "https://www.facebook.com/"], ["href", "/"], ["href", "#", 2, "font-size", "40px", 3, "click"], [1, "mb-4"], [1, "text-center", "p-3", 2, "background-color", "rgba(0, 0, 0, 0.2)"], ["href", "/", 1, "text-white"]],
        template: function LandingPageComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "body", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-toolbar", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-toolbar-row", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_10_listener() {
              return ctx.scrollToBottom();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Features");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_12_listener() {
              return ctx.scrollToDown();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "About us");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_14_listener() {
              return ctx.scrollToDown();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Contact us");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "add");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "SELL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "a", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "Sign In");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "img", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "h1", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Welcome to SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "h4", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Guaranteed sale on every posting. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](37, "img", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "h1", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Advertise, I Want It All. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "h4", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "It is more than just sales. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "img", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "h1", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "A few clicks is all it takes. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "h4", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Helping buyers and sellers to attain their goals.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "img", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "h1", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, "Find it, love it, buy it. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "h4", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, "Combining quality and reliability in one.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "button", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "span", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "span", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](63, "Previous");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "button", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](65, "span", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "span", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, "Next");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "img", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](79, "Apple Airpods pro (2nd generation)");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, "Earphones");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "\u20B910,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](85, "34 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](87, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, " contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](93, "img", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](98, "Sony Bluetooth Earphones");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](100, "Earphoness");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](102, "\u20B95,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](104, "10 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](106, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](107, " contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](112, "img", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](117, "Iphone X 64 gb");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Mobiles & phones");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](121, "\u20B940,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123, "34 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](125, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](126, " contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](131, "img", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](136, "Boat Bluetooth Headphones");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](138, "Earphones");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](140, "\u20B915,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](142, "50 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](144, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](145, "contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](146, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](149, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](150, "img", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](155, "Dell desktop with 500GB HDD & 8GB RAM");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](157, "Laptops & Notebooks");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](159, "\u20B965,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](161, "56 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](163, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](164, " contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](165, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](166, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](168, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](169, "img", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](170, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](171, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](172, "h6", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](173, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](174, "JBL portalble blutooth speaker");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](175, "a", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](176, "Electronics");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](177, "h3", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](178, "\u20B917,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](179, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](180, "9 reviews");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](181, "button", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](182, "i", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](183, " contact seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](184, "mat-divider");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](185, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](186, "div", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](187, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](188, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](189, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](190, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](191, "div", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](192, "div", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](193, "h3");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](194, "CHAT SERVICES");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](195, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](196, "Chat software is a service that allows immediate customer support and information. It works as an instant messenger where your customers can communicate with you in real time. A live chat support has the ability to promptly and conveniently answer customer inquiries that can bump up your website conversion rates.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](197, "div", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](198, "img", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](199, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](200, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](201, "div", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](202, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](203, "img", 59);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](204, "div", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](205, "h3");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](206, "MAIL SERVICES");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](207, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](208, "When the Transaction is completed i.e you exchange the product You and exchanger both get a confirmation mail from Swap-on.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](209, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](210, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](211, "div", 61);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](212, "div", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](213, "h3");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](214, "VIDEO CONNECT");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](215, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](216, "Video conferencing is live, visual connection between two or more remote parties over the internet that simulates a face-to-face meeting. You can connect with the seller or buyer via video call and verify products. That results in verification of the advertisement and prevents scam. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](217, "div", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](218, "img", 62);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](219, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](220, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](221, "div", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](222, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](223, "img", 63);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](224, "div", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](225, "h3");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](226, "REFERAL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](227, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](228, "Refer SwapSquad and earn 100 barter coin when you friend join swapsqad , and for each transaction you get 25 Barter coins. Your friend get 50 Barter coins as joining bonous.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](229, "div", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](230, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](231, "footer", 64);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](232, "div", 65);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](233, "div", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](234, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](235, "div", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](236, "a", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](237, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](238, "facebook");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](239, "a", 69);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](240, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](241, "home");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](242, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](243, "public");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](244, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](245, "mat-icon", 70);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LandingPageComponent_Template_mat_icon_click_245_listener() {
              return ctx.scrollToTop();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](246, "arrow_upward");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](247, "section", 71);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](248, "h2");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](249, "THANK YOU");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](250, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](251, " We Exist to provide people with excess to a better future. Hope you visit again. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](252, "div", 72);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](253, " \xA9 2022 Copyright : ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](254, "a", 73);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](255, "Swap-on.com");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](256, "app-chat-bot");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", "/");
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__["MatToolbar"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_2__["MatToolbarRow"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_3__["DefaultLayoutAlignDirective"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterLink"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_4__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterLinkWithHref"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__["MatDivider"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_3__["DefaultLayoutDirective"], _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_8__["ChatBotComponent"]],
        styles: ["body[_ngcontent-%COMP%] {\n  \n  font-size: 15px;\n  \n}\n\n.spacer[_ngcontent-%COMP%]{\n  flex: 1 1 auto;\n}\n\n.mat-toolbar-single-row[_ngcontent-%COMP%] {\n  height: 75px;\n  padding: 0;\n}\n\n.mat-toolbar.mat-primary[_ngcontent-%COMP%]{\n  background-color: #383a48;\n}\n\n.mat-form-field-appearance-legacy[_ngcontent-%COMP%]   .mat-form-field-wrapper[_ngcontent-%COMP%] {\n  padding-bottom: 1.2em;\n}\n\n.categ[_ngcontent-%COMP%]{\n  margin-left: 10px;\n}\n\n.mat-form-field[_ngcontent-%COMP%] {\n  font-size: medium;\n  \n}\n\n.navbar[_ngcontent-%COMP%] {\n  \n  display: flex;\n  position: fixed;\n  \n}\n\n.reg-button[_ngcontent-%COMP%]{\n  margin-left:9px;\n}\n\n.fade-out[_ngcontent-%COMP%] {\n  animation: fadeOut 2s;\n  opacity: 0;\n}\n\n@keyframes fadeOut {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n  }\n}\n\n.fadeIn[_ngcontent-%COMP%] {\n  animation: fade 5s;\n}\n\n@keyframes fade {\n  0% {\n    opacity: 0;\n  }\n\n  100% {\n    opacity: 1;\n  }\n}\n\n.Title[_ngcontent-%COMP%] {\n  \n  font-size: 150%;\n  margin-right: 20px;\n  margin-left: 10px;\n}\n\n.navbar-brand[_ngcontent-%COMP%] {\n  cursor: pointer;\n  margin-left: 10px;\n  margin-right: 0px;\n}\n\n.Title[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:hover{\n  color: rgb(210, 29, 41);\n}\n\n.rightNav[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: right;\n  padding: 10px;\n}\n\n.nav-item[_ngcontent-%COMP%] {\n  padding-right: 12px;\n  padding-left: 12px;\n}\n\n.flag[_ngcontent-%COMP%] {\n  max-height: 20px;\n  max-width: 20px;\n  margin-top: 10px;\n}\n\n.nav-link.active[_ngcontent-%COMP%] {\n  background-color: lightgrey !important;\n}\n\n.content-mid-body[_ngcontent-%COMP%] {\n  background-color: rgba(220, 232, 235, 0.7);\n  border-radius: 6px;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  \n  \n  \n  \n  transition: all 1s ease\n}\n\n.card-body[_ngcontent-%COMP%]:hover {\n  transform: scale(1.05);\n}\n\n.prenota-text[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 40%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.image-prenota[_ngcontent-%COMP%] {\n  opacity: 0.4;\n  max-height: 750px;\n}\n\n.carousel-caption[_ngcontent-%COMP%] {\n  top: 40%;\n}\n\n.img-slider[_ngcontent-%COMP%] {\n  min-height: 320px;\n}\n\n.navMenu[_ngcontent-%COMP%] {\n  padding-top: 75px;\n  padding-bottom: 20px;\n}\n\n.card-img-top[_ngcontent-%COMP%] {\n  height: 200px;\n}\n\n.mappa[_ngcontent-%COMP%] {\n  height: 320px;\n  padding-right: 10px;\n}\n\n@media screen and (max-width : 1920px) {\n  .only-mobile[_ngcontent-%COMP%] {\n    visibility: hidden;\n  }\n}\n\n@media screen and (max-width : 506px) {\n\n  .only-mobile[_ngcontent-%COMP%] {\n    visibility: visible;\n  }\n}\n\n.footer[_ngcontent-%COMP%] {\n\n  margin-top: 30px;\n  padding-top: 20px;\n}\n\n.social-icon[_ngcontent-%COMP%] {\n  font-size: 28;\n}\n\n.image-box[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.description[_ngcontent-%COMP%] {\n  display: grid;\n  justify-content: center;\n  align-content: center;\n\n}\n\n.heading[_ngcontent-%COMP%] {\n  font-weight: bold;\n  font-size: 2rem;\n}\n\n.hover-4[_ngcontent-%COMP%] {\n  border: 2px solid;\n  \n  -o-border-image: repeating-linear-gradient(135deg, #67abc4 0 10px, #1095c1 0 20px, #59c8f7 0 30px) 8;\n     border-image: repeating-linear-gradient(135deg, #67abc4 0 10px, #1095c1 0 20px, #59c8f7 0 30px) 8;\n  -webkit-mask:\n    conic-gradient(from 180deg at top 8px right 8px, #0000 90deg, #000 0) var(--_i, 200%) 0 /200% var(--_i, 8px) border-box no-repeat,\n    conic-gradient(at bottom 8px left 8px, #0000 90deg, #000 0) 0 var(--_i, 200%)/var(--_i, 8px) 200% border-box no-repeat,\n    linear-gradient(#000 0 0) padding-box no-repeat;\n  transition: .3s, -webkit-mask-position .3s .3s;\n\n}\n\n.hover-4[_ngcontent-%COMP%]:hover {\n  --_i: 100%;\n  color: #CC333F;\n  transition: .3s, -webkit-mask-size .3s .3s;\n}\n\n.hover-3[_ngcontent-%COMP%] {\n  --b: 0.1em;\n  \n  --c: #1095c1;\n  \n\n  color: #0000;\n  padding-block: var(--b);\n  background:\n    linear-gradient(var(--c) 50%, #000 0) 0% calc(100% - var(--_p, 0%))/100% 200%,\n    linear-gradient(var(--c) 0 0) 0% var(--_p, 0%)/var(--_p, 0%) var(--b) no-repeat;\n  -webkit-background-clip: text, padding-box;\n  background-clip: text, padding-box;\n  transition: .3s var(--_s, 0s) linear, background-size .3s calc(.3s - var(--_s, 0s));\n}\n\n.hover-3[_ngcontent-%COMP%]:hover {\n  --_p: 100%;\n  --_s: .3s;\n}\n\n.hover-2[_ngcontent-%COMP%] {\n  --s: 0.1em;\n  \n  --c: #1095c1;\n  \n\n  color: #0000;\n  padding-bottom: var(--s);\n  background:\n    linear-gradient(90deg, var(--c) 50%, #000 0) calc(100% - var(--_p, 0%))/200% 100%,\n    linear-gradient(var(--c) 0 0) 0% 100%/var(--_p, 0%) var(--s) no-repeat;\n  -webkit-background-clip: text, padding-box;\n  background-clip: text, padding-box;\n  transition: 0.5s;\n}\n\n.hover-2[_ngcontent-%COMP%]:hover {\n  --_p: 100%\n}\n\n.hover-1[_ngcontent-%COMP%] {\n  color: #0000;\n  background:\n    linear-gradient(90deg, #0e83a9 50%, #000 0) var(--_p, 100%)/200% no-repeat;\n  -webkit-background-clip: text;\n  background-clip: text;\n  transition: .4s;\n}\n\n.hover-1[_ngcontent-%COMP%]:hover {\n  --_p: 0%;\n}\n\n.boxes[_ngcontent-%COMP%] {\n  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);\n}\n\n\n\n.carousel-caption[_ngcontent-%COMP%] {\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  \n  background-color: rgba(89, 137, 156, 0.7);\n  z-index: 1;\n}\n\n@media (max-width: 576px) {\n  .carousel-caption[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n    font-size: 14px;\n    font-weight: 500 !important;\n  }\n\n  .carousel-caption[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n    font-size: 30px;\n    font-weight: 600 !important;\n  }\n}\n\n.carousel-control-prev[_ngcontent-%COMP%], .carousel-control-next[_ngcontent-%COMP%] {\n  width: 10%;\n}\n\n.carousel-control-prev-icon[_ngcontent-%COMP%], .carousel-control-next-icon[_ngcontent-%COMP%] {\n  width: 1rem;\n  height: 1rem;\n\n}\n\n\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-dots[_ngcontent-%COMP%] {\n  margin-top: 15px;\n  display: flex;\n  align-items: flex-end;\n  justify-content: center;\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-dot[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  margin: 0 5px;\n  width: 15px;\n  height: 15px;\n  background: #DDDDDD;\n  border-radius: 2px;\n  transition: .5s;\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-dot.active[_ngcontent-%COMP%] {\n  width: 30px;\n  background: var(--primary);\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-item.center[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 1;\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-item[_ngcontent-%COMP%]   .testimonial-item[_ngcontent-%COMP%] {\n  transition: .5s;\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-item.center[_ngcontent-%COMP%]   .testimonial-item[_ngcontent-%COMP%] {\n  background: #FFFFFF !important;\n  box-shadow: 0 0 30px #DDDDDD;\n}\n\n.bg-header[_ngcontent-%COMP%] {\n  \n  background-size: cover;\n}\n\n.navbar-dark[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:hover, .navbar-dark[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n\n.navbar-dark[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:hover::before, .navbar-dark[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%]::before {\n  width: 100%;\n  left: 0;\n}\n\n.testimonial-carousel[_ngcontent-%COMP%]   .owl-dot.active[_ngcontent-%COMP%] {\n  width: 30px;\n  background: var(--primary);\n}\n\n.link-animated[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  transition: .5s;\n}\n\n.link-animated[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  padding-left: 10px;\n}\n\n.animated[_ngcontent-%COMP%] {\n  animation-duration: 1s;\n  animation-fill-mode: both;\n}\n\n.animated[_ngcontent-%COMP%] {\n  animation-duration: 1s;\n  animation-fill-mode: both;\n}\n\n.animated.infinite[_ngcontent-%COMP%] {\n  animation-iteration-count: infinite;\n}\n\n.animated.hinge[_ngcontent-%COMP%] {\n  animation-duration: 2s;\n}\n\n.animated.flipOutX[_ngcontent-%COMP%], .animated.flipOutY[_ngcontent-%COMP%], .animated.bounceIn[_ngcontent-%COMP%], .animated.bounceOut[_ngcontent-%COMP%] {\n  animation-duration: .75s;\n}\n\n@keyframes bounce {\n\n  from,\n  20%,\n  53%,\n  80%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n    transform: translate3d(0, 0, 0);\n  }\n\n  40%,\n  43% {\n    animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);\n    transform: translate3d(0, -30px, 0);\n  }\n\n  70% {\n    animation-timing-function: cubic-bezier(0.755, 0.050, 0.855, 0.060);\n    transform: translate3d(0, -15px, 0);\n  }\n\n  90% {\n    transform: translate3d(0, -4px, 0);\n  }\n}\n\n.bounce[_ngcontent-%COMP%] {\n  animation-name: bounce;\n  transform-origin: center bottom;\n}\n\n@keyframes flash {\n\n  from,\n  50%,\n  to {\n    opacity: 1;\n  }\n\n  25%,\n  75% {\n    opacity: 0;\n  }\n}\n\n.flash[_ngcontent-%COMP%] {\n  animation-name: flash;\n}\n\n\n\n@keyframes pulse {\n  from {\n    transform: scale3d(1, 1, 1);\n  }\n\n  50% {\n    transform: scale3d(1.05, 1.05, 1.05);\n  }\n\n  to {\n    transform: scale3d(1, 1, 1);\n  }\n}\n\n.pulse[_ngcontent-%COMP%] {\n  animation-name: pulse;\n}\n\n@keyframes rubberBand {\n  from {\n    transform: scale3d(1, 1, 1);\n  }\n\n  30% {\n    transform: scale3d(1.25, 0.75, 1);\n  }\n\n  40% {\n    transform: scale3d(0.75, 1.25, 1);\n  }\n\n  50% {\n    transform: scale3d(1.15, 0.85, 1);\n  }\n\n  65% {\n    transform: scale3d(.95, 1.05, 1);\n  }\n\n  75% {\n    transform: scale3d(1.05, .95, 1);\n  }\n\n  to {\n    transform: scale3d(1, 1, 1);\n  }\n}\n\n.rubberBand[_ngcontent-%COMP%] {\n  animation-name: rubberBand;\n}\n\n@keyframes shake {\n\n  from,\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n\n  10%,\n  30%,\n  50%,\n  70%,\n  90% {\n    transform: translate3d(-10px, 0, 0);\n  }\n\n  20%,\n  40%,\n  60%,\n  80% {\n    transform: translate3d(10px, 0, 0);\n  }\n}\n\n.shake[_ngcontent-%COMP%] {\n  animation-name: shake;\n}\n\n@keyframes headShake {\n  0% {\n    transform: translateX(0);\n  }\n\n  6.5% {\n    transform: translateX(-6px) rotateY(-9deg);\n  }\n\n  18.5% {\n    transform: translateX(5px) rotateY(7deg);\n  }\n\n  31.5% {\n    transform: translateX(-3px) rotateY(-5deg);\n  }\n\n  43.5% {\n    transform: translateX(2px) rotateY(3deg);\n  }\n\n  50% {\n    transform: translateX(0);\n  }\n}\n\n.headShake[_ngcontent-%COMP%] {\n  animation-timing-function: ease-in-out;\n  animation-name: headShake;\n}\n\n@keyframes swing {\n  20% {\n    transform: rotate3d(0, 0, 1, 15deg);\n  }\n\n  40% {\n    transform: rotate3d(0, 0, 1, -10deg);\n  }\n\n  60% {\n    transform: rotate3d(0, 0, 1, 5deg);\n  }\n\n  80% {\n    transform: rotate3d(0, 0, 1, -5deg);\n  }\n\n  to {\n    transform: rotate3d(0, 0, 1, 0deg);\n  }\n}\n\n.swing[_ngcontent-%COMP%] {\n  transform-origin: top center;\n  animation-name: swing;\n}\n\n@keyframes tada {\n  from {\n    transform: scale3d(1, 1, 1);\n  }\n\n  10%,\n  20% {\n    transform: scale3d(.9, .9, .9) rotate3d(0, 0, 1, -3deg);\n  }\n\n  30%,\n  50%,\n  70%,\n  90% {\n    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);\n  }\n\n  40%,\n  60%,\n  80% {\n    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);\n  }\n\n  to {\n    transform: scale3d(1, 1, 1);\n  }\n}\n\n.tada[_ngcontent-%COMP%] {\n  animation-name: tada;\n}\n\n\n\n@keyframes wobble {\n  from {\n    transform: none;\n  }\n\n  15% {\n    transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);\n  }\n\n  30% {\n    transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);\n  }\n\n  45% {\n    transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);\n  }\n\n  60% {\n    transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);\n  }\n\n  75% {\n    transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);\n  }\n\n  to {\n    transform: none;\n  }\n}\n\n.wobble[_ngcontent-%COMP%] {\n  animation-name: wobble;\n}\n\n@keyframes jello {\n\n  from,\n  11.1%,\n  to {\n    transform: none;\n  }\n\n  22.2% {\n    transform: skewX(-12.5deg) skewY(-12.5deg);\n  }\n\n  33.3% {\n    transform: skewX(6.25deg) skewY(6.25deg);\n  }\n\n  44.4% {\n    transform: skewX(-3.125deg) skewY(-3.125deg);\n  }\n\n  55.5% {\n    transform: skewX(1.5625deg) skewY(1.5625deg);\n  }\n\n  66.6% {\n    transform: skewX(-0.78125deg) skewY(-0.78125deg);\n  }\n\n  77.7% {\n    transform: skewX(0.390625deg) skewY(0.390625deg);\n  }\n\n  88.8% {\n    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);\n  }\n}\n\n.jello[_ngcontent-%COMP%] {\n  animation-name: jello;\n  transform-origin: center;\n}\n\n@keyframes bounceIn {\n\n  from,\n  20%,\n  40%,\n  60%,\n  80%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n  }\n\n  0% {\n    opacity: 0;\n    transform: scale3d(.3, .3, .3);\n  }\n\n  20% {\n    transform: scale3d(1.1, 1.1, 1.1);\n  }\n\n  40% {\n    transform: scale3d(.9, .9, .9);\n  }\n\n  60% {\n    opacity: 1;\n    transform: scale3d(1.03, 1.03, 1.03);\n  }\n\n  80% {\n    transform: scale3d(.97, .97, .97);\n  }\n\n  to {\n    opacity: 1;\n    transform: scale3d(1, 1, 1);\n  }\n}\n\n.bounceIn[_ngcontent-%COMP%] {\n  animation-name: bounceIn;\n}\n\n@keyframes bounceInDown {\n\n  from,\n  60%,\n  75%,\n  90%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n  }\n\n  0% {\n    opacity: 0;\n    transform: translate3d(0, -3000px, 0);\n  }\n\n  60% {\n    opacity: 1;\n    transform: translate3d(0, 25px, 0);\n  }\n\n  75% {\n    transform: translate3d(0, -10px, 0);\n  }\n\n  90% {\n    transform: translate3d(0, 5px, 0);\n  }\n\n  to {\n    transform: none;\n  }\n}\n\n.bounceInDown[_ngcontent-%COMP%] {\n  animation-name: bounceInDown;\n}\n\n@keyframes bounceInLeft {\n\n  from,\n  60%,\n  75%,\n  90%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n  }\n\n  0% {\n    opacity: 0;\n    transform: translate3d(-3000px, 0, 0);\n  }\n\n  60% {\n    opacity: 1;\n    transform: translate3d(25px, 0, 0);\n  }\n\n  75% {\n    transform: translate3d(-10px, 0, 0);\n  }\n\n  90% {\n    transform: translate3d(5px, 0, 0);\n  }\n\n  to {\n    transform: none;\n  }\n}\n\n.bounceInLeft[_ngcontent-%COMP%] {\n  animation-name: bounceInLeft;\n}\n\n@keyframes bounceInRight {\n\n  from,\n  60%,\n  75%,\n  90%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n  }\n\n  from {\n    opacity: 0;\n    transform: translate3d(3000px, 0, 0);\n  }\n\n  60% {\n    opacity: 1;\n    transform: translate3d(-25px, 0, 0);\n  }\n\n  75% {\n    transform: translate3d(10px, 0, 0);\n  }\n\n  90% {\n    transform: translate3d(-5px, 0, 0);\n  }\n\n  to {\n    transform: none;\n  }\n}\n\n.bounceInRight[_ngcontent-%COMP%] {\n  animation-name: bounceInRight;\n}\n\n@keyframes bounceInUp {\n\n  from,\n  60%,\n  75%,\n  90%,\n  to {\n    animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000);\n  }\n\n  from {\n    opacity: 0;\n    transform: translate3d(0, 3000px, 0);\n  }\n\n  60% {\n    opacity: 1;\n    transform: translate3d(0, -20px, 0);\n  }\n\n  75% {\n    transform: translate3d(0, 10px, 0);\n  }\n\n  90% {\n    transform: translate3d(0, -5px, 0);\n  }\n\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n}\n\n.bounceInUp[_ngcontent-%COMP%] {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceOut {\n  20% {\n    transform: scale3d(.9, .9, .9);\n  }\n\n  50%,\n  55% {\n    opacity: 1;\n    transform: scale3d(1.1, 1.1, 1.1);\n  }\n\n  to {\n    opacity: 0;\n    transform: scale3d(.3, .3, .3);\n  }\n}\n\n.bounceOut[_ngcontent-%COMP%] {\n  animation-name: bounceOut;\n}\n\n@keyframes bounceOutDown {\n  20% {\n    transform: translate3d(0, 10px, 0);\n  }\n\n  40%,\n  45% {\n    opacity: 1;\n    transform: translate3d(0, -20px, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, 2000px, 0);\n  }\n}\n\n.bounceOutDown[_ngcontent-%COMP%] {\n  animation-name: bounceOutDown;\n}\n\n@keyframes bounceOutLeft {\n  20% {\n    opacity: 1;\n    transform: translate3d(20px, 0, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(-2000px, 0, 0);\n  }\n}\n\n.bounceOutLeft[_ngcontent-%COMP%] {\n  animation-name: bounceOutLeft;\n}\n\n@keyframes bounceOutRight {\n  20% {\n    opacity: 1;\n    transform: translate3d(-20px, 0, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(2000px, 0, 0);\n  }\n}\n\n.bounceOutRight[_ngcontent-%COMP%] {\n  animation-name: bounceOutRight;\n}\n\n@keyframes bounceOutUp {\n  20% {\n    transform: translate3d(0, -10px, 0);\n  }\n\n  40%,\n  45% {\n    opacity: 1;\n    transform: translate3d(0, 20px, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, -2000px, 0);\n  }\n}\n\n.bounceOutUp[_ngcontent-%COMP%] {\n  animation-name: bounceOutUp;\n}\n\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n  }\n\n  to {\n    opacity: 1;\n  }\n}\n\n.fadeIn[_ngcontent-%COMP%] {\n  animation-name: fadeIn;\n}\n\n@keyframes fadeInDown {\n  from {\n    opacity: 0;\n    transform: translate3d(0, -100%, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInDown[_ngcontent-%COMP%] {\n  animation-name: fadeInDown;\n}\n\n@keyframes fadeInDownBig {\n  from {\n    opacity: 0;\n    transform: translate3d(0, -2000px, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInDownBig[_ngcontent-%COMP%] {\n  animation-name: fadeInDownBig;\n}\n\n@keyframes fadeInLeft {\n  from {\n    opacity: 0;\n    transform: translate3d(-100%, 0, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInLeft[_ngcontent-%COMP%] {\n  animation-name: fadeInLeft;\n}\n\n@keyframes fadeInLeftBig {\n  from {\n    opacity: 0;\n    transform: translate3d(-2000px, 0, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInLeftBig[_ngcontent-%COMP%] {\n  animation-name: fadeInLeftBig;\n}\n\n@keyframes fadeInRight {\n  from {\n    opacity: 0;\n    transform: translate3d(100%, 0, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInRight[_ngcontent-%COMP%] {\n  animation-name: fadeInRight;\n}\n\n@keyframes fadeInRightBig {\n  from {\n    opacity: 0;\n    transform: translate3d(2000px, 0, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInRightBig[_ngcontent-%COMP%] {\n  animation-name: fadeInRightBig;\n}\n\n@keyframes fadeInUp {\n  from {\n    opacity: 0;\n    transform: translate3d(0, 100%, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInUp[_ngcontent-%COMP%] {\n  animation-name: fadeInUp;\n}\n\n@keyframes fadeInUpBig {\n  from {\n    opacity: 0;\n    transform: translate3d(0, 2000px, 0);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.fadeInUpBig[_ngcontent-%COMP%] {\n  animation-name: fadeInUpBig;\n}\n\n@keyframes fadeOut {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n  }\n}\n\n.fadeOut[_ngcontent-%COMP%] {\n  animation-name: fadeOut;\n}\n\n@keyframes fadeOutDown {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, 100%, 0);\n  }\n}\n\n.fadeOutDown[_ngcontent-%COMP%] {\n  animation-name: fadeOutDown;\n}\n\n@keyframes fadeOutDownBig {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, 2000px, 0);\n  }\n}\n\n.fadeOutDownBig[_ngcontent-%COMP%] {\n  animation-name: fadeOutDownBig;\n}\n\n@keyframes fadeOutLeft {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(-100%, 0, 0);\n  }\n}\n\n.fadeOutLeft[_ngcontent-%COMP%] {\n  animation-name: fadeOutLeft;\n}\n\n@keyframes fadeOutLeftBig {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(-2000px, 0, 0);\n  }\n}\n\n.fadeOutLeftBig[_ngcontent-%COMP%] {\n  animation-name: fadeOutLeftBig;\n}\n\n@keyframes fadeOutRight {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(100%, 0, 0);\n  }\n}\n\n.fadeOutRight[_ngcontent-%COMP%] {\n  animation-name: fadeOutRight;\n}\n\n@keyframes fadeOutRightBig {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(2000px, 0, 0);\n  }\n}\n\n.fadeOutRightBig[_ngcontent-%COMP%] {\n  animation-name: fadeOutRightBig;\n}\n\n@keyframes fadeOutUp {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, -100%, 0);\n  }\n}\n\n.fadeOutUp[_ngcontent-%COMP%] {\n  animation-name: fadeOutUp;\n}\n\n@keyframes fadeOutUpBig {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(0, -2000px, 0);\n  }\n}\n\n.fadeOutUpBig[_ngcontent-%COMP%] {\n  animation-name: fadeOutUpBig;\n}\n\n@keyframes flip {\n  from {\n    transform: perspective(400px) rotate3d(0, 1, 0, -360deg);\n    animation-timing-function: ease-out;\n  }\n\n  40% {\n    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);\n    animation-timing-function: ease-out;\n  }\n\n  50% {\n    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);\n    animation-timing-function: ease-in;\n  }\n\n  80% {\n    transform: perspective(400px) scale3d(.95, .95, .95);\n    animation-timing-function: ease-in;\n  }\n\n  to {\n    transform: perspective(400px);\n    animation-timing-function: ease-in;\n  }\n}\n\n.animated.flip[_ngcontent-%COMP%] {\n  -webkit-backface-visibility: visible;\n  backface-visibility: visible;\n  animation-name: flip;\n}\n\n@keyframes flipInX {\n  from {\n    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    animation-timing-function: ease-in;\n    opacity: 0;\n  }\n\n  40% {\n    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    animation-timing-function: ease-in;\n  }\n\n  60% {\n    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);\n    opacity: 1;\n  }\n\n  80% {\n    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);\n  }\n\n  to {\n    transform: perspective(400px);\n  }\n}\n\n.flipInX[_ngcontent-%COMP%] {\n  -webkit-backface-visibility: visible !important;\n  backface-visibility: visible !important;\n  animation-name: flipInX;\n}\n\n@keyframes flipInY {\n  from {\n    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);\n    animation-timing-function: ease-in;\n    opacity: 0;\n  }\n\n  40% {\n    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);\n    animation-timing-function: ease-in;\n  }\n\n  60% {\n    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);\n    opacity: 1;\n  }\n\n  80% {\n    transform: perspective(400px) rotate3d(0, 1, 0, -5deg);\n  }\n\n  to {\n    transform: perspective(400px);\n  }\n}\n\n.flipInY[_ngcontent-%COMP%] {\n  -webkit-backface-visibility: visible !important;\n  backface-visibility: visible !important;\n  animation-name: flipInY;\n}\n\n@keyframes flipOutX {\n  from {\n    transform: perspective(400px);\n  }\n\n  30% {\n    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    opacity: 1;\n  }\n\n  to {\n    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    opacity: 0;\n  }\n}\n\n.flipOutX[_ngcontent-%COMP%] {\n  animation-name: flipOutX;\n  -webkit-backface-visibility: visible !important;\n  backface-visibility: visible !important;\n}\n\n@keyframes flipOutY {\n  from {\n    transform: perspective(400px);\n  }\n\n  30% {\n    transform: perspective(400px) rotate3d(0, 1, 0, -15deg);\n    opacity: 1;\n  }\n\n  to {\n    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);\n    opacity: 0;\n  }\n}\n\n.flipOutY[_ngcontent-%COMP%] {\n  -webkit-backface-visibility: visible !important;\n  backface-visibility: visible !important;\n  animation-name: flipOutY;\n}\n\n@keyframes lightSpeedIn {\n  from {\n    transform: translate3d(100%, 0, 0) skewX(-30deg);\n    opacity: 0;\n  }\n\n  60% {\n    transform: skewX(20deg);\n    opacity: 1;\n  }\n\n  80% {\n    transform: skewX(-5deg);\n    opacity: 1;\n  }\n\n  to {\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.lightSpeedIn[_ngcontent-%COMP%] {\n  animation-name: lightSpeedIn;\n  animation-timing-function: ease-out;\n}\n\n@keyframes lightSpeedOut {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    transform: translate3d(100%, 0, 0) skewX(30deg);\n    opacity: 0;\n  }\n}\n\n.lightSpeedOut[_ngcontent-%COMP%] {\n  animation-name: lightSpeedOut;\n  animation-timing-function: ease-in;\n}\n\n@keyframes rotateIn {\n  from {\n    transform-origin: center;\n    transform: rotate3d(0, 0, 1, -200deg);\n    opacity: 0;\n  }\n\n  to {\n    transform-origin: center;\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.rotateIn[_ngcontent-%COMP%] {\n  animation-name: rotateIn;\n}\n\n@keyframes rotateInDownLeft {\n  from {\n    transform-origin: left bottom;\n    transform: rotate3d(0, 0, 1, -45deg);\n    opacity: 0;\n  }\n\n  to {\n    transform-origin: left bottom;\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.rotateInDownLeft[_ngcontent-%COMP%] {\n  animation-name: rotateInDownLeft;\n}\n\n@keyframes rotateInDownRight {\n  from {\n    transform-origin: right bottom;\n    transform: rotate3d(0, 0, 1, 45deg);\n    opacity: 0;\n  }\n\n  to {\n    transform-origin: right bottom;\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.rotateInDownRight[_ngcontent-%COMP%] {\n  animation-name: rotateInDownRight;\n}\n\n@keyframes rotateInUpLeft {\n  from {\n    transform-origin: left bottom;\n    transform: rotate3d(0, 0, 1, 45deg);\n    opacity: 0;\n  }\n\n  to {\n    transform-origin: left bottom;\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.rotateInUpLeft[_ngcontent-%COMP%] {\n  animation-name: rotateInUpLeft;\n}\n\n@keyframes rotateInUpRight {\n  from {\n    transform-origin: right bottom;\n    transform: rotate3d(0, 0, 1, -90deg);\n    opacity: 0;\n  }\n\n  to {\n    transform-origin: right bottom;\n    transform: none;\n    opacity: 1;\n  }\n}\n\n.rotateInUpRight[_ngcontent-%COMP%] {\n  animation-name: rotateInUpRight;\n}\n\n@keyframes rotateOut {\n  from {\n    transform-origin: center;\n    opacity: 1;\n  }\n\n  to {\n    transform-origin: center;\n    transform: rotate3d(0, 0, 1, 200deg);\n    opacity: 0;\n  }\n}\n\n.rotateOut[_ngcontent-%COMP%] {\n  animation-name: rotateOut;\n}\n\n@keyframes rotateOutDownLeft {\n  from {\n    transform-origin: left bottom;\n    opacity: 1;\n  }\n\n  to {\n    transform-origin: left bottom;\n    transform: rotate3d(0, 0, 1, 45deg);\n    opacity: 0;\n  }\n}\n\n.rotateOutDownLeft[_ngcontent-%COMP%] {\n  animation-name: rotateOutDownLeft;\n}\n\n@keyframes rotateOutDownRight {\n  from {\n    transform-origin: right bottom;\n    opacity: 1;\n  }\n\n  to {\n    transform-origin: right bottom;\n    transform: rotate3d(0, 0, 1, -45deg);\n    opacity: 0;\n  }\n}\n\n.rotateOutDownRight[_ngcontent-%COMP%] {\n  animation-name: rotateOutDownRight;\n}\n\n@keyframes rotateOutUpLeft {\n  from {\n    transform-origin: left bottom;\n    opacity: 1;\n  }\n\n  to {\n    transform-origin: left bottom;\n    transform: rotate3d(0, 0, 1, -45deg);\n    opacity: 0;\n  }\n}\n\n.rotateOutUpLeft[_ngcontent-%COMP%] {\n  animation-name: rotateOutUpLeft;\n}\n\n@keyframes rotateOutUpRight {\n  from {\n    transform-origin: right bottom;\n    opacity: 1;\n  }\n\n  to {\n    transform-origin: right bottom;\n    transform: rotate3d(0, 0, 1, 90deg);\n    opacity: 0;\n  }\n}\n\n.rotateOutUpRight[_ngcontent-%COMP%] {\n  animation-name: rotateOutUpRight;\n}\n\n@keyframes hinge {\n  0% {\n    transform-origin: top left;\n    animation-timing-function: ease-in-out;\n  }\n\n  20%,\n  60% {\n    transform: rotate3d(0, 0, 1, 80deg);\n    transform-origin: top left;\n    animation-timing-function: ease-in-out;\n  }\n\n  40%,\n  80% {\n    transform: rotate3d(0, 0, 1, 60deg);\n    transform-origin: top left;\n    animation-timing-function: ease-in-out;\n    opacity: 1;\n  }\n\n  to {\n    transform: translate3d(0, 700px, 0);\n    opacity: 0;\n  }\n}\n\n.hinge[_ngcontent-%COMP%] {\n  animation-name: hinge;\n}\n\n@keyframes jackInTheBox {\n  from {\n    opacity: 0;\n    transform: scale(0.1) rotate(30deg);\n    transform-origin: center bottom;\n  }\n\n  50% {\n    transform: rotate(-10deg);\n  }\n\n  70% {\n    transform: rotate(3deg);\n  }\n\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n\n.jackInTheBox[_ngcontent-%COMP%] {\n  animation-name: jackInTheBox;\n}\n\n\n\n@keyframes rollIn {\n  from {\n    opacity: 0;\n    transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);\n  }\n\n  to {\n    opacity: 1;\n    transform: none;\n  }\n}\n\n.rollIn[_ngcontent-%COMP%] {\n  animation-name: rollIn;\n}\n\n\n\n@keyframes rollOut {\n  from {\n    opacity: 1;\n  }\n\n  to {\n    opacity: 0;\n    transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);\n  }\n}\n\n.rollOut[_ngcontent-%COMP%] {\n  animation-name: rollOut;\n}\n\n@keyframes zoomIn {\n  from {\n    opacity: 0;\n    transform: scale3d(.3, .3, .3);\n  }\n\n  50% {\n    opacity: 1;\n  }\n}\n\n.zoomIn[_ngcontent-%COMP%] {\n  animation-name: zoomIn;\n}\n\n@keyframes zoomInDown {\n  from {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(0, -1000px, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  60% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomInDown[_ngcontent-%COMP%] {\n  animation-name: zoomInDown;\n}\n\n@keyframes zoomInLeft {\n  from {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(-1000px, 0, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  60% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(10px, 0, 0);\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomInLeft[_ngcontent-%COMP%] {\n  animation-name: zoomInLeft;\n}\n\n@keyframes zoomInRight {\n  from {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(1000px, 0, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  60% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(-10px, 0, 0);\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomInRight[_ngcontent-%COMP%] {\n  animation-name: zoomInRight;\n}\n\n@keyframes zoomInUp {\n  from {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(0, 1000px, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  60% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomInUp[_ngcontent-%COMP%] {\n  animation-name: zoomInUp;\n}\n\n@keyframes zoomOut {\n  from {\n    opacity: 1;\n  }\n\n  50% {\n    opacity: 0;\n    transform: scale3d(.3, .3, .3);\n  }\n\n  to {\n    opacity: 0;\n  }\n}\n\n.zoomOut[_ngcontent-%COMP%] {\n  animation-name: zoomOut;\n}\n\n@keyframes zoomOutDown {\n  40% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(0, -60px, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  to {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(0, 2000px, 0);\n    transform-origin: center bottom;\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomOutDown[_ngcontent-%COMP%] {\n  animation-name: zoomOutDown;\n}\n\n@keyframes zoomOutLeft {\n  40% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(42px, 0, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: scale(.1) translate3d(-2000px, 0, 0);\n    transform-origin: left center;\n  }\n}\n\n.zoomOutLeft[_ngcontent-%COMP%] {\n  animation-name: zoomOutLeft;\n}\n\n@keyframes zoomOutRight {\n  40% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(-42px, 0, 0);\n  }\n\n  to {\n    opacity: 0;\n    transform: scale(.1) translate3d(2000px, 0, 0);\n    transform-origin: right center;\n  }\n}\n\n.zoomOutRight[_ngcontent-%COMP%] {\n  animation-name: zoomOutRight;\n}\n\n@keyframes zoomOutUp {\n  40% {\n    opacity: 1;\n    transform: scale3d(.475, .475, .475) translate3d(0, 60px, 0);\n    animation-timing-function: cubic-bezier(0.550, 0.055, 0.675, 0.190);\n  }\n\n  to {\n    opacity: 0;\n    transform: scale3d(.1, .1, .1) translate3d(0, -2000px, 0);\n    transform-origin: center bottom;\n    animation-timing-function: cubic-bezier(0.175, 0.885, 0.320, 1);\n  }\n}\n\n.zoomOutUp[_ngcontent-%COMP%] {\n  animation-name: zoomOutUp;\n}\n\n@keyframes slideInDown {\n  from {\n    transform: translate3d(0, -100%, 0);\n    visibility: visible;\n  }\n\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n}\n\n.slideInDown[_ngcontent-%COMP%] {\n  animation-name: slideInDown;\n}\n\n@keyframes slideInLeft {\n  from {\n    transform: translate3d(-100%, 0, 0);\n    visibility: visible;\n  }\n\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n}\n\n.slideInLeft[_ngcontent-%COMP%] {\n  animation-name: slideInLeft;\n}\n\n@keyframes slideInRight {\n  from {\n    transform: translate3d(100%, 0, 0);\n    visibility: visible;\n  }\n\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n}\n\n.slideInRight[_ngcontent-%COMP%] {\n  animation-name: slideInRight;\n}\n\n@keyframes slideInUp {\n  from {\n    transform: translate3d(0, 100%, 0);\n    visibility: visible;\n  }\n\n  to {\n    transform: translate3d(0, 0, 0);\n  }\n}\n\n.slideInUp[_ngcontent-%COMP%] {\n  animation-name: slideInUp;\n}\n\n@keyframes slideOutDown {\n  from {\n    transform: translate3d(0, 0, 0);\n  }\n\n  to {\n    visibility: hidden;\n    transform: translate3d(0, 100%, 0);\n  }\n}\n\n.slideOutDown[_ngcontent-%COMP%] {\n  animation-name: slideOutDown;\n}\n\n@keyframes slideOutLeft {\n  from {\n    transform: translate3d(0, 0, 0);\n  }\n\n  to {\n    visibility: hidden;\n    transform: translate3d(-100%, 0, 0);\n  }\n}\n\n.slideOutLeft[_ngcontent-%COMP%] {\n  animation-name: slideOutLeft;\n}\n\n@keyframes slideOutRight {\n  from {\n    transform: translate3d(0, 0, 0);\n  }\n\n  to {\n    visibility: hidden;\n    transform: translate3d(100%, 0, 0);\n  }\n}\n\n.slideOutRight[_ngcontent-%COMP%] {\n  animation-name: slideOutRight;\n}\n\n@keyframes slideOutUp {\n  from {\n    transform: translate3d(0, 0, 0);\n  }\n\n  to {\n    visibility: hidden;\n    transform: translate3d(0, -100%, 0);\n  }\n}\n\n.slideOutUp[_ngcontent-%COMP%] {\n  animation-name: slideOutUp;\n}\n\nbody[_ngcontent-%COMP%] {\n  margin: 0;\n  font-family: Roboto,-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,\"Helvetica Neue\",Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",\"Segoe UI Symbol\",\"Noto Color Emoji\";\n  font-size: .8125rem;\n  font-weight: 400;\n  line-height: 2;\n  color: #333;\n  text-align: left;\n  background-color: #383a48;\n}\n\n.mt-50[_ngcontent-%COMP%]{\n\n  margin-top: 50px;\n}\n\n.mb-50[_ngcontent-%COMP%]{\n\n  margin-bottom: 50px;\n}\n\n.card[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  word-wrap: break-word;\n  background-color: #fff;\n  background-clip: border-box;\n  border: 1px solid rgba(0,0,0,.125);\n  border-radius: .1875rem;\n}\n\n.card-img-actions[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  text-align: center;\n}\n\n.card-img[_ngcontent-%COMP%]{\n\n  width: 350px;\n}\n\n.star[_ngcontent-%COMP%]{\n      color: red;\n}\n\n.bg-cart[_ngcontent-%COMP%] {\n  background-color:rgb(90, 89, 86);\n  color:#fff;\n}\n\n.bg-cart[_ngcontent-%COMP%]:hover {\n  \n  color:#fff;\n}\n\n.bg-buy[_ngcontent-%COMP%] {\n  background-color:green;\n  color:#fff;\n  padding-right: 29px;\n}\n\n.bg-buy[_ngcontent-%COMP%]:hover {\n  \n  color:#fff;\n}\n\na[_ngcontent-%COMP%]{\n\n  text-decoration: none !important;\n}\n\n.lang[_ngcontent-%COMP%]{\n  margin-left:80px;\n}\n\n.example-form[_ngcontent-%COMP%] {\n  min-width: 250px;\n  max-width: 500px;\n  width: 100%;\n}\n\n.example-full-width[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-left: 55px;\n  margin-bottom: 5px;\n}\n\n.example-input[_ngcontent-%COMP%] {\n  max-width: 100%;\n  width: 400px;\n}\n\n.example-full-width[_ngcontent-%COMP%]{\n  margin: block end 10px; ;\n}\n\n.sign-button[_ngcontent-%COMP%]{\n  margin-right:20px;\n  margin-left: -35px;\n  \n}\n\n.sellicon[_ngcontent-%COMP%]{\n  margin-right:60px;\n  z-index: 1;\n}\n\n.sellc[_ngcontent-%COMP%]{\n  left: -40px;\n  margin-right: -20px;\n  \n}\n\n.sellc1[_ngcontent-%COMP%]{\n  right: 66px;\n\n  \n}\n\nmat-icon[_ngcontent-%COMP%]{\n  margin: 2px;\n  cursor: pointer;\n}\n\n.Title[_ngcontent-%COMP%] {\n  \n  font-size: 220%;\n  \n  \n}\n\n.navbar[_ngcontent-%COMP%]{\n  background: #383a48;\n  \n  \n  color: white;\n}\n\n.content[_ngcontent-%COMP%]{\n  margin-top:5rem;\n}\n\n.logo[_ngcontent-%COMP%]{\n    padding: 0px 5px;\n    font-size: 20px;\n}\n\n.flex[_ngcontent-%COMP%]{\n    margin-bottom: 1rem;\n    \n}\n\n.example-button-row[_ngcontent-%COMP%]{\n  align-items: end;\n  padding-left:600px;\n\n}\n\n.mat-toolbar-row[_ngcontent-%COMP%]{\n  padding:0px 0px ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxhbmRpbmctcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQTZCO0VBQzdCLGVBQWU7O0FBRWpCOztBQUVBO0VBQ0UsY0FBYztBQUNoQjs7QUFHQTtFQUNFLFlBQVk7RUFDWixVQUFVO0FBQ1o7O0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7O0FBQ0E7RUFDRSxxQkFBcUI7QUFDdkI7O0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxpQkFBaUI7O0FBRW5COztBQUNBOztFQUVFLGFBQWE7RUFDYixlQUFlOztBQUVqQjs7QUFFQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsVUFBVTtBQUNaOztBQUdBO0VBQ0U7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtFQUNaOztFQUVBO0lBQ0UsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFDQTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsYUFBYTtBQUNmOztBQUVBO0VBQ0UsbUJBQW1CO0VBQ25CLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0Usc0NBQXNDO0FBQ3hDOztBQUVBO0VBQ0UsMENBQTBDO0VBQzFDLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUVFLHNCQUFzQjtFQUV0QixZQUFZO0VBRVosU0FBUztFQUVULFVBQVU7RUFDVjtBQUNGOztBQUVBO0VBS0Usc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixTQUFTO0VBQ1QsZ0NBQWdDO0FBQ2xDOztBQUVBO0VBQ0UsWUFBWTtFQUNaLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFFBQVE7QUFDVjs7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0U7SUFDRSxrQkFBa0I7RUFDcEI7QUFDRjs7QUFFQTs7RUFFRTtJQUNFLG1CQUFtQjtFQUNyQjtBQUNGOztBQUVBOztFQUVFLGdCQUFnQjtFQUNoQixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIscUJBQXFCOztBQUV2Qjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLG9HQUFvRztFQUNwRyxvR0FBaUc7S0FBakcsaUdBQWlHO0VBQ2pHOzs7bURBR2lEO0VBQ2pELDhDQUE4Qzs7QUFFaEQ7O0FBRUE7RUFDRSxVQUFVO0VBQ1YsY0FBYztFQUNkLDBDQUEwQztBQUM1Qzs7QUFFQTtFQUNFLFVBQVU7RUFDViw4QkFBOEI7RUFDOUIsWUFBWTtFQUNaLGNBQWM7O0VBRWQsWUFBWTtFQUNaLHVCQUF1QjtFQUN2Qjs7bUZBRWlGO0VBQ2pGLDBDQUEwQztFQUMxQyxrQ0FBa0M7RUFDbEMsbUZBQW1GO0FBQ3JGOztBQUVBO0VBQ0UsVUFBVTtFQUNWLFNBQVM7QUFDWDs7QUFHQTtFQUNFLFVBQVU7RUFDViw4QkFBOEI7RUFDOUIsWUFBWTtFQUNaLGNBQWM7O0VBRWQsWUFBWTtFQUNaLHdCQUF3QjtFQUN4Qjs7MEVBRXdFO0VBQ3hFLDBDQUEwQztFQUMxQyxrQ0FBa0M7RUFDbEMsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWjs4RUFDNEU7RUFDNUUsNkJBQTZCO0VBQzdCLHFCQUFxQjtFQUNyQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsUUFBUTtBQUNWOztBQUVBO0VBQ0UsNEVBQTRFO0FBQzlFOztBQUdBLGFBQWE7O0FBQ2I7RUFDRSxNQUFNO0VBQ04sT0FBTztFQUNQLFFBQVE7RUFDUixTQUFTO0VBQ1QscUNBQXFDO0VBQ3JDLHlDQUF5QztFQUN6QyxVQUFVO0FBQ1o7O0FBRUE7RUFDRTtJQUNFLGVBQWU7SUFDZiwyQkFBMkI7RUFDN0I7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsMkJBQTJCO0VBQzdCO0FBQ0Y7O0FBRUE7O0VBRUUsVUFBVTtBQUNaOztBQUVBOztFQUVFLFdBQVc7RUFDWCxZQUFZOztBQUVkOztBQUVBLG9CQUFvQjs7QUFDcEI7RUFDRSxnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLHFCQUFxQjtFQUNyQix1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIscUJBQXFCO0VBQ3JCLGFBQWE7RUFDYixXQUFXO0VBQ1gsWUFBWTtFQUNaLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsVUFBVTtBQUNaOztBQUVBO0VBQ0UsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLDhCQUE4QjtFQUM5Qiw0QkFBNEI7QUFDOUI7O0FBRUE7RUFDRSwrSEFBK0g7RUFDL0gsc0JBQXNCO0FBQ3hCOztBQUVBOztFQUVFLHFCQUFxQjtBQUN2Qjs7QUFFQTs7RUFFRSxXQUFXO0VBQ1gsT0FBTztBQUNUOztBQUVBO0VBQ0UsV0FBVztFQUNYLDBCQUEwQjtBQUM1Qjs7QUFFQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxzQkFBc0I7RUFDdEIseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0Usc0JBQXNCO0VBQ3RCLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLG1DQUFtQztBQUNyQzs7QUFFQTtFQUNFLHNCQUFzQjtBQUN4Qjs7QUFFQTs7OztFQUlFLHdCQUF3QjtBQUMxQjs7QUFFQTs7RUFFRTs7Ozs7SUFLRSxtRUFBbUU7SUFDbkUsK0JBQStCO0VBQ2pDOztFQUVBOztJQUVFLG1FQUFtRTtJQUNuRSxtQ0FBbUM7RUFDckM7O0VBRUE7SUFDRSxtRUFBbUU7SUFDbkUsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0Usa0NBQWtDO0VBQ3BDO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBc0I7RUFDdEIsK0JBQStCO0FBQ2pDOztBQUVBOztFQUVFOzs7SUFHRSxVQUFVO0VBQ1o7O0VBRUE7O0lBRUUsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBcUI7QUFDdkI7O0FBRUEsNkVBQTZFOztBQUU3RTtFQUNFO0lBQ0UsMkJBQTJCO0VBQzdCOztFQUVBO0lBQ0Usb0NBQW9DO0VBQ3RDOztFQUVBO0lBQ0UsMkJBQTJCO0VBQzdCO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRTtJQUNFLDJCQUEyQjtFQUM3Qjs7RUFFQTtJQUNFLGlDQUFpQztFQUNuQzs7RUFFQTtJQUNFLGlDQUFpQztFQUNuQzs7RUFFQTtJQUNFLGlDQUFpQztFQUNuQzs7RUFFQTtJQUNFLGdDQUFnQztFQUNsQzs7RUFFQTtJQUNFLGdDQUFnQztFQUNsQzs7RUFFQTtJQUNFLDJCQUEyQjtFQUM3QjtBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0FBQzVCOztBQUVBOztFQUVFOztJQUVFLCtCQUErQjtFQUNqQzs7RUFFQTs7Ozs7SUFLRSxtQ0FBbUM7RUFDckM7O0VBRUE7Ozs7SUFJRSxrQ0FBa0M7RUFDcEM7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtBQUN2Qjs7QUFFQTtFQUNFO0lBQ0Usd0JBQXdCO0VBQzFCOztFQUVBO0lBQ0UsMENBQTBDO0VBQzVDOztFQUVBO0lBQ0Usd0NBQXdDO0VBQzFDOztFQUVBO0lBQ0UsMENBQTBDO0VBQzVDOztFQUVBO0lBQ0Usd0NBQXdDO0VBQzFDOztFQUVBO0lBQ0Usd0JBQXdCO0VBQzFCO0FBQ0Y7O0FBRUE7RUFDRSxzQ0FBc0M7RUFDdEMseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0U7SUFDRSxtQ0FBbUM7RUFDckM7O0VBRUE7SUFDRSxvQ0FBb0M7RUFDdEM7O0VBRUE7SUFDRSxrQ0FBa0M7RUFDcEM7O0VBRUE7SUFDRSxtQ0FBbUM7RUFDckM7O0VBRUE7SUFDRSxrQ0FBa0M7RUFDcEM7QUFDRjs7QUFFQTtFQUNFLDRCQUE0QjtFQUM1QixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRTtJQUNFLDJCQUEyQjtFQUM3Qjs7RUFFQTs7SUFFRSx1REFBdUQ7RUFDekQ7O0VBRUE7Ozs7SUFJRSx5REFBeUQ7RUFDM0Q7O0VBRUE7OztJQUdFLDBEQUEwRDtFQUM1RDs7RUFFQTtJQUNFLDJCQUEyQjtFQUM3QjtBQUNGOztBQUVBO0VBQ0Usb0JBQW9CO0FBQ3RCOztBQUVBLDZFQUE2RTs7QUFFN0U7RUFDRTtJQUNFLGVBQWU7RUFDakI7O0VBRUE7SUFDRSwyREFBMkQ7RUFDN0Q7O0VBRUE7SUFDRSx5REFBeUQ7RUFDM0Q7O0VBRUE7SUFDRSwyREFBMkQ7RUFDN0Q7O0VBRUE7SUFDRSx5REFBeUQ7RUFDM0Q7O0VBRUE7SUFDRSwwREFBMEQ7RUFDNUQ7O0VBRUE7SUFDRSxlQUFlO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7O0VBRUU7OztJQUdFLGVBQWU7RUFDakI7O0VBRUE7SUFDRSwwQ0FBMEM7RUFDNUM7O0VBRUE7SUFDRSx3Q0FBd0M7RUFDMUM7O0VBRUE7SUFDRSw0Q0FBNEM7RUFDOUM7O0VBRUE7SUFDRSw0Q0FBNEM7RUFDOUM7O0VBRUE7SUFDRSxnREFBZ0Q7RUFDbEQ7O0VBRUE7SUFDRSxnREFBZ0Q7RUFDbEQ7O0VBRUE7SUFDRSxvREFBb0Q7RUFDdEQ7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQix3QkFBd0I7QUFDMUI7O0FBRUE7O0VBRUU7Ozs7OztJQU1FLG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDViw4QkFBOEI7RUFDaEM7O0VBRUE7SUFDRSxpQ0FBaUM7RUFDbkM7O0VBRUE7SUFDRSw4QkFBOEI7RUFDaEM7O0VBRUE7SUFDRSxVQUFVO0lBQ1Ysb0NBQW9DO0VBQ3RDOztFQUVBO0lBQ0UsaUNBQWlDO0VBQ25DOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDJCQUEyQjtFQUM3QjtBQUNGOztBQUVBO0VBQ0Usd0JBQXdCO0FBQzFCOztBQUVBOztFQUVFOzs7OztJQUtFLG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDVixxQ0FBcUM7RUFDdkM7O0VBRUE7SUFDRSxVQUFVO0lBQ1Ysa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0UsaUNBQWlDO0VBQ25DOztFQUVBO0lBQ0UsZUFBZTtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsNEJBQTRCO0FBQzlCOztBQUVBOztFQUVFOzs7OztJQUtFLG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDVixxQ0FBcUM7RUFDdkM7O0VBRUE7SUFDRSxVQUFVO0lBQ1Ysa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0UsaUNBQWlDO0VBQ25DOztFQUVBO0lBQ0UsZUFBZTtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsNEJBQTRCO0FBQzlCOztBQUVBOztFQUVFOzs7OztJQUtFLG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0Usa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0Usa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsZUFBZTtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsNkJBQTZCO0FBQy9COztBQUVBOztFQUVFOzs7OztJQUtFLG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0Usa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0Usa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsK0JBQStCO0VBQ2pDO0FBQ0Y7O0FBRUE7RUFDRSwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRTtJQUNFLDhCQUE4QjtFQUNoQzs7RUFFQTs7SUFFRSxVQUFVO0lBQ1YsaUNBQWlDO0VBQ25DOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDhCQUE4QjtFQUNoQztBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0U7SUFDRSxrQ0FBa0M7RUFDcEM7O0VBRUE7O0lBRUUsVUFBVTtJQUNWLG1DQUFtQztFQUNyQzs7RUFFQTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7QUFDRjs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLGtDQUFrQztFQUNwQzs7RUFFQTtJQUNFLFVBQVU7SUFDVixxQ0FBcUM7RUFDdkM7QUFDRjs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLG1DQUFtQztFQUNyQzs7RUFFQTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7QUFDRjs7QUFFQTtFQUNFLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFO0lBQ0UsbUNBQW1DO0VBQ3JDOztFQUVBOztJQUVFLFVBQVU7SUFDVixrQ0FBa0M7RUFDcEM7O0VBRUE7SUFDRSxVQUFVO0lBQ1YscUNBQXFDO0VBQ3ZDO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7RUFDWjs7RUFFQTtJQUNFLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0Usc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1YsbUNBQW1DO0VBQ3JDOztFQUVBO0lBQ0UsVUFBVTtJQUNWLGVBQWU7RUFDakI7QUFDRjs7QUFFQTtFQUNFLDBCQUEwQjtBQUM1Qjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLHFDQUFxQztFQUN2Qzs7RUFFQTtJQUNFLFVBQVU7SUFDVixlQUFlO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7SUFDVixtQ0FBbUM7RUFDckM7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsZUFBZTtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0FBQzVCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1YscUNBQXFDO0VBQ3ZDOztFQUVBO0lBQ0UsVUFBVTtJQUNWLGVBQWU7RUFDakI7QUFDRjs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLGtDQUFrQztFQUNwQzs7RUFFQTtJQUNFLFVBQVU7SUFDVixlQUFlO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsZUFBZTtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1Ysa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsVUFBVTtJQUNWLGVBQWU7RUFDakI7QUFDRjs7QUFFQTtFQUNFLHdCQUF3QjtBQUMxQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLG9DQUFvQztFQUN0Qzs7RUFFQTtJQUNFLFVBQVU7SUFDVixlQUFlO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7RUFDWjs7RUFFQTtJQUNFLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxVQUFVO0lBQ1Ysa0NBQWtDO0VBQ3BDO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7RUFDWjs7RUFFQTtJQUNFLFVBQVU7SUFDVixvQ0FBb0M7RUFDdEM7QUFDRjs7QUFFQTtFQUNFLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtFQUNaOztFQUVBO0lBQ0UsVUFBVTtJQUNWLG1DQUFtQztFQUNyQztBQUNGOztBQUVBO0VBQ0UsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxVQUFVO0lBQ1YscUNBQXFDO0VBQ3ZDO0FBQ0Y7O0FBRUE7RUFDRSw4QkFBOEI7QUFDaEM7O0FBRUE7RUFDRTtJQUNFLFVBQVU7RUFDWjs7RUFFQTtJQUNFLFVBQVU7SUFDVixrQ0FBa0M7RUFDcEM7QUFDRjs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5Qjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtFQUNaOztFQUVBO0lBQ0UsVUFBVTtJQUNWLG9DQUFvQztFQUN0QztBQUNGOztBQUVBO0VBQ0UsK0JBQStCO0FBQ2pDOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsbUNBQW1DO0VBQ3JDO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7RUFDWjs7RUFFQTtJQUNFLFVBQVU7SUFDVixxQ0FBcUM7RUFDdkM7QUFDRjs7QUFFQTtFQUNFLDRCQUE0QjtBQUM5Qjs7QUFFQTtFQUNFO0lBQ0Usd0RBQXdEO0lBQ3hELG1DQUFtQztFQUNyQzs7RUFFQTtJQUNFLGlGQUFpRjtJQUNqRixtQ0FBbUM7RUFDckM7O0VBRUE7SUFDRSxpRkFBaUY7SUFDakYsa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0Usb0RBQW9EO0lBQ3BELGtDQUFrQztFQUNwQzs7RUFFQTtJQUNFLDZCQUE2QjtJQUM3QixrQ0FBa0M7RUFDcEM7QUFDRjs7QUFFQTtFQUNFLG9DQUFvQztFQUNwQyw0QkFBNEI7RUFDNUIsb0JBQW9CO0FBQ3RCOztBQUVBO0VBQ0U7SUFDRSxzREFBc0Q7SUFDdEQsa0NBQWtDO0lBQ2xDLFVBQVU7RUFDWjs7RUFFQTtJQUNFLHVEQUF1RDtJQUN2RCxrQ0FBa0M7RUFDcEM7O0VBRUE7SUFDRSxzREFBc0Q7SUFDdEQsVUFBVTtFQUNaOztFQUVBO0lBQ0Usc0RBQXNEO0VBQ3hEOztFQUVBO0lBQ0UsNkJBQTZCO0VBQy9CO0FBQ0Y7O0FBRUE7RUFDRSwrQ0FBK0M7RUFDL0MsdUNBQXVDO0VBQ3ZDLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFO0lBQ0Usc0RBQXNEO0lBQ3RELGtDQUFrQztJQUNsQyxVQUFVO0VBQ1o7O0VBRUE7SUFDRSx1REFBdUQ7SUFDdkQsa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0Usc0RBQXNEO0lBQ3RELFVBQVU7RUFDWjs7RUFFQTtJQUNFLHNEQUFzRDtFQUN4RDs7RUFFQTtJQUNFLDZCQUE2QjtFQUMvQjtBQUNGOztBQUVBO0VBQ0UsK0NBQStDO0VBQy9DLHVDQUF1QztFQUN2Qyx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRTtJQUNFLDZCQUE2QjtFQUMvQjs7RUFFQTtJQUNFLHVEQUF1RDtJQUN2RCxVQUFVO0VBQ1o7O0VBRUE7SUFDRSxzREFBc0Q7SUFDdEQsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBd0I7RUFDeEIsK0NBQStDO0VBQy9DLHVDQUF1QztBQUN6Qzs7QUFFQTtFQUNFO0lBQ0UsNkJBQTZCO0VBQy9COztFQUVBO0lBQ0UsdURBQXVEO0lBQ3ZELFVBQVU7RUFDWjs7RUFFQTtJQUNFLHNEQUFzRDtJQUN0RCxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLCtDQUErQztFQUMvQyx1Q0FBdUM7RUFDdkMsd0JBQXdCO0FBQzFCOztBQUVBO0VBQ0U7SUFDRSxnREFBZ0Q7SUFDaEQsVUFBVTtFQUNaOztFQUVBO0lBQ0UsdUJBQXVCO0lBQ3ZCLFVBQVU7RUFDWjs7RUFFQTtJQUNFLHVCQUF1QjtJQUN2QixVQUFVO0VBQ1o7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBNEI7RUFDNUIsbUNBQW1DO0FBQ3JDOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0VBQ1o7O0VBRUE7SUFDRSwrQ0FBK0M7SUFDL0MsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSw2QkFBNkI7RUFDN0Isa0NBQWtDO0FBQ3BDOztBQUVBO0VBQ0U7SUFDRSx3QkFBd0I7SUFDeEIscUNBQXFDO0lBQ3JDLFVBQVU7RUFDWjs7RUFFQTtJQUNFLHdCQUF3QjtJQUN4QixlQUFlO0lBQ2YsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBd0I7QUFDMUI7O0FBRUE7RUFDRTtJQUNFLDZCQUE2QjtJQUM3QixvQ0FBb0M7SUFDcEMsVUFBVTtFQUNaOztFQUVBO0lBQ0UsNkJBQTZCO0lBQzdCLGVBQWU7SUFDZixVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFO0lBQ0UsOEJBQThCO0lBQzlCLG1DQUFtQztJQUNuQyxVQUFVO0VBQ1o7O0VBRUE7SUFDRSw4QkFBOEI7SUFDOUIsZUFBZTtJQUNmLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0UsaUNBQWlDO0FBQ25DOztBQUVBO0VBQ0U7SUFDRSw2QkFBNkI7SUFDN0IsbUNBQW1DO0lBQ25DLFVBQVU7RUFDWjs7RUFFQTtJQUNFLDZCQUE2QjtJQUM3QixlQUFlO0lBQ2YsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSw4QkFBOEI7QUFDaEM7O0FBRUE7RUFDRTtJQUNFLDhCQUE4QjtJQUM5QixvQ0FBb0M7SUFDcEMsVUFBVTtFQUNaOztFQUVBO0lBQ0UsOEJBQThCO0lBQzlCLGVBQWU7SUFDZixVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLCtCQUErQjtBQUNqQzs7QUFFQTtFQUNFO0lBQ0Usd0JBQXdCO0lBQ3hCLFVBQVU7RUFDWjs7RUFFQTtJQUNFLHdCQUF3QjtJQUN4QixvQ0FBb0M7SUFDcEMsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRTtJQUNFLDZCQUE2QjtJQUM3QixVQUFVO0VBQ1o7O0VBRUE7SUFDRSw2QkFBNkI7SUFDN0IsbUNBQW1DO0lBQ25DLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0UsaUNBQWlDO0FBQ25DOztBQUVBO0VBQ0U7SUFDRSw4QkFBOEI7SUFDOUIsVUFBVTtFQUNaOztFQUVBO0lBQ0UsOEJBQThCO0lBQzlCLG9DQUFvQztJQUNwQyxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLGtDQUFrQztBQUNwQzs7QUFFQTtFQUNFO0lBQ0UsNkJBQTZCO0lBQzdCLFVBQVU7RUFDWjs7RUFFQTtJQUNFLDZCQUE2QjtJQUM3QixvQ0FBb0M7SUFDcEMsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBK0I7QUFDakM7O0FBRUE7RUFDRTtJQUNFLDhCQUE4QjtJQUM5QixVQUFVO0VBQ1o7O0VBRUE7SUFDRSw4QkFBOEI7SUFDOUIsbUNBQW1DO0lBQ25DLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0UsZ0NBQWdDO0FBQ2xDOztBQUVBO0VBQ0U7SUFDRSwwQkFBMEI7SUFDMUIsc0NBQXNDO0VBQ3hDOztFQUVBOztJQUVFLG1DQUFtQztJQUNuQywwQkFBMEI7SUFDMUIsc0NBQXNDO0VBQ3hDOztFQUVBOztJQUVFLG1DQUFtQztJQUNuQywwQkFBMEI7SUFDMUIsc0NBQXNDO0lBQ3RDLFVBQVU7RUFDWjs7RUFFQTtJQUNFLG1DQUFtQztJQUNuQyxVQUFVO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtBQUN2Qjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLG1DQUFtQztJQUNuQywrQkFBK0I7RUFDakM7O0VBRUE7SUFDRSx5QkFBeUI7RUFDM0I7O0VBRUE7SUFDRSx1QkFBdUI7RUFDekI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsbUJBQW1CO0VBQ3JCO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBNEI7QUFDOUI7O0FBRUEsNkVBQTZFOztBQUU3RTtFQUNFO0lBQ0UsVUFBVTtJQUNWLDhEQUE4RDtFQUNoRTs7RUFFQTtJQUNFLFVBQVU7SUFDVixlQUFlO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUEsNkVBQTZFOztBQUU3RTtFQUNFO0lBQ0UsVUFBVTtFQUNaOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDREQUE0RDtFQUM5RDtBQUNGOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1YsOEJBQThCO0VBQ2hDOztFQUVBO0lBQ0UsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRTtJQUNFLFVBQVU7SUFDVix5REFBeUQ7SUFDekQsbUVBQW1FO0VBQ3JFOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDREQUE0RDtJQUM1RCwrREFBK0Q7RUFDakU7QUFDRjs7QUFFQTtFQUNFLDBCQUEwQjtBQUM1Qjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLHlEQUF5RDtJQUN6RCxtRUFBbUU7RUFDckU7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsNERBQTREO0lBQzVELCtEQUErRDtFQUNqRTtBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0FBQzVCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1Ysd0RBQXdEO0lBQ3hELG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDViw2REFBNkQ7SUFDN0QsK0RBQStEO0VBQ2pFO0FBQ0Y7O0FBRUE7RUFDRSwyQkFBMkI7QUFDN0I7O0FBRUE7RUFDRTtJQUNFLFVBQVU7SUFDVix3REFBd0Q7SUFDeEQsbUVBQW1FO0VBQ3JFOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDZEQUE2RDtJQUM3RCwrREFBK0Q7RUFDakU7QUFDRjs7QUFFQTtFQUNFLHdCQUF3QjtBQUMxQjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtFQUNaOztFQUVBO0lBQ0UsVUFBVTtJQUNWLDhCQUE4QjtFQUNoQzs7RUFFQTtJQUNFLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1YsNkRBQTZEO0lBQzdELG1FQUFtRTtFQUNyRTs7RUFFQTtJQUNFLFVBQVU7SUFDVix3REFBd0Q7SUFDeEQsK0JBQStCO0lBQy9CLCtEQUErRDtFQUNqRTtBQUNGOztBQUVBO0VBQ0UsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0U7SUFDRSxVQUFVO0lBQ1YsNERBQTREO0VBQzlEOztFQUVBO0lBQ0UsVUFBVTtJQUNWLCtDQUErQztJQUMvQyw2QkFBNkI7RUFDL0I7QUFDRjs7QUFFQTtFQUNFLDJCQUEyQjtBQUM3Qjs7QUFFQTtFQUNFO0lBQ0UsVUFBVTtJQUNWLDZEQUE2RDtFQUMvRDs7RUFFQTtJQUNFLFVBQVU7SUFDViw4Q0FBOEM7SUFDOUMsOEJBQThCO0VBQ2hDO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBNEI7QUFDOUI7O0FBRUE7RUFDRTtJQUNFLFVBQVU7SUFDViw0REFBNEQ7SUFDNUQsbUVBQW1FO0VBQ3JFOztFQUVBO0lBQ0UsVUFBVTtJQUNWLHlEQUF5RDtJQUN6RCwrQkFBK0I7SUFDL0IsK0RBQStEO0VBQ2pFO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRTtJQUNFLG1DQUFtQztJQUNuQyxtQkFBbUI7RUFDckI7O0VBRUE7SUFDRSwrQkFBK0I7RUFDakM7QUFDRjs7QUFFQTtFQUNFLDJCQUEyQjtBQUM3Qjs7QUFFQTtFQUNFO0lBQ0UsbUNBQW1DO0lBQ25DLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLCtCQUErQjtFQUNqQztBQUNGOztBQUVBO0VBQ0UsMkJBQTJCO0FBQzdCOztBQUVBO0VBQ0U7SUFDRSxrQ0FBa0M7SUFDbEMsbUJBQW1CO0VBQ3JCOztFQUVBO0lBQ0UsK0JBQStCO0VBQ2pDO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBNEI7QUFDOUI7O0FBRUE7RUFDRTtJQUNFLGtDQUFrQztJQUNsQyxtQkFBbUI7RUFDckI7O0VBRUE7SUFDRSwrQkFBK0I7RUFDakM7QUFDRjs7QUFFQTtFQUNFLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFO0lBQ0UsK0JBQStCO0VBQ2pDOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLGtDQUFrQztFQUNwQztBQUNGOztBQUVBO0VBQ0UsNEJBQTRCO0FBQzlCOztBQUVBO0VBQ0U7SUFDRSwrQkFBK0I7RUFDakM7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsbUNBQW1DO0VBQ3JDO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBNEI7QUFDOUI7O0FBRUE7RUFDRTtJQUNFLCtCQUErQjtFQUNqQzs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixrQ0FBa0M7RUFDcEM7QUFDRjs7QUFFQTtFQUNFLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFO0lBQ0UsK0JBQStCO0VBQ2pDOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLG1DQUFtQztFQUNyQztBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0FBQzVCOztBQUNBO0VBQ0UsU0FBUztFQUNULGtMQUFrTDtFQUNsTCxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLHlCQUF5QjtBQUMzQjs7QUFFQTs7RUFFRSxnQkFBZ0I7QUFDbEI7O0FBRUE7O0VBRUUsbUJBQW1CO0FBQ3JCOztBQUlBO0VBQ0Usa0JBQWtCO0VBRWxCLGFBQWE7RUFFYixzQkFBc0I7RUFDdEIsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQixzQkFBc0I7RUFDdEIsMkJBQTJCO0VBQzNCLGtDQUFrQztFQUNsQyx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBQ0E7RUFFRSxjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtBQUNwQjs7QUFFQTs7RUFFRSxZQUFZO0FBQ2Q7O0FBRUE7TUFDTSxVQUFVO0FBQ2hCOztBQUVBO0VBQ0UsZ0NBQWdDO0VBQ2hDLFVBQVU7QUFDWjs7QUFFQTs7RUFFRSxVQUFVO0FBQ1o7O0FBRUE7RUFDRSxzQkFBc0I7RUFDdEIsVUFBVTtFQUNWLG1CQUFtQjtBQUNyQjs7QUFDQTs7RUFFRSxVQUFVO0FBQ1o7O0FBRUE7O0VBRUUsZ0NBQWdDO0FBQ2xDOztBQUVBO0VBQ0UsZ0JBQWdCO0FBQ2xCOztBQUdBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixZQUFZO0FBQ2Q7O0FBR0E7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsa0JBQWtCOztBQUVwQjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixVQUFVO0FBQ1o7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsbUJBQW1COztBQUVyQjs7QUFDQTtFQUNFLFdBQVc7OztBQUdiOztBQUNBO0VBQ0UsV0FBVztFQUNYLGVBQWU7QUFDakI7O0FBQ0E7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLHdCQUF3QjtFQUN4QixzQkFBc0I7QUFDeEI7O0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsaUJBQWlCO0VBQ2pCLHFCQUFxQjtFQUNyQixZQUFZO0FBQ2Q7O0FBQ0E7RUFDRSxlQUFlO0FBQ2pCOztBQUNBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGVBQWU7QUFDbkI7O0FBR0E7SUFDSSxtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCOztBQUlBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtCQUFrQjs7QUFFcEI7O0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEIiLCJmaWxlIjoibGFuZGluZy1wYWdlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJib2R5IHtcbiAgLyogZm9udC1mYW1pbHk6ICdNZXJpZW5kYSc7ICovXG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgXG59XG5cbi5zcGFjZXJ7XG4gIGZsZXg6IDEgMSBhdXRvO1xufVxuXG5cbi5tYXQtdG9vbGJhci1zaW5nbGUtcm93IHtcbiAgaGVpZ2h0OiA3NXB4O1xuICBwYWRkaW5nOiAwO1xufVxuLm1hdC10b29sYmFyLm1hdC1wcmltYXJ5e1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzgzYTQ4O1xufVxuLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2UtbGVnYWN5IC5tYXQtZm9ybS1maWVsZC13cmFwcGVyIHtcbiAgcGFkZGluZy1ib3R0b206IDEuMmVtO1xufVxuLmNhdGVne1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLm1hdC1mb3JtLWZpZWxkIHtcbiAgZm9udC1zaXplOiBtZWRpdW07XG4gIFxufVxuLm5hdmJhciB7XG4gIFxuICBkaXNwbGF5OiBmbGV4O1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIFxufVxuXG4ucmVnLWJ1dHRvbntcbiAgbWFyZ2luLWxlZnQ6OXB4O1xufVxuXG4uZmFkZS1vdXQge1xuICBhbmltYXRpb246IGZhZGVPdXQgMnM7XG4gIG9wYWNpdHk6IDA7XG59XG5cblxuQGtleWZyYW1lcyBmYWRlT3V0IHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5cbi5mYWRlSW4ge1xuICBhbmltYXRpb246IGZhZGUgNXM7XG59XG5cbkBrZXlmcmFtZXMgZmFkZSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG5cbiAgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG4uVGl0bGUge1xuICAvKiBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlOyAqL1xuICBmb250LXNpemU6IDE1MCU7XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5uYXZiYXItYnJhbmQge1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDBweDtcbn1cblxuLlRpdGxlIDpob3ZlcntcbiAgY29sb3I6IHJnYigyMTAsIDI5LCA0MSk7XG59XG4ucmlnaHROYXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHJpZ2h0O1xuICBwYWRkaW5nOiAxMHB4O1xufVxuXG4ubmF2LWl0ZW0ge1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xuICBwYWRkaW5nLWxlZnQ6IDEycHg7XG59XG5cbi5mbGFnIHtcbiAgbWF4LWhlaWdodDogMjBweDtcbiAgbWF4LXdpZHRoOiAyMHB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4ubmF2LWxpbmsuYWN0aXZlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmV5ICFpbXBvcnRhbnQ7XG59XG5cbi5jb250ZW50LW1pZC1ib2R5IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMjAsIDIzMiwgMjM1LCAwLjcpO1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG59XG5cbi5jYXJkLWJvZHkge1xuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAxcyBlYXNlO1xuICAvKiBTYWZhcmkgYW5kIENocm9tZSAqL1xuICAtbW96LXRyYW5zaXRpb246IGFsbCAxcyBlYXNlO1xuICAvKiBGaXJlZm94ICovXG4gIC1vLXRyYW5zaXRpb246IGFsbCAxcyBlYXNlO1xuICAvKiBJRSA5ICovXG4gIC1tcy10cmFuc2l0aW9uOiBhbGwgMXMgZWFzZTtcbiAgLyogT3BlcmEgKi9cbiAgdHJhbnNpdGlvbjogYWxsIDFzIGVhc2Vcbn1cblxuLmNhcmQtYm9keTpob3ZlciB7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxLjA1KTtcbiAgLW1vei10cmFuc2Zvcm06IHNjYWxlKDEuMDUpO1xuICAtby10cmFuc2Zvcm06IHNjYWxlKDEuMDUpO1xuICAtbXMtdHJhbnNmb3JtOiBzY2FsZSgxLjA1KTtcbiAgdHJhbnNmb3JtOiBzY2FsZSgxLjA1KTtcbn1cblxuLnByZW5vdGEtdGV4dCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA0MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG5cbi5pbWFnZS1wcmVub3RhIHtcbiAgb3BhY2l0eTogMC40O1xuICBtYXgtaGVpZ2h0OiA3NTBweDtcbn1cblxuLmNhcm91c2VsLWNhcHRpb24ge1xuICB0b3A6IDQwJTtcbn1cblxuLmltZy1zbGlkZXIge1xuICBtaW4taGVpZ2h0OiAzMjBweDtcbn1cblxuLm5hdk1lbnUge1xuICBwYWRkaW5nLXRvcDogNzVweDtcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbi5jYXJkLWltZy10b3Age1xuICBoZWlnaHQ6IDIwMHB4O1xufVxuXG4ubWFwcGEge1xuICBoZWlnaHQ6IDMyMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoIDogMTkyMHB4KSB7XG4gIC5vbmx5LW1vYmlsZSB7XG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICB9XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGggOiA1MDZweCkge1xuXG4gIC5vbmx5LW1vYmlsZSB7XG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgfVxufVxuXG4uZm9vdGVyIHtcblxuICBtYXJnaW4tdG9wOiAzMHB4O1xuICBwYWRkaW5nLXRvcDogMjBweDtcbn1cblxuLnNvY2lhbC1pY29uIHtcbiAgZm9udC1zaXplOiAyODtcbn1cblxuLmltYWdlLWJveCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uZGVzY3JpcHRpb24ge1xuICBkaXNwbGF5OiBncmlkO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuXG59XG5cbi5oZWFkaW5nIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMnJlbTtcbn1cblxuLmhvdmVyLTQge1xuICBib3JkZXI6IDJweCBzb2xpZDtcbiAgLyogYm9yZGVyLWltYWdlOiByZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KDEzNWRlZywjRjhDQTAwIDAgMTBweCwjRTk3RjAyIDAgMjBweCwjZDMzNDZjIDAgMzBweCkgODsgKi9cbiAgYm9yZGVyLWltYWdlOiByZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzY3YWJjNCAwIDEwcHgsICMxMDk1YzEgMCAyMHB4LCAjNTljOGY3IDAgMzBweCkgODtcbiAgLXdlYmtpdC1tYXNrOlxuICAgIGNvbmljLWdyYWRpZW50KGZyb20gMTgwZGVnIGF0IHRvcCA4cHggcmlnaHQgOHB4LCAjMDAwMCA5MGRlZywgIzAwMCAwKSB2YXIoLS1faSwgMjAwJSkgMCAvMjAwJSB2YXIoLS1faSwgOHB4KSBib3JkZXItYm94IG5vLXJlcGVhdCxcbiAgICBjb25pYy1ncmFkaWVudChhdCBib3R0b20gOHB4IGxlZnQgOHB4LCAjMDAwMCA5MGRlZywgIzAwMCAwKSAwIHZhcigtLV9pLCAyMDAlKS92YXIoLS1faSwgOHB4KSAyMDAlIGJvcmRlci1ib3ggbm8tcmVwZWF0LFxuICAgIGxpbmVhci1ncmFkaWVudCgjMDAwIDAgMCkgcGFkZGluZy1ib3ggbm8tcmVwZWF0O1xuICB0cmFuc2l0aW9uOiAuM3MsIC13ZWJraXQtbWFzay1wb3NpdGlvbiAuM3MgLjNzO1xuXG59XG5cbi5ob3Zlci00OmhvdmVyIHtcbiAgLS1faTogMTAwJTtcbiAgY29sb3I6ICNDQzMzM0Y7XG4gIHRyYW5zaXRpb246IC4zcywgLXdlYmtpdC1tYXNrLXNpemUgLjNzIC4zcztcbn1cblxuLmhvdmVyLTMge1xuICAtLWI6IDAuMWVtO1xuICAvKiB0aGUgdGhpY2tuZXNzIG9mIHRoZSBsaW5lICovXG4gIC0tYzogIzEwOTVjMTtcbiAgLyogdGhlIGNvbG9yICovXG5cbiAgY29sb3I6ICMwMDAwO1xuICBwYWRkaW5nLWJsb2NrOiB2YXIoLS1iKTtcbiAgYmFja2dyb3VuZDpcbiAgICBsaW5lYXItZ3JhZGllbnQodmFyKC0tYykgNTAlLCAjMDAwIDApIDAlIGNhbGMoMTAwJSAtIHZhcigtLV9wLCAwJSkpLzEwMCUgMjAwJSxcbiAgICBsaW5lYXItZ3JhZGllbnQodmFyKC0tYykgMCAwKSAwJSB2YXIoLS1fcCwgMCUpL3ZhcigtLV9wLCAwJSkgdmFyKC0tYikgbm8tcmVwZWF0O1xuICAtd2Via2l0LWJhY2tncm91bmQtY2xpcDogdGV4dCwgcGFkZGluZy1ib3g7XG4gIGJhY2tncm91bmQtY2xpcDogdGV4dCwgcGFkZGluZy1ib3g7XG4gIHRyYW5zaXRpb246IC4zcyB2YXIoLS1fcywgMHMpIGxpbmVhciwgYmFja2dyb3VuZC1zaXplIC4zcyBjYWxjKC4zcyAtIHZhcigtLV9zLCAwcykpO1xufVxuXG4uaG92ZXItMzpob3ZlciB7XG4gIC0tX3A6IDEwMCU7XG4gIC0tX3M6IC4zcztcbn1cblxuXG4uaG92ZXItMiB7XG4gIC0tczogMC4xZW07XG4gIC8qIHRoZSB0aGlja25lc3Mgb2YgdGhlIGxpbmUgKi9cbiAgLS1jOiAjMTA5NWMxO1xuICAvKiB0aGUgY29sb3IgKi9cblxuICBjb2xvcjogIzAwMDA7XG4gIHBhZGRpbmctYm90dG9tOiB2YXIoLS1zKTtcbiAgYmFja2dyb3VuZDpcbiAgICBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHZhcigtLWMpIDUwJSwgIzAwMCAwKSBjYWxjKDEwMCUgLSB2YXIoLS1fcCwgMCUpKS8yMDAlIDEwMCUsXG4gICAgbGluZWFyLWdyYWRpZW50KHZhcigtLWMpIDAgMCkgMCUgMTAwJS92YXIoLS1fcCwgMCUpIHZhcigtLXMpIG5vLXJlcGVhdDtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQsIHBhZGRpbmctYm94O1xuICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQsIHBhZGRpbmctYm94O1xuICB0cmFuc2l0aW9uOiAwLjVzO1xufVxuXG4uaG92ZXItMjpob3ZlciB7XG4gIC0tX3A6IDEwMCVcbn1cblxuLmhvdmVyLTEge1xuICBjb2xvcjogIzAwMDA7XG4gIGJhY2tncm91bmQ6XG4gICAgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjMGU4M2E5IDUwJSwgIzAwMCAwKSB2YXIoLS1fcCwgMTAwJSkvMjAwJSBuby1yZXBlYXQ7XG4gIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xuICBiYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gIHRyYW5zaXRpb246IC40cztcbn1cblxuLmhvdmVyLTE6aG92ZXIge1xuICAtLV9wOiAwJTtcbn1cblxuLmJveGVzIHtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjE5KTtcbn1cblxuXG4vKiBjYXJvdXNlbCAqL1xuLmNhcm91c2VsLWNhcHRpb24ge1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3R0b206IDA7XG4gIC8qIGJhY2tncm91bmQ6IHJnYmEoOSwgMzAsIDYyLCAuNyk7ICovXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoODksIDEzNywgMTU2LCAwLjcpO1xuICB6LWluZGV4OiAxO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNTc2cHgpIHtcbiAgLmNhcm91c2VsLWNhcHRpb24gaDUge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuY2Fyb3VzZWwtY2FwdGlvbiBoMSB7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcbiAgfVxufVxuXG4uY2Fyb3VzZWwtY29udHJvbC1wcmV2LFxuLmNhcm91c2VsLWNvbnRyb2wtbmV4dCB7XG4gIHdpZHRoOiAxMCU7XG59XG5cbi5jYXJvdXNlbC1jb250cm9sLXByZXYtaWNvbixcbi5jYXJvdXNlbC1jb250cm9sLW5leHQtaWNvbiB7XG4gIHdpZHRoOiAxcmVtO1xuICBoZWlnaHQ6IDFyZW07XG5cbn1cblxuLyoqKiBUZXN0aW1vbmlhbCAqKiovXG4udGVzdGltb25pYWwtY2Fyb3VzZWwgLm93bC1kb3RzIHtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnRlc3RpbW9uaWFsLWNhcm91c2VsIC5vd2wtZG90IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbjogMCA1cHg7XG4gIHdpZHRoOiAxNXB4O1xuICBoZWlnaHQ6IDE1cHg7XG4gIGJhY2tncm91bmQ6ICNEREREREQ7XG4gIGJvcmRlci1yYWRpdXM6IDJweDtcbiAgdHJhbnNpdGlvbjogLjVzO1xufVxuXG4udGVzdGltb25pYWwtY2Fyb3VzZWwgLm93bC1kb3QuYWN0aXZlIHtcbiAgd2lkdGg6IDMwcHg7XG4gIGJhY2tncm91bmQ6IHZhcigtLXByaW1hcnkpO1xufVxuXG4udGVzdGltb25pYWwtY2Fyb3VzZWwgLm93bC1pdGVtLmNlbnRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTtcbn1cblxuLnRlc3RpbW9uaWFsLWNhcm91c2VsIC5vd2wtaXRlbSAudGVzdGltb25pYWwtaXRlbSB7XG4gIHRyYW5zaXRpb246IC41cztcbn1cblxuLnRlc3RpbW9uaWFsLWNhcm91c2VsIC5vd2wtaXRlbS5jZW50ZXIgLnRlc3RpbW9uaWFsLWl0ZW0ge1xuICBiYWNrZ3JvdW5kOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDAgMCAzMHB4ICNEREREREQ7XG59XG5cbi5iZy1oZWFkZXIge1xuICAvKiBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQocmdiYSg5LCAzMCwgNjIsIC43KSwgcmdiYSg5LCAzMCwgNjIsIC43KSksIHVybCguLi9pbWcvY2Fyb3VzZWwtMS5qcGcpIGNlbnRlciBjZW50ZXIgbm8tcmVwZWF0OyAqL1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4ubmF2YmFyLWRhcmsgLm5hdmJhci1uYXYgLm5hdi1saW5rOmhvdmVyLFxuLm5hdmJhci1kYXJrIC5uYXZiYXItbmF2IC5uYXYtbGluay5hY3RpdmUge1xuICBjb2xvcjogdmFyKC0tcHJpbWFyeSk7XG59XG5cbi5uYXZiYXItZGFyayAubmF2YmFyLW5hdiAubmF2LWxpbms6aG92ZXI6OmJlZm9yZSxcbi5uYXZiYXItZGFyayAubmF2YmFyLW5hdiAubmF2LWxpbmsuYWN0aXZlOjpiZWZvcmUge1xuICB3aWR0aDogMTAwJTtcbiAgbGVmdDogMDtcbn1cblxuLnRlc3RpbW9uaWFsLWNhcm91c2VsIC5vd2wtZG90LmFjdGl2ZSB7XG4gIHdpZHRoOiAzMHB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1wcmltYXJ5KTtcbn1cblxuLmxpbmstYW5pbWF0ZWQgYSB7XG4gIHRyYW5zaXRpb246IC41cztcbn1cblxuLmxpbmstYW5pbWF0ZWQgYTpob3ZlciB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuLmFuaW1hdGVkIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxcztcbiAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcbn1cblxuLmFuaW1hdGVkIHtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxcztcbiAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcbn1cblxuLmFuaW1hdGVkLmluZmluaXRlIHtcbiAgYW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudDogaW5maW5pdGU7XG59XG5cbi5hbmltYXRlZC5oaW5nZSB7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogMnM7XG59XG5cbi5hbmltYXRlZC5mbGlwT3V0WCxcbi5hbmltYXRlZC5mbGlwT3V0WSxcbi5hbmltYXRlZC5ib3VuY2VJbixcbi5hbmltYXRlZC5ib3VuY2VPdXQge1xuICBhbmltYXRpb24tZHVyYXRpb246IC43NXM7XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlIHtcblxuICBmcm9tLFxuICAyMCUsXG4gIDUzJSxcbiAgODAlLFxuICB0byB7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxMCwgMC4zNTUsIDEuMDAwKTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICB9XG5cbiAgNDAlLFxuICA0MyUge1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjc1NSwgMC4wNTAsIDAuODU1LCAwLjA2MCk7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMzBweCwgMCk7XG4gIH1cblxuICA3MCUge1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjc1NSwgMC4wNTAsIDAuODU1LCAwLjA2MCk7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTVweCwgMCk7XG4gIH1cblxuICA5MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTRweCwgMCk7XG4gIH1cbn1cblxuLmJvdW5jZSB7XG4gIGFuaW1hdGlvbi1uYW1lOiBib3VuY2U7XG4gIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBib3R0b207XG59XG5cbkBrZXlmcmFtZXMgZmxhc2gge1xuXG4gIGZyb20sXG4gIDUwJSxcbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICAyNSUsXG4gIDc1JSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxufVxuXG4uZmxhc2gge1xuICBhbmltYXRpb24tbmFtZTogZmxhc2g7XG59XG5cbi8qIG9yaWdpbmFsbHkgYXV0aG9yZWQgYnkgTmljayBQZXR0aXQgLSBodHRwczovL2dpdGh1Yi5jb20vbmlja3BldHRpdC9nbGlkZSAqL1xuXG5Aa2V5ZnJhbWVzIHB1bHNlIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEsIDEsIDEpO1xuICB9XG5cbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMS4wNSwgMS4wNSwgMS4wNSk7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEsIDEsIDEpO1xuICB9XG59XG5cbi5wdWxzZSB7XG4gIGFuaW1hdGlvbi1uYW1lOiBwdWxzZTtcbn1cblxuQGtleWZyYW1lcyBydWJiZXJCYW5kIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEsIDEsIDEpO1xuICB9XG5cbiAgMzAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMS4yNSwgMC43NSwgMSk7XG4gIH1cblxuICA0MCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCgwLjc1LCAxLjI1LCAxKTtcbiAgfVxuXG4gIDUwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEuMTUsIDAuODUsIDEpO1xuICB9XG5cbiAgNjUlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjk1LCAxLjA1LCAxKTtcbiAgfVxuXG4gIDc1JSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEuMDUsIC45NSwgMSk7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEsIDEsIDEpO1xuICB9XG59XG5cbi5ydWJiZXJCYW5kIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHJ1YmJlckJhbmQ7XG59XG5cbkBrZXlmcmFtZXMgc2hha2Uge1xuXG4gIGZyb20sXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICB9XG5cbiAgMTAlLFxuICAzMCUsXG4gIDUwJSxcbiAgNzAlLFxuICA5MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTEwcHgsIDAsIDApO1xuICB9XG5cbiAgMjAlLFxuICA0MCUsXG4gIDYwJSxcbiAgODAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwcHgsIDAsIDApO1xuICB9XG59XG5cbi5zaGFrZSB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzaGFrZTtcbn1cblxuQGtleWZyYW1lcyBoZWFkU2hha2Uge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApO1xuICB9XG5cbiAgNi41JSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC02cHgpIHJvdGF0ZVkoLTlkZWcpO1xuICB9XG5cbiAgMTguNSUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCg1cHgpIHJvdGF0ZVkoN2RlZyk7XG4gIH1cblxuICAzMS41JSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0zcHgpIHJvdGF0ZVkoLTVkZWcpO1xuICB9XG5cbiAgNDMuNSUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgycHgpIHJvdGF0ZVkoM2RlZyk7XG4gIH1cblxuICA1MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTtcbiAgfVxufVxuXG4uaGVhZFNoYWtlIHtcbiAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XG4gIGFuaW1hdGlvbi1uYW1lOiBoZWFkU2hha2U7XG59XG5cbkBrZXlmcmFtZXMgc3dpbmcge1xuICAyMCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlM2QoMCwgMCwgMSwgMTVkZWcpO1xuICB9XG5cbiAgNDAlIHtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIC0xMGRlZyk7XG4gIH1cblxuICA2MCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlM2QoMCwgMCwgMSwgNWRlZyk7XG4gIH1cblxuICA4MCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlM2QoMCwgMCwgMSwgLTVkZWcpO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogcm90YXRlM2QoMCwgMCwgMSwgMGRlZyk7XG4gIH1cbn1cblxuLnN3aW5nIHtcbiAgdHJhbnNmb3JtLW9yaWdpbjogdG9wIGNlbnRlcjtcbiAgYW5pbWF0aW9uLW5hbWU6IHN3aW5nO1xufVxuXG5Aa2V5ZnJhbWVzIHRhZGEge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMSwgMSwgMSk7XG4gIH1cblxuICAxMCUsXG4gIDIwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC45LCAuOSwgLjkpIHJvdGF0ZTNkKDAsIDAsIDEsIC0zZGVnKTtcbiAgfVxuXG4gIDMwJSxcbiAgNTAlLFxuICA3MCUsXG4gIDkwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEuMSwgMS4xLCAxLjEpIHJvdGF0ZTNkKDAsIDAsIDEsIDNkZWcpO1xuICB9XG5cbiAgNDAlLFxuICA2MCUsXG4gIDgwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKDEuMSwgMS4xLCAxLjEpIHJvdGF0ZTNkKDAsIDAsIDEsIC0zZGVnKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMSwgMSwgMSk7XG4gIH1cbn1cblxuLnRhZGEge1xuICBhbmltYXRpb24tbmFtZTogdGFkYTtcbn1cblxuLyogb3JpZ2luYWxseSBhdXRob3JlZCBieSBOaWNrIFBldHRpdCAtIGh0dHBzOi8vZ2l0aHViLmNvbS9uaWNrcGV0dGl0L2dsaWRlICovXG5cbkBrZXlmcmFtZXMgd29iYmxlIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICB9XG5cbiAgMTUlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yNSUsIDAsIDApIHJvdGF0ZTNkKDAsIDAsIDEsIC01ZGVnKTtcbiAgfVxuXG4gIDMwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyMCUsIDAsIDApIHJvdGF0ZTNkKDAsIDAsIDEsIDNkZWcpO1xuICB9XG5cbiAgNDUlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xNSUsIDAsIDApIHJvdGF0ZTNkKDAsIDAsIDEsIC0zZGVnKTtcbiAgfVxuXG4gIDYwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMCUsIDAsIDApIHJvdGF0ZTNkKDAsIDAsIDEsIDJkZWcpO1xuICB9XG5cbiAgNzUlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC01JSwgMCwgMCkgcm90YXRlM2QoMCwgMCwgMSwgLTFkZWcpO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogbm9uZTtcbiAgfVxufVxuXG4ud29iYmxlIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHdvYmJsZTtcbn1cblxuQGtleWZyYW1lcyBqZWxsbyB7XG5cbiAgZnJvbSxcbiAgMTEuMSUsXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cblxuICAyMi4yJSB7XG4gICAgdHJhbnNmb3JtOiBza2V3WCgtMTIuNWRlZykgc2tld1koLTEyLjVkZWcpO1xuICB9XG5cbiAgMzMuMyUge1xuICAgIHRyYW5zZm9ybTogc2tld1goNi4yNWRlZykgc2tld1koNi4yNWRlZyk7XG4gIH1cblxuICA0NC40JSB7XG4gICAgdHJhbnNmb3JtOiBza2V3WCgtMy4xMjVkZWcpIHNrZXdZKC0zLjEyNWRlZyk7XG4gIH1cblxuICA1NS41JSB7XG4gICAgdHJhbnNmb3JtOiBza2V3WCgxLjU2MjVkZWcpIHNrZXdZKDEuNTYyNWRlZyk7XG4gIH1cblxuICA2Ni42JSB7XG4gICAgdHJhbnNmb3JtOiBza2V3WCgtMC43ODEyNWRlZykgc2tld1koLTAuNzgxMjVkZWcpO1xuICB9XG5cbiAgNzcuNyUge1xuICAgIHRyYW5zZm9ybTogc2tld1goMC4zOTA2MjVkZWcpIHNrZXdZKDAuMzkwNjI1ZGVnKTtcbiAgfVxuXG4gIDg4LjglIHtcbiAgICB0cmFuc2Zvcm06IHNrZXdYKC0wLjE5NTMxMjVkZWcpIHNrZXdZKC0wLjE5NTMxMjVkZWcpO1xuICB9XG59XG5cbi5qZWxsbyB7XG4gIGFuaW1hdGlvbi1uYW1lOiBqZWxsbztcbiAgdHJhbnNmb3JtLW9yaWdpbjogY2VudGVyO1xufVxuXG5Aa2V5ZnJhbWVzIGJvdW5jZUluIHtcblxuICBmcm9tLFxuICAyMCUsXG4gIDQwJSxcbiAgNjAlLFxuICA4MCUsXG4gIHRvIHtcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEwLCAwLjM1NSwgMS4wMDApO1xuICB9XG5cbiAgMCUge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC4zLCAuMywgLjMpO1xuICB9XG5cbiAgMjAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMS4xLCAxLjEsIDEuMSk7XG4gIH1cblxuICA0MCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguOSwgLjksIC45KTtcbiAgfVxuXG4gIDYwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMS4wMywgMS4wMywgMS4wMyk7XG4gIH1cblxuICA4MCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguOTcsIC45NywgLjk3KTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCgxLCAxLCAxKTtcbiAgfVxufVxuXG4uYm91bmNlSW4ge1xuICBhbmltYXRpb24tbmFtZTogYm91bmNlSW47XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlSW5Eb3duIHtcblxuICBmcm9tLFxuICA2MCUsXG4gIDc1JSxcbiAgOTAlLFxuICB0byB7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxMCwgMC4zNTUsIDEuMDAwKTtcbiAgfVxuXG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTMwMDBweCwgMCk7XG4gIH1cblxuICA2MCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyNXB4LCAwKTtcbiAgfVxuXG4gIDc1JSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTBweCwgMCk7XG4gIH1cblxuICA5MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNXB4LCAwKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmJvdW5jZUluRG93biB7XG4gIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VJbkRvd247XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlSW5MZWZ0IHtcblxuICBmcm9tLFxuICA2MCUsXG4gIDc1JSxcbiAgOTAlLFxuICB0byB7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxMCwgMC4zNTUsIDEuMDAwKTtcbiAgfVxuXG4gIDAlIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTMwMDBweCwgMCwgMCk7XG4gIH1cblxuICA2MCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyNXB4LCAwLCAwKTtcbiAgfVxuXG4gIDc1JSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XG4gIH1cblxuICA5MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoNXB4LCAwLCAwKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmJvdW5jZUluTGVmdCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VJbkxlZnQ7XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlSW5SaWdodCB7XG5cbiAgZnJvbSxcbiAgNjAlLFxuICA3NSUsXG4gIDkwJSxcbiAgdG8ge1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjIxNSwgMC42MTAsIDAuMzU1LCAxLjAwMCk7XG4gIH1cblxuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMzAwMHB4LCAwLCAwKTtcbiAgfVxuXG4gIDYwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yNXB4LCAwLCAwKTtcbiAgfVxuXG4gIDc1JSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMHB4LCAwLCAwKTtcbiAgfVxuXG4gIDkwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtNXB4LCAwLCAwKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmJvdW5jZUluUmlnaHQge1xuICBhbmltYXRpb24tbmFtZTogYm91bmNlSW5SaWdodDtcbn1cblxuQGtleWZyYW1lcyBib3VuY2VJblVwIHtcblxuICBmcm9tLFxuICA2MCUsXG4gIDc1JSxcbiAgOTAlLFxuICB0byB7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxMCwgMC4zNTUsIDEuMDAwKTtcbiAgfVxuXG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAzMDAwcHgsIDApO1xuICB9XG5cbiAgNjAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwcHgsIDApO1xuICB9XG5cbiAgNzUlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xuICB9XG5cbiAgOTAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC01cHgsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gIH1cbn1cblxuLmJvdW5jZUluVXAge1xuICBhbmltYXRpb24tbmFtZTogYm91bmNlSW5VcDtcbn1cblxuQGtleWZyYW1lcyBib3VuY2VPdXQge1xuICAyMCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguOSwgLjksIC45KTtcbiAgfVxuXG4gIDUwJSxcbiAgNTUlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCgxLjEsIDEuMSwgMS4xKTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguMywgLjMsIC4zKTtcbiAgfVxufVxuXG4uYm91bmNlT3V0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGJvdW5jZU91dDtcbn1cblxuQGtleWZyYW1lcyBib3VuY2VPdXREb3duIHtcbiAgMjAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xuICB9XG5cbiAgNDAlLFxuICA0NSUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMjBweCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDIwMDBweCwgMCk7XG4gIH1cbn1cblxuLmJvdW5jZU91dERvd24ge1xuICBhbmltYXRpb24tbmFtZTogYm91bmNlT3V0RG93bjtcbn1cblxuQGtleWZyYW1lcyBib3VuY2VPdXRMZWZ0IHtcbiAgMjAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjBweCwgMCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yMDAwcHgsIDAsIDApO1xuICB9XG59XG5cbi5ib3VuY2VPdXRMZWZ0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGJvdW5jZU91dExlZnQ7XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlT3V0UmlnaHQge1xuICAyMCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjBweCwgMCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDIwMDBweCwgMCwgMCk7XG4gIH1cbn1cblxuLmJvdW5jZU91dFJpZ2h0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGJvdW5jZU91dFJpZ2h0O1xufVxuXG5Aa2V5ZnJhbWVzIGJvdW5jZU91dFVwIHtcbiAgMjAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMHB4LCAwKTtcbiAgfVxuXG4gIDQwJSxcbiAgNDUlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjBweCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMDAwcHgsIDApO1xuICB9XG59XG5cbi5ib3VuY2VPdXRVcCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VPdXRVcDtcbn1cblxuQGtleWZyYW1lcyBmYWRlSW4ge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cblxuLmZhZGVJbiB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlSW47XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluRG93biB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTAwJSwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmZhZGVJbkRvd24ge1xuICBhbmltYXRpb24tbmFtZTogZmFkZUluRG93bjtcbn1cblxuQGtleWZyYW1lcyBmYWRlSW5Eb3duQmlnIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMDAwcHgsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICB9XG59XG5cbi5mYWRlSW5Eb3duQmlnIHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJbkRvd25CaWc7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluTGVmdCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTAwJSwgMCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmZhZGVJbkxlZnQge1xuICBhbmltYXRpb24tbmFtZTogZmFkZUluTGVmdDtcbn1cblxuQGtleWZyYW1lcyBmYWRlSW5MZWZ0QmlnIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yMDAwcHgsIDAsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICB9XG59XG5cbi5mYWRlSW5MZWZ0QmlnIHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJbkxlZnRCaWc7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluUmlnaHQge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmZhZGVJblJpZ2h0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJblJpZ2h0O1xufVxuXG5Aa2V5ZnJhbWVzIGZhZGVJblJpZ2h0QmlnIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDIwMDBweCwgMCwgMCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gIH1cbn1cblxuLmZhZGVJblJpZ2h0QmlnIHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVJblJpZ2h0QmlnO1xufVxuXG5Aa2V5ZnJhbWVzIGZhZGVJblVwIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwMCUsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICB9XG59XG5cbi5mYWRlSW5VcCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlSW5VcDtcbn1cblxuQGtleWZyYW1lcyBmYWRlSW5VcEJpZyB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyMDAwcHgsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICB9XG59XG5cbi5mYWRlSW5VcEJpZyB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlSW5VcEJpZztcbn1cblxuQGtleWZyYW1lcyBmYWRlT3V0IHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5cbi5mYWRlT3V0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVPdXQ7XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dERvd24ge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMDAlLCAwKTtcbiAgfVxufVxuXG4uZmFkZU91dERvd24ge1xuICBhbmltYXRpb24tbmFtZTogZmFkZU91dERvd247XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dERvd25CaWcge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyMDAwcHgsIDApO1xuICB9XG59XG5cbi5mYWRlT3V0RG93bkJpZyB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlT3V0RG93bkJpZztcbn1cblxuQGtleWZyYW1lcyBmYWRlT3V0TGVmdCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMDAlLCAwLCAwKTtcbiAgfVxufVxuXG4uZmFkZU91dExlZnQge1xuICBhbmltYXRpb24tbmFtZTogZmFkZU91dExlZnQ7XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dExlZnRCaWcge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjAwMHB4LCAwLCAwKTtcbiAgfVxufVxuXG4uZmFkZU91dExlZnRCaWcge1xuICBhbmltYXRpb24tbmFtZTogZmFkZU91dExlZnRCaWc7XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dFJpZ2h0IHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XG4gIH1cbn1cblxuLmZhZGVPdXRSaWdodCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlT3V0UmlnaHQ7XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dFJpZ2h0QmlnIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjAwMHB4LCAwLCAwKTtcbiAgfVxufVxuXG4uZmFkZU91dFJpZ2h0QmlnIHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZhZGVPdXRSaWdodEJpZztcbn1cblxuQGtleWZyYW1lcyBmYWRlT3V0VXAge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTAwJSwgMCk7XG4gIH1cbn1cblxuLmZhZGVPdXRVcCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlT3V0VXA7XG59XG5cbkBrZXlmcmFtZXMgZmFkZU91dFVwQmlnIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwMDBweCwgMCk7XG4gIH1cbn1cblxuLmZhZGVPdXRVcEJpZyB7XG4gIGFuaW1hdGlvbi1uYW1lOiBmYWRlT3V0VXBCaWc7XG59XG5cbkBrZXlmcmFtZXMgZmxpcCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDAsIDEsIDAsIC0zNjBkZWcpO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0O1xuICB9XG5cbiAgNDAlIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSB0cmFuc2xhdGUzZCgwLCAwLCAxNTBweCkgcm90YXRlM2QoMCwgMSwgMCwgLTE5MGRlZyk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XG4gIH1cblxuICA1MCUge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHRyYW5zbGF0ZTNkKDAsIDAsIDE1MHB4KSByb3RhdGUzZCgwLCAxLCAwLCAtMTcwZGVnKTtcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xuICB9XG5cbiAgODAlIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSBzY2FsZTNkKC45NSwgLjk1LCAuOTUpO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW47XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbiAgfVxufVxuXG4uYW5pbWF0ZWQuZmxpcCB7XG4gIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgYW5pbWF0aW9uLW5hbWU6IGZsaXA7XG59XG5cbkBrZXlmcmFtZXMgZmxpcEluWCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIDkwZGVnKTtcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cblxuICA0MCUge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC0yMGRlZyk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbiAgfVxuXG4gIDYwJSB7XG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgMTBkZWcpO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICA4MCUge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC01ZGVnKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KTtcbiAgfVxufVxuXG4uZmxpcEluWCB7XG4gIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xuICBiYWNrZmFjZS12aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XG4gIGFuaW1hdGlvbi1uYW1lOiBmbGlwSW5YO1xufVxuXG5Aa2V5ZnJhbWVzIGZsaXBJblkge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgwLCAxLCAwLCA5MGRlZyk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG5cbiAgNDAlIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgwLCAxLCAwLCAtMjBkZWcpO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW47XG4gIH1cblxuICA2MCUge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDAsIDEsIDAsIDEwZGVnKTtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgODAlIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgwLCAxLCAwLCAtNWRlZyk7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCk7XG4gIH1cbn1cblxuLmZsaXBJblkge1xuICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IHZpc2libGUgIWltcG9ydGFudDtcbiAgYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xuICBhbmltYXRpb24tbmFtZTogZmxpcEluWTtcbn1cblxuQGtleWZyYW1lcyBmbGlwT3V0WCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpO1xuICB9XG5cbiAgMzAlIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAtMjBkZWcpO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgOTBkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cblxuLmZsaXBPdXRYIHtcbiAgYW5pbWF0aW9uLW5hbWU6IGZsaXBPdXRYO1xuICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IHZpc2libGUgIWltcG9ydGFudDtcbiAgYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xufVxuXG5Aa2V5ZnJhbWVzIGZsaXBPdXRZIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCk7XG4gIH1cblxuICAzMCUge1xuICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDAsIDEsIDAsIC0xNWRlZyk7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgwLCAxLCAwLCA5MGRlZyk7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxufVxuXG4uZmxpcE91dFkge1xuICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IHZpc2libGUgIWltcG9ydGFudDtcbiAgYmFja2ZhY2UtdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xuICBhbmltYXRpb24tbmFtZTogZmxpcE91dFk7XG59XG5cbkBrZXlmcmFtZXMgbGlnaHRTcGVlZEluIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKSBza2V3WCgtMzBkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cblxuICA2MCUge1xuICAgIHRyYW5zZm9ybTogc2tld1goMjBkZWcpO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICA4MCUge1xuICAgIHRyYW5zZm9ybTogc2tld1goLTVkZWcpO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cblxuLmxpZ2h0U3BlZWRJbiB7XG4gIGFuaW1hdGlvbi1uYW1lOiBsaWdodFNwZWVkSW47XG4gIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0O1xufVxuXG5Aa2V5ZnJhbWVzIGxpZ2h0U3BlZWRPdXQge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCkgc2tld1goMzBkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cblxuLmxpZ2h0U3BlZWRPdXQge1xuICBhbmltYXRpb24tbmFtZTogbGlnaHRTcGVlZE91dDtcbiAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbn1cblxuQGtleWZyYW1lcyByb3RhdGVJbiB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIC0yMDBkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogY2VudGVyO1xuICAgIHRyYW5zZm9ybTogbm9uZTtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG59XG5cbi5yb3RhdGVJbiB7XG4gIGFuaW1hdGlvbi1uYW1lOiByb3RhdGVJbjtcbn1cblxuQGtleWZyYW1lcyByb3RhdGVJbkRvd25MZWZ0IHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCBib3R0b207XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCAtNDVkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCBib3R0b207XG4gICAgdHJhbnNmb3JtOiBub25lO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cblxuLnJvdGF0ZUluRG93bkxlZnQge1xuICBhbmltYXRpb24tbmFtZTogcm90YXRlSW5Eb3duTGVmdDtcbn1cblxuQGtleWZyYW1lcyByb3RhdGVJbkRvd25SaWdodCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IHJpZ2h0IGJvdHRvbTtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIDQ1ZGVnKTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IHJpZ2h0IGJvdHRvbTtcbiAgICB0cmFuc2Zvcm06IG5vbmU7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG4ucm90YXRlSW5Eb3duUmlnaHQge1xuICBhbmltYXRpb24tbmFtZTogcm90YXRlSW5Eb3duUmlnaHQ7XG59XG5cbkBrZXlmcmFtZXMgcm90YXRlSW5VcExlZnQge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiBsZWZ0IGJvdHRvbTtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIDQ1ZGVnKTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGxlZnQgYm90dG9tO1xuICAgIHRyYW5zZm9ybTogbm9uZTtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG59XG5cbi5yb3RhdGVJblVwTGVmdCB7XG4gIGFuaW1hdGlvbi1uYW1lOiByb3RhdGVJblVwTGVmdDtcbn1cblxuQGtleWZyYW1lcyByb3RhdGVJblVwUmlnaHQge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiByaWdodCBib3R0b207XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCAtOTBkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogcmlnaHQgYm90dG9tO1xuICAgIHRyYW5zZm9ybTogbm9uZTtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG59XG5cbi5yb3RhdGVJblVwUmlnaHQge1xuICBhbmltYXRpb24tbmFtZTogcm90YXRlSW5VcFJpZ2h0O1xufVxuXG5Aa2V5ZnJhbWVzIHJvdGF0ZU91dCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIDIwMGRlZyk7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxufVxuXG4ucm90YXRlT3V0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IHJvdGF0ZU91dDtcbn1cblxuQGtleWZyYW1lcyByb3RhdGVPdXREb3duTGVmdCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGxlZnQgYm90dG9tO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCBib3R0b207XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCA0NWRlZyk7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxufVxuXG4ucm90YXRlT3V0RG93bkxlZnQge1xuICBhbmltYXRpb24tbmFtZTogcm90YXRlT3V0RG93bkxlZnQ7XG59XG5cbkBrZXlmcmFtZXMgcm90YXRlT3V0RG93blJpZ2h0IHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogcmlnaHQgYm90dG9tO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogcmlnaHQgYm90dG9tO1xuICAgIHRyYW5zZm9ybTogcm90YXRlM2QoMCwgMCwgMSwgLTQ1ZGVnKTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5cbi5yb3RhdGVPdXREb3duUmlnaHQge1xuICBhbmltYXRpb24tbmFtZTogcm90YXRlT3V0RG93blJpZ2h0O1xufVxuXG5Aa2V5ZnJhbWVzIHJvdGF0ZU91dFVwTGVmdCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGxlZnQgYm90dG9tO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCBib3R0b207XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCAtNDVkZWcpO1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cblxuLnJvdGF0ZU91dFVwTGVmdCB7XG4gIGFuaW1hdGlvbi1uYW1lOiByb3RhdGVPdXRVcExlZnQ7XG59XG5cbkBrZXlmcmFtZXMgcm90YXRlT3V0VXBSaWdodCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IHJpZ2h0IGJvdHRvbTtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IHJpZ2h0IGJvdHRvbTtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZTNkKDAsIDAsIDEsIDkwZGVnKTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5cbi5yb3RhdGVPdXRVcFJpZ2h0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IHJvdGF0ZU91dFVwUmlnaHQ7XG59XG5cbkBrZXlmcmFtZXMgaGluZ2Uge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogdG9wIGxlZnQ7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XG4gIH1cblxuICAyMCUsXG4gIDYwJSB7XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCA4MGRlZyk7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogdG9wIGxlZnQ7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XG4gIH1cblxuICA0MCUsXG4gIDgwJSB7XG4gICAgdHJhbnNmb3JtOiByb3RhdGUzZCgwLCAwLCAxLCA2MGRlZyk7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogdG9wIGxlZnQ7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDcwMHB4LCAwKTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG59XG5cbi5oaW5nZSB7XG4gIGFuaW1hdGlvbi1uYW1lOiBoaW5nZTtcbn1cblxuQGtleWZyYW1lcyBqYWNrSW5UaGVCb3gge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMC4xKSByb3RhdGUoMzBkZWcpO1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBib3R0b207XG4gIH1cblxuICA1MCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKC0xMGRlZyk7XG4gIH1cblxuICA3MCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDNkZWcpO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgfVxufVxuXG4uamFja0luVGhlQm94IHtcbiAgYW5pbWF0aW9uLW5hbWU6IGphY2tJblRoZUJveDtcbn1cblxuLyogb3JpZ2luYWxseSBhdXRob3JlZCBieSBOaWNrIFBldHRpdCAtIGh0dHBzOi8vZ2l0aHViLmNvbS9uaWNrcGV0dGl0L2dsaWRlICovXG5cbkBrZXlmcmFtZXMgcm9sbEluIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMDAlLCAwLCAwKSByb3RhdGUzZCgwLCAwLCAxLCAtMTIwZGVnKTtcbiAgfVxuXG4gIHRvIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogbm9uZTtcbiAgfVxufVxuXG4ucm9sbEluIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHJvbGxJbjtcbn1cblxuLyogb3JpZ2luYWxseSBhdXRob3JlZCBieSBOaWNrIFBldHRpdCAtIGh0dHBzOi8vZ2l0aHViLmNvbS9uaWNrcGV0dGl0L2dsaWRlICovXG5cbkBrZXlmcmFtZXMgcm9sbE91dCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDEwMCUsIDAsIDApIHJvdGF0ZTNkKDAsIDAsIDEsIDEyMGRlZyk7XG4gIH1cbn1cblxuLnJvbGxPdXQge1xuICBhbmltYXRpb24tbmFtZTogcm9sbE91dDtcbn1cblxuQGtleWZyYW1lcyB6b29tSW4ge1xuICBmcm9tIHtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguMywgLjMsIC4zKTtcbiAgfVxuXG4gIDUwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG4uem9vbUluIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHpvb21Jbjtcbn1cblxuQGtleWZyYW1lcyB6b29tSW5Eb3duIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjEsIC4xLCAuMSkgdHJhbnNsYXRlM2QoMCwgLTEwMDBweCwgMCk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuNTUwLCAwLjA1NSwgMC42NzUsIDAuMTkwKTtcbiAgfVxuXG4gIDYwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjQ3NSwgLjQ3NSwgLjQ3NSkgdHJhbnNsYXRlM2QoMCwgNjBweCwgMCk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMTc1LCAwLjg4NSwgMC4zMjAsIDEpO1xuICB9XG59XG5cbi56b29tSW5Eb3duIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHpvb21JbkRvd247XG59XG5cbkBrZXlmcmFtZXMgem9vbUluTGVmdCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC4xLCAuMSwgLjEpIHRyYW5zbGF0ZTNkKC0xMDAwcHgsIDAsIDApO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjU1MCwgMC4wNTUsIDAuNjc1LCAwLjE5MCk7XG4gIH1cblxuICA2MCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC40NzUsIC40NzUsIC40NzUpIHRyYW5zbGF0ZTNkKDEwcHgsIDAsIDApO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjE3NSwgMC44ODUsIDAuMzIwLCAxKTtcbiAgfVxufVxuXG4uem9vbUluTGVmdCB7XG4gIGFuaW1hdGlvbi1uYW1lOiB6b29tSW5MZWZ0O1xufVxuXG5Aa2V5ZnJhbWVzIHpvb21JblJpZ2h0IHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjEsIC4xLCAuMSkgdHJhbnNsYXRlM2QoMTAwMHB4LCAwLCAwKTtcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC41NTAsIDAuMDU1LCAwLjY3NSwgMC4xOTApO1xuICB9XG5cbiAgNjAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguNDc1LCAuNDc1LCAuNDc1KSB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMTc1LCAwLjg4NSwgMC4zMjAsIDEpO1xuICB9XG59XG5cbi56b29tSW5SaWdodCB7XG4gIGFuaW1hdGlvbi1uYW1lOiB6b29tSW5SaWdodDtcbn1cblxuQGtleWZyYW1lcyB6b29tSW5VcCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC4xLCAuMSwgLjEpIHRyYW5zbGF0ZTNkKDAsIDEwMDBweCwgMCk7XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuNTUwLCAwLjA1NSwgMC42NzUsIDAuMTkwKTtcbiAgfVxuXG4gIDYwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjQ3NSwgLjQ3NSwgLjQ3NSkgdHJhbnNsYXRlM2QoMCwgLTYwcHgsIDApO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjE3NSwgMC44ODUsIDAuMzIwLCAxKTtcbiAgfVxufVxuXG4uem9vbUluVXAge1xuICBhbmltYXRpb24tbmFtZTogem9vbUluVXA7XG59XG5cbkBrZXlmcmFtZXMgem9vbU91dCB7XG4gIGZyb20ge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cblxuICA1MCUge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC4zLCAuMywgLjMpO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gIH1cbn1cblxuLnpvb21PdXQge1xuICBhbmltYXRpb24tbmFtZTogem9vbU91dDtcbn1cblxuQGtleWZyYW1lcyB6b29tT3V0RG93biB7XG4gIDQwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjQ3NSwgLjQ3NSwgLjQ3NSkgdHJhbnNsYXRlM2QoMCwgLTYwcHgsIDApO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjU1MCwgMC4wNTUsIDAuNjc1LCAwLjE5MCk7XG4gIH1cblxuICB0byB7XG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjEsIC4xLCAuMSkgdHJhbnNsYXRlM2QoMCwgMjAwMHB4LCAwKTtcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiBjZW50ZXIgYm90dG9tO1xuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjE3NSwgMC44ODUsIDAuMzIwLCAxKTtcbiAgfVxufVxuXG4uem9vbU91dERvd24ge1xuICBhbmltYXRpb24tbmFtZTogem9vbU91dERvd247XG59XG5cbkBrZXlmcmFtZXMgem9vbU91dExlZnQge1xuICA0MCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC40NzUsIC40NzUsIC40NzUpIHRyYW5zbGF0ZTNkKDQycHgsIDAsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSguMSkgdHJhbnNsYXRlM2QoLTIwMDBweCwgMCwgMCk7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCBjZW50ZXI7XG4gIH1cbn1cblxuLnpvb21PdXRMZWZ0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IHpvb21PdXRMZWZ0O1xufVxuXG5Aa2V5ZnJhbWVzIHpvb21PdXRSaWdodCB7XG4gIDQwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlM2QoLjQ3NSwgLjQ3NSwgLjQ3NSkgdHJhbnNsYXRlM2QoLTQycHgsIDAsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSguMSkgdHJhbnNsYXRlM2QoMjAwMHB4LCAwLCAwKTtcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiByaWdodCBjZW50ZXI7XG4gIH1cbn1cblxuLnpvb21PdXRSaWdodCB7XG4gIGFuaW1hdGlvbi1uYW1lOiB6b29tT3V0UmlnaHQ7XG59XG5cbkBrZXlmcmFtZXMgem9vbU91dFVwIHtcbiAgNDAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzZCguNDc1LCAuNDc1LCAuNDc1KSB0cmFuc2xhdGUzZCgwLCA2MHB4LCAwKTtcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC41NTAsIDAuMDU1LCAwLjY3NSwgMC4xOTApO1xuICB9XG5cbiAgdG8ge1xuICAgIG9wYWNpdHk6IDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNkKC4xLCAuMSwgLjEpIHRyYW5zbGF0ZTNkKDAsIC0yMDAwcHgsIDApO1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBib3R0b207XG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMTc1LCAwLjg4NSwgMC4zMjAsIDEpO1xuICB9XG59XG5cbi56b29tT3V0VXAge1xuICBhbmltYXRpb24tbmFtZTogem9vbU91dFVwO1xufVxuXG5Aa2V5ZnJhbWVzIHNsaWRlSW5Eb3duIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTAwJSwgMCk7XG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgfVxuXG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICB9XG59XG5cbi5zbGlkZUluRG93biB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluRG93bjtcbn1cblxuQGtleWZyYW1lcyBzbGlkZUluTGVmdCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTEwMCUsIDAsIDApO1xuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XG4gIH1cblxuICB0byB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcbiAgfVxufVxuXG4uc2xpZGVJbkxlZnQge1xuICBhbmltYXRpb24tbmFtZTogc2xpZGVJbkxlZnQ7XG59XG5cbkBrZXlmcmFtZXMgc2xpZGVJblJpZ2h0IHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gIH1cbn1cblxuLnNsaWRlSW5SaWdodCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluUmlnaHQ7XG59XG5cbkBrZXlmcmFtZXMgc2xpZGVJblVwIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMDAlLCAwKTtcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICB9XG5cbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gIH1cbn1cblxuLnNsaWRlSW5VcCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzbGlkZUluVXA7XG59XG5cbkBrZXlmcmFtZXMgc2xpZGVPdXREb3duIHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMDAlLCAwKTtcbiAgfVxufVxuXG4uc2xpZGVPdXREb3duIHtcbiAgYW5pbWF0aW9uLW5hbWU6IHNsaWRlT3V0RG93bjtcbn1cblxuQGtleWZyYW1lcyBzbGlkZU91dExlZnQge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMDAlLCAwLCAwKTtcbiAgfVxufVxuXG4uc2xpZGVPdXRMZWZ0IHtcbiAgYW5pbWF0aW9uLW5hbWU6IHNsaWRlT3V0TGVmdDtcbn1cblxuQGtleWZyYW1lcyBzbGlkZU91dFJpZ2h0IHtcbiAgZnJvbSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcbiAgfVxuXG4gIHRvIHtcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcbiAgfVxufVxuXG4uc2xpZGVPdXRSaWdodCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzbGlkZU91dFJpZ2h0O1xufVxuXG5Aa2V5ZnJhbWVzIHNsaWRlT3V0VXAge1xuICBmcm9tIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICB9XG5cbiAgdG8ge1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMDAlLCAwKTtcbiAgfVxufVxuXG4uc2xpZGVPdXRVcCB7XG4gIGFuaW1hdGlvbi1uYW1lOiBzbGlkZU91dFVwO1xufVxuYm9keSB7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1mYW1pbHk6IFJvYm90bywtYXBwbGUtc3lzdGVtLEJsaW5rTWFjU3lzdGVtRm9udCxcIlNlZ29lIFVJXCIsUm9ib3RvLFwiSGVsdmV0aWNhIE5ldWVcIixBcmlhbCxzYW5zLXNlcmlmLFwiQXBwbGUgQ29sb3IgRW1vamlcIixcIlNlZ29lIFVJIEVtb2ppXCIsXCJTZWdvZSBVSSBTeW1ib2xcIixcIk5vdG8gQ29sb3IgRW1vamlcIjtcbiAgZm9udC1zaXplOiAuODEyNXJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgbGluZS1oZWlnaHQ6IDI7XG4gIGNvbG9yOiAjMzMzO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzgzYTQ4O1xufVxuXG4ubXQtNTB7XG5cbiAgbWFyZ2luLXRvcDogNTBweDtcbn1cblxuLm1iLTUwe1xuXG4gIG1hcmdpbi1ib3R0b206IDUwcHg7XG59XG5cblxuXG4uY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogLW1zLWZsZXhib3g7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC1tcy1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBtaW4td2lkdGg6IDA7XG4gIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jbGlwOiBib3JkZXItYm94O1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDAsMCwwLC4xMjUpO1xuICBib3JkZXItcmFkaXVzOiAuMTg3NXJlbTtcbn1cblxuLmNhcmQtaW1nLWFjdGlvbnMge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uY2FyZC1ib2R5IHtcbiAgLW1zLWZsZXg6IDEgMSBhdXRvO1xuICBmbGV4OiAxIDEgYXV0bztcbiAgcGFkZGluZzogMS4yNXJlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY2FyZC1pbWd7XG5cbiAgd2lkdGg6IDM1MHB4O1xufVxuXG4uc3RhcntcbiAgICAgIGNvbG9yOiByZWQ7XG59XG5cbi5iZy1jYXJ0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjpyZ2IoOTAsIDg5LCA4Nik7XG4gIGNvbG9yOiNmZmY7XG59XG5cbi5iZy1jYXJ0OmhvdmVyIHtcbiAgXG4gIGNvbG9yOiNmZmY7XG59XG5cbi5iZy1idXkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOmdyZWVuO1xuICBjb2xvcjojZmZmO1xuICBwYWRkaW5nLXJpZ2h0OiAyOXB4O1xufVxuLmJnLWJ1eTpob3ZlciB7XG4gIFxuICBjb2xvcjojZmZmO1xufVxuXG5he1xuXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4ubGFuZ3tcbiAgbWFyZ2luLWxlZnQ6ODBweDtcbn1cblxuXG4uZXhhbXBsZS1mb3JtIHtcbiAgbWluLXdpZHRoOiAyNTBweDtcbiAgbWF4LXdpZHRoOiA1MDBweDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5leGFtcGxlLWZ1bGwtd2lkdGgge1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLWxlZnQ6IDU1cHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbn1cblxuLmV4YW1wbGUtaW5wdXQge1xuICBtYXgtd2lkdGg6IDEwMCU7XG4gIHdpZHRoOiA0MDBweDtcbn1cblxuXG4uZXhhbXBsZS1mdWxsLXdpZHRoe1xuICBtYXJnaW46IGJsb2NrIGVuZCAxMHB4OyA7XG59XG5cbi5zaWduLWJ1dHRvbntcbiAgbWFyZ2luLXJpZ2h0OjIwcHg7XG4gIG1hcmdpbi1sZWZ0OiAtMzVweDtcbiAgXG59XG5cbi5zZWxsaWNvbntcbiAgbWFyZ2luLXJpZ2h0OjYwcHg7XG4gIHotaW5kZXg6IDE7XG59XG5cbi5zZWxsY3tcbiAgbGVmdDogLTQwcHg7XG4gIG1hcmdpbi1yaWdodDogLTIwcHg7XG4gIFxufVxuLnNlbGxjMXtcbiAgcmlnaHQ6IDY2cHg7XG5cbiAgXG59XG5tYXQtaWNvbntcbiAgbWFyZ2luOiAycHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5UaXRsZSB7XG4gIC8qIGZvbnQtZmFtaWx5OiAnUnViaWsgRGlzdHJlc3NlZCcsIGN1cnNpdmU7ICovXG4gIGZvbnQtc2l6ZTogMjIwJTtcbiAgLyogbWFyZ2luLXJpZ2h0OiAyMHB4OyAqL1xuICAvKiBtYXJnaW4tbGVmdDogMHB4OyAqL1xufVxuLm5hdmJhcntcbiAgYmFja2dyb3VuZDogIzM4M2E0ODtcbiAgLyogd2lkdGg6IDEwMCU7ICovXG4gIC8qIG1hcmdpbi1sZWZ0OiAwcHggKi9cbiAgY29sb3I6IHdoaXRlO1xufVxuLmNvbnRlbnR7XG4gIG1hcmdpbi10b3A6NXJlbTtcbn1cbi5sb2dve1xuICAgIHBhZGRpbmc6IDBweCA1cHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxuXG5cbi5mbGV4e1xuICAgIG1hcmdpbi1ib3R0b206IDFyZW07XG4gICAgLyogd2lkdGg6IDkwJTsgKi9cbn1cblxuXG5cbi5leGFtcGxlLWJ1dHRvbi1yb3d7XG4gIGFsaWduLWl0ZW1zOiBlbmQ7XG4gIHBhZGRpbmctbGVmdDo2MDBweDtcblxufVxuXG4ubWF0LXRvb2xiYXItcm93e1xuICBwYWRkaW5nOjBweCAwcHggO1xufVxuXG5cblxuIl19 */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LandingPageComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-landing-page',
            templateUrl: './landing-page.component.html',
            styleUrls: ['./landing-page.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "ofsS":
    /*!************************************************************************!*\
      !*** ./src/app/add-product/dialog-example/dialog-example.component.ts ***!
      \************************************************************************/

    /*! exports provided: DialogExampleComponent */

    /***/
    function ofsS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DialogExampleComponent", function () {
        return DialogExampleComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "iInd");

      var DialogExampleComponent = /*#__PURE__*/function () {
        function DialogExampleComponent() {
          _classCallCheck(this, DialogExampleComponent);
        }

        _createClass(DialogExampleComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return DialogExampleComponent;
      }();

      DialogExampleComponent.ɵfac = function DialogExampleComponent_Factory(t) {
        return new (t || DialogExampleComponent)();
      };

      DialogExampleComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: DialogExampleComponent,
        selectors: [["app-dialog-example"]],
        decls: 7,
        vars: 0,
        consts: [[1, "example-card", 2, "padding", "30px"], ["id", "img", "mat-card-image", "", "src", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmXRQ_IU1Ru1m0-FkOVJBVVORhtGW_YYoBazNyWb7o&s", "alt", "submitted"], ["mat-raised-button", "", "routerLink", "/showProduct", "color", "primary"]],
        template: function DialogExampleComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-card", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Submitted Sucessfully ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Show products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }
        },
        directives: [_angular_material_card__WEBPACK_IMPORTED_MODULE_1__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_1__["MatCardImage"], _angular_material_button__WEBPACK_IMPORTED_MODULE_2__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLink"]],
        styles: [".example-card[_ngcontent-%COMP%] {\n    padding: 10px;\n    text-align: center;\n    border-radius: 20px;\n    width:30vw;\n    margin:auto;\n    border:black 1px solid;\n  }\n#img[_ngcontent-%COMP%]{\n    height:100px;\n    width:auto;\n    padding: 20px;\n }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRpYWxvZy1leGFtcGxlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2Isa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQixVQUFVO0lBQ1YsV0FBVztJQUNYLHNCQUFzQjtFQUN4QjtBQUNGO0lBQ0ksWUFBWTtJQUNaLFVBQVU7SUFDVixhQUFhO0NBQ2hCIiwiZmlsZSI6ImRpYWxvZy1leGFtcGxlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXhhbXBsZS1jYXJkIHtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgIHdpZHRoOjMwdnc7XG4gICAgbWFyZ2luOmF1dG87XG4gICAgYm9yZGVyOmJsYWNrIDFweCBzb2xpZDtcbiAgfVxuI2ltZ3tcbiAgICBoZWlnaHQ6MTAwcHg7XG4gICAgd2lkdGg6YXV0bztcbiAgICBwYWRkaW5nOiAyMHB4O1xuIH0gIl19 */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DialogExampleComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-dialog-example',
            templateUrl: './dialog-example.component.html',
            styleUrls: ['./dialog-example.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./login/login.component */
      "vtpD");
      /* harmony import */


      var _add_product_add_product_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./add-product/add-product.component */
      "WGIg");
      /* harmony import */


      var _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./chat-service-app/chat-service-app.component */
      "/ZnB");
      /* harmony import */


      var _product_categories_product_categories_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./product-categories/product-categories.component */
      "g1F2");
      /* harmony import */


      var _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./product-details/product-details.component */
      "ylPK");
      /* harmony import */


      var _register_user_register_user_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./register-user/register-user.component */
      "MvdQ");
      /* harmony import */


      var _my_profile_my_profile_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./my-profile/my-profile.component */
      "kMBp");
      /* harmony import */


      var _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./landing-page/landing-page.component */
      "mSt+");
      /* harmony import */


      var _my_products_my_products_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./my-products/my-products.component */
      "FJfR");
      /* harmony import */


      var _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ./chat-bot/chat-bot.component */
      "wY5D");
      /* harmony import */


      var _video_service_video_service_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./video-service/video-service.component */
      "jo2m");

      var routes = [{
        path: "videoService",
        component: _video_service_video_service_component__WEBPACK_IMPORTED_MODULE_12__["VideoServiceComponent"]
      }, {
        path: '',
        component: _landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_9__["LandingPageComponent"]
      }, {
        path: 'showProduct',
        component: _product_categories_product_categories_component__WEBPACK_IMPORTED_MODULE_5__["ProductCategoriesComponent"]
      }, {
        path: 'register',
        component: _register_user_register_user_component__WEBPACK_IMPORTED_MODULE_7__["RegisterUserComponent"]
      }, {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"]
      }, {
        path: 'profile',
        component: _my_profile_my_profile_component__WEBPACK_IMPORTED_MODULE_8__["MyProfileComponent"]
      }, {
        path: 'detailss',
        component: _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_6__["ProductDetailsComponent"]
      }, {
        path: 'details',
        component: _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_6__["ProductDetailsComponent"]
      }, {
        path: 'chatbox',
        component: _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_4__["ChatServiceAppComponent"]
      }, {
        path: 'addProduct',
        component: _add_product_add_product_component__WEBPACK_IMPORTED_MODULE_3__["AddProductComponent"]
      }, {
        path: 'chat',
        component: _chat_service_app_chat_service_app_component__WEBPACK_IMPORTED_MODULE_4__["ChatServiceAppComponent"]
      }, {
        path: 'details',
        component: _product_details_product_details_component__WEBPACK_IMPORTED_MODULE_6__["ProductDetailsComponent"]
      }, {
        path: 'myProducts',
        component: _my_products_my_products_component__WEBPACK_IMPORTED_MODULE_10__["MyProductsComponent"]
      }, {
        path: 'chatbot',
        component: _chat_bot_chat_bot_component__WEBPACK_IMPORTED_MODULE_11__["ChatBotComponent"]
      }];

      var AppRoutingModule = /*#__PURE__*/_createClass(function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      });

      AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AppRoutingModule
      });
      AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AppRoutingModule_Factory(t) {
          return new (t || AppRoutingModule)();
        },
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, {
          useHash: true
        })], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, {
              useHash: true
            })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "vtpD":
    /*!******************************************!*\
      !*** ./src/app/login/login.component.ts ***!
      \******************************************/

    /*! exports provided: LoginComponent */

    /***/
    function vtpD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LoginComponent", function () {
        return LoginComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _model_login_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../model/login/user */
      "UBkm");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/grid-list */
      "40+f");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");

      function LoginComponent_mat_error_24_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-error");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.getErrorMessage());
        }
      }

      var LoginComponent = /*#__PURE__*/function () {
        function LoginComponent(formBuilder, loginService, router) {
          _classCallCheck(this, LoginComponent);

          this.formBuilder = formBuilder;
          this.loginService = loginService;
          this.router = router;
          this.search = "";
          this.submitted = false; // get f(): { [key: string]: AbstractControl } {
          //   return this.form.controls;
          // }

          this.loginObj = new _model_login_user__WEBPACK_IMPORTED_MODULE_2__["User"]();
          this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email]);
          this.RememberMe = false;
          this.hide = true;
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$")]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(15)])
          });
        }

        _createClass(LoginComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {// this.form = this.formBuilder.group(
            //   {
            //     email: ['', [Validators.required, Validators.email]],
            //     password: [
            //       '',
            //       [
            //         Validators.required,
            //         Validators.minLength(6),
            //         Validators.maxLength(40)
            //       ]
            //     ]
            //   }
            // );
          }
        }, {
          key: "onSubmit",
          value: function onSubmit() {
            var _this14 = this;

            // this.submitted = true;
            // if (this.form.invalid) {
            //   return;
            // }
            // console.log(JSON.stringify(this.form.value, null, 2));
            console.log("FORMDATA", this.form.value);
            this.loginObj.email = this.form.value.email;
            this.loginObj.password = this.form.value.password;
            this.loginService.loginApi(this.loginObj).subscribe(function (data) {
              console.log("validated", data);

              _this14.form.reset();

              localStorage.setItem("buyerEmail", _this14.loginObj.email);

              _this14.router.navigate(["/showProduct"]);
            }, function (error) {
              console.log(error);
              _this14.errorMessage = error.error;
            });
          }
        }, {
          key: "getErrorMessage",
          value: function getErrorMessage() {
            if (this.email.hasError("required")) {
              return "You must enter a value";
            }

            return this.email.hasError("email") ? "Not a valid email" : "";
          }
        }]);

        return LoginComponent;
      }();

      LoginComponent.ɵfac = function LoginComponent_Factory(t) {
        return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]));
      };

      LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: LoginComponent,
        selectors: [["app-login"]],
        decls: 38,
        vars: 7,
        consts: [["color", "primary", 1, "navbar-expand-lg", "navbar", "fixed-top"], ["src", "assets/obj1.png", "routerLink", "", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], ["routerLink", "", 1, "Title"], ["name", "viewport", "content", "width=device-width, initial-scale=1.0"], ["type", "button", "routerLink", "", 1, "btn", "btn-light"], [1, "col-lg-5", "col-md-5", "col-sm-5", "col-12"], ["src", "assets/Objects.png", "width", "50", "height", "50", "alt", "", 1, "d-inline-block"], ["cols", "2", "rowHeight", "90vh"], ["mat-card-image", "", "src", "assets/handshake.webp", "alt", "img", "width", "90%", "height", "80%", 1, "handshake-image"], [2, "background-color", "rgba(239, 244, 244, 0.66)"], [1, "container", "col-md-6", 2, "background-color", "rgb(252, 250, 250)"], ["fxLayoutAlign", "center center", "fxLayout.xs", "column", 1, "main-div"], ["fxFlex", "100"], ["color", "primary"], [1, "signup"], ["fxLayoutAlign", "stretch", "fxLayout", "column", 1, "login-form", 3, "formGroup"], ["appearance", "fill"], ["matInput", "", "type", "email", "formControlName", "email", "placeholder", "pat@example.com", 1, "form-control"], [4, "ngIf"], [1, "pass"], ["matInput", "", "formControlName", "password", 1, "form-control", 3, "type"], ["mat-icon-button", "", "matSuffix", "", 3, "click"], ["mat-raised-button", "", "color", "primary", "type", "submit", "name", "submit_reg", 3, "disabled", "click"], [1, "signin"], ["routerLink", "/register"]],
        template: function LoginComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-toolbar", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "head");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "meta", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-grid-list", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-grid-tile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "img", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "mat-grid-tile", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-card", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-toolbar", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-label", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Sign In ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "form", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-form-field", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-label");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Email");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "input", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, LoginComponent_mat_error_24_Template, 2, 1, "mat-error", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "mat-form-field", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "mat-label", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Password");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "input", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_29_listener() {
              return ctx.hide = !ctx.hide;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "button", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_32_listener() {
              return ctx.onSubmit();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Sign In");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "p", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Do not have an account? ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "a", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Sign Up");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.email.invalid);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("type", ctx.hide ? "password" : "text");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-label", "Hide password")("aria-pressed", ctx.hide);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.hide ? "visibility_off" : "visibility");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.form.valid);
          }
        },
        directives: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbar"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLink"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__["MatGridList"], _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_6__["MatGridTile"], _angular_material_card__WEBPACK_IMPORTED_MODULE_7__["MatCardImage"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutAlignDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultLayoutDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_7__["MatCard"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_8__["DefaultFlexDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatLabel"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormField"], _angular_material_input__WEBPACK_IMPORTED_MODULE_10__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["NgIf"], _angular_material_button__WEBPACK_IMPORTED_MODULE_12__["MatButton"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatSuffix"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_13__["MatIcon"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterLinkWithHref"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatError"]],
        styles: [".fcontainer[_ngcontent-%COMP%]{\n\n  height: 100vh;\n  display: flex;\n  \n  \n  \n  \n  \n  flex-wrap: wrap; \n  \n  flex-flow: column wrap; \n  \n  \n}\n.lang[_ngcontent-%COMP%]{\n  margin-left:80px;\n}\n.spacer[_ngcontent-%COMP%]{\n  flex: 1 1 auto;\n}\n.mat-toolbar-single-row[_ngcontent-%COMP%] {\n  height: 76px;\n  padding: 0;\n}\n.mat-toolbar.mat-primary[_ngcontent-%COMP%]{\n  background-color: #383a48;\n}\n.mat-form-field-appearance-legacy[_ngcontent-%COMP%]   .mat-form-field-wrapper[_ngcontent-%COMP%] {\n  padding-bottom: 1.2em;\n}\n.categ[_ngcontent-%COMP%]{\n  margin-left: 10px;\n}\n.mat-form-field[_ngcontent-%COMP%] {\n  font-size: medium;\n\n}\n.navbar[_ngcontent-%COMP%] {\n\n  display: flex;\n  position: fixed;\n  \n\n}\n.sell-button[_ngcontent-%COMP%]{\n  margin-right: 10px;\n  padding:0px 20px 0px 20px;\n}\n.reg-button[_ngcontent-%COMP%]{\n  margin-left:9px;\n}\n.fitem[_ngcontent-%COMP%]{\n  \n\n  \n  width: 50%;\n  height: 100%;\n}\n.item1[_ngcontent-%COMP%]{\n  flex:1 ;\n  \n   flex-shrink: 2; \n\n}\n.item2[_ngcontent-%COMP%]{\n  width: 40%;\n  height: 100%;\n  \n  \n}\n\n.example-card[_ngcontent-%COMP%] {\n  max-width: 400 px;\n  width: 100%;\n}\n.example-form[_ngcontent-%COMP%] {\n  min-width: 150px;\n  max-width: 500px;\n  width: 100%;\n}\n.example-full-width[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.main-div[_ngcontent-%COMP%]   mat-card[_ngcontent-%COMP%]{\npadding: 0px;\n\n}\n.login-form[_ngcontent-%COMP%]{\n  padding: 20px;\n}\n.signin[_ngcontent-%COMP%]{\n  padding: 12px;\n}\n.handshake-image[_ngcontent-%COMP%]{\n  width:100%;\n  height: auto;\n}\n.pass[_ngcontent-%COMP%]{\n  margin-left:0px;\n}\n.example-margin[_ngcontent-%COMP%] {\n  margin: 0 12px;\n  padding-bottom: 10px;\n}\n.Title[_ngcontent-%COMP%] {\n  \n  font-size: 150%;\n  margin-left: 10px;\n}\n.navbar-brand[_ngcontent-%COMP%] {\n  cursor: pointer;\n  margin-left: 10px;\n  margin-right: 0px;\n}\n.example-form[_ngcontent-%COMP%] {\n  min-width: 250px;\n  max-width: 500px;\n  width: 100%;\n}\n.example-full-width[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-left: 55px;\n  margin-bottom: 5px;\n}\n.example-input[_ngcontent-%COMP%] {\n  max-width: 100%;\n  width: 400px;\n}\n.example-full-width[_ngcontent-%COMP%]{\n  margin: block end 10px; ;\n}\n.signup[_ngcontent-%COMP%]{\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0VBRUUsYUFBYTtFQUNiLGFBQWE7RUFDYixvQ0FBb0M7RUFDcEMsK0JBQStCO0VBQy9CLGlDQUFpQztFQUNqQyw2QkFBNkI7RUFDN0I7OzRCQUUwQjtFQUMxQixlQUFlO0VBQ2YsNkJBQTZCO0VBQzdCLHNCQUFzQjs7O0FBR3hCO0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7QUFFQTtFQUNFLGNBQWM7QUFDaEI7QUFHQTtFQUNFLFlBQVk7RUFDWixVQUFVO0FBQ1o7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UscUJBQXFCO0FBQ3ZCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFFQTtFQUNFLGlCQUFpQjs7QUFFbkI7QUFDQTs7RUFFRSxhQUFhO0VBQ2IsZUFBZTs7O0FBR2pCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSxlQUFlO0FBQ2pCO0FBRUE7Ozs7RUFJRSxVQUFVO0VBQ1YsWUFBWTtBQUNkO0FBRUE7RUFDRSxPQUFPO0VBQ1Asa0JBQWtCO0dBQ2pCLGNBQWM7O0FBRWpCO0FBRUE7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGtCQUFrQjs7QUFFcEI7QUFFQTs7O0dBR0c7QUFFSDtFQUNFLGlCQUFpQjtFQUNqQixXQUFXO0FBQ2I7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsV0FBVztBQUNiO0FBRUE7RUFDRSxXQUFXO0FBQ2I7QUFFQTtBQUNBLFlBQVk7O0FBRVo7QUFFQTtFQUNFLGFBQWE7QUFDZjtBQUVBO0VBQ0UsYUFBYTtBQUNmO0FBRUE7RUFDRSxVQUFVO0VBQ1YsWUFBWTtBQUNkO0FBRUE7RUFDRSxlQUFlO0FBQ2pCO0FBRUE7RUFDRSxjQUFjO0VBQ2Qsb0JBQW9CO0FBQ3RCO0FBRUE7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLGlCQUFpQjtBQUNuQjtBQUVBO0VBQ0UsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixpQkFBaUI7QUFDbkI7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsV0FBVztBQUNiO0FBRUE7RUFDRSxXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjtBQUVBO0VBQ0UsZUFBZTtFQUNmLFlBQVk7QUFDZDtBQUdBO0VBQ0Usc0JBQXNCO0FBQ3hCO0FBRUE7RUFDRSxpQkFBaUI7QUFDbkIiLCJmaWxlIjoibG9naW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mY29udGFpbmVye1xuXG4gIGhlaWdodDogMTAwdmg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC8qIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4tcmV2ZXJzZTsgKi9cbiAgLyoganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDsgKi9cbiAgLyoganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0OyAqL1xuICAvKiBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgKi9cbiAgLyogYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDsgKi9cbiAgZmxleC13cmFwOiB3cmFwOyBcbiAgLyogZmxleC13cmFwOiB3cmFwLXJldmVyc2U7ICovXG4gIGZsZXgtZmxvdzogY29sdW1uIHdyYXA7IFxuICBcbiAgXG59XG4ubGFuZ3tcbiAgbWFyZ2luLWxlZnQ6ODBweDtcbn1cblxuLnNwYWNlcntcbiAgZmxleDogMSAxIGF1dG87XG59XG5cblxuLm1hdC10b29sYmFyLXNpbmdsZS1yb3cge1xuICBoZWlnaHQ6IDc2cHg7XG4gIHBhZGRpbmc6IDA7XG59XG4ubWF0LXRvb2xiYXIubWF0LXByaW1hcnl7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzODNhNDg7XG59XG4ubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1sZWdhY3kgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMS4yZW07XG59XG4uY2F0ZWd7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubWF0LWZvcm0tZmllbGQge1xuICBmb250LXNpemU6IG1lZGl1bTtcblxufVxuLm5hdmJhciB7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBcblxufVxuLnNlbGwtYnV0dG9ue1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIHBhZGRpbmc6MHB4IDIwcHggMHB4IDIwcHg7XG59XG4ucmVnLWJ1dHRvbntcbiAgbWFyZ2luLWxlZnQ6OXB4O1xufVxuXG4uZml0ZW17XG4gIFxuXG4gIFxuICB3aWR0aDogNTAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5pdGVtMXtcbiAgZmxleDoxIDtcbiAgLyogZmxleC1ncm93OiAzOyAqL1xuICAgZmxleC1zaHJpbms6IDI7IFxuXG59XG5cbi5pdGVtMntcbiAgd2lkdGg6IDQwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICAvKiBmbGV4LWdyb3c6IDI7ICovXG4gIFxufVxuXG4vKiAuVGl0bGUge1xuICBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlO1xuICBmb250LXNpemU6IDE4MCU7XG59ICovXG5cbi5leGFtcGxlLWNhcmQge1xuICBtYXgtd2lkdGg6IDQwMCBweDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5leGFtcGxlLWZvcm0ge1xuICBtaW4td2lkdGg6IDE1MHB4O1xuICBtYXgtd2lkdGg6IDUwMHB4O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmV4YW1wbGUtZnVsbC13aWR0aCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ubWFpbi1kaXYgbWF0LWNhcmR7XG5wYWRkaW5nOiAwcHg7XG5cbn1cblxuLmxvZ2luLWZvcm17XG4gIHBhZGRpbmc6IDIwcHg7XG59XG5cbi5zaWduaW57XG4gIHBhZGRpbmc6IDEycHg7XG59XG5cbi5oYW5kc2hha2UtaW1hZ2V7XG4gIHdpZHRoOjEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLnBhc3N7XG4gIG1hcmdpbi1sZWZ0OjBweDtcbn1cblxuLmV4YW1wbGUtbWFyZ2luIHtcbiAgbWFyZ2luOiAwIDEycHg7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4uVGl0bGUge1xuICAvKiBmb250LWZhbWlseTogJ1J1YmlrIERpc3RyZXNzZWQnLCBjdXJzaXZlOyAqL1xuICBmb250LXNpemU6IDE1MCU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubmF2YmFyLWJyYW5kIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG5cbi5leGFtcGxlLWZvcm0ge1xuICBtaW4td2lkdGg6IDI1MHB4O1xuICBtYXgtd2lkdGg6IDUwMHB4O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmV4YW1wbGUtZnVsbC13aWR0aCB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tbGVmdDogNTVweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuXG4uZXhhbXBsZS1pbnB1dCB7XG4gIG1heC13aWR0aDogMTAwJTtcbiAgd2lkdGg6IDQwMHB4O1xufVxuXG5cbi5leGFtcGxlLWZ1bGwtd2lkdGh7XG4gIG1hcmdpbjogYmxvY2sgZW5kIDEwcHg7IDtcbn1cblxuLnNpZ251cHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG4iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-login",
            templateUrl: "./login.component.html",
            styleUrls: ["./login.component.css"]
          }]
        }], function () {
          return [{
            type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]
          }, {
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "wY5D":
    /*!************************************************!*\
      !*** ./src/app/chat-bot/chat-bot.component.ts ***!
      \************************************************/

    /*! exports provided: ChatBotComponent */

    /***/
    function wY5D(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatBotComponent", function () {
        return ChatBotComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");

      function ChatBotComponent_iframe_3_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "iframe", 3);
        }
      }

      var ChatBotComponent = /*#__PURE__*/function () {
        function ChatBotComponent() {
          _classCallCheck(this, ChatBotComponent);

          this.showChat = true;
        }

        _createClass(ChatBotComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "showChatOption",
          value: function showChatOption() {
            this.showChat = !this.showChat;
          }
        }]);

        return ChatBotComponent;
      }();

      ChatBotComponent.ɵfac = function ChatBotComponent_Factory(t) {
        return new (t || ChatBotComponent)();
      };

      ChatBotComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: ChatBotComponent,
        selectors: [["app-chat-bot"]],
        decls: 4,
        vars: 1,
        consts: [[1, "button", 3, "click"], ["color", "primary"], ["class", "bot", "width", "350", "height", "430", "allow", "microphone;", "src", "https://console.dialogflow.com/api-client/demo/embedded/bf3026b2-968e-4fd8-9efa-2db3881bf5c8", 4, "ngIf"], ["width", "350", "height", "430", "allow", "microphone;", "src", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtrustConstantResourceUrl"]("https://console.dialogflow.com/api-client/demo/embedded/bf3026b2-968e-4fd8-9efa-2db3881bf5c8"), 1, "bot"]],
        template: function ChatBotComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ChatBotComponent_Template_button_click_0_listener() {
              return ctx.showChatOption();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-icon", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " people");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ChatBotComponent_iframe_3_Template, 1, 0, "iframe", 2);
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showChat == false);
          }
        },
        directives: [_angular_material_icon__WEBPACK_IMPORTED_MODULE_1__["MatIcon"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"]],
        styles: [".button[_ngcontent-%COMP%]{\r\n    display: inline-block;\r\n    vertical-align: bottom;\r\n    position: fixed;\r\n    bottom:0;\r\n    right:0;\r\n    margin: 40px;\r\n    border: black 1px solid;\r\n    border-radius: 10px;\r\n    \r\n}\r\n.bot[_ngcontent-%COMP%]{\r\n    display: inline-block;\r\n    vertical-align: bottom;\r\n    position: fixed;\r\n    bottom:0;\r\n    right:0;\r\n    margin: 50px;\r\n    border: black 1px solid;\r\n    border-radius: 10px;\r\n    z-index: 1;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQtYm90LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxxQkFBcUI7SUFDckIsc0JBQXNCO0lBQ3RCLGVBQWU7SUFDZixRQUFRO0lBQ1IsT0FBTztJQUNQLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsbUJBQW1COztBQUV2QjtBQUNBO0lBQ0kscUJBQXFCO0lBQ3JCLHNCQUFzQjtJQUN0QixlQUFlO0lBQ2YsUUFBUTtJQUNSLE9BQU87SUFDUCxZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixVQUFVO0FBQ2QiLCJmaWxlIjoiY2hhdC1ib3QuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5idXR0b257XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYm90dG9tOjA7XHJcbiAgICByaWdodDowO1xyXG4gICAgbWFyZ2luOiA0MHB4O1xyXG4gICAgYm9yZGVyOiBibGFjayAxcHggc29saWQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgXHJcbn1cclxuLmJvdHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBib3R0b206MDtcclxuICAgIHJpZ2h0OjA7XHJcbiAgICBtYXJnaW46IDUwcHg7XHJcbiAgICBib3JkZXI6IGJsYWNrIDFweCBzb2xpZDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB6LWluZGV4OiAxO1xyXG59XHJcbiJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ChatBotComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-chat-bot',
            templateUrl: './chat-bot.component.html',
            styleUrls: ['./chat-bot.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "ylPK":
    /*!**************************************************************!*\
      !*** ./src/app/product-details/product-details.component.ts ***!
      \**************************************************************/

    /*! exports provided: ProductDetailsComponent */

    /***/
    function ylPK(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductDetailsComponent", function () {
        return ProductDetailsComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _service_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../service/app.service */
      "3mgE");
      /* harmony import */


      var _service_recommendation_recommendation_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../service/recommendation/recommendation-service.service */
      "l2D2");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /* harmony import */


      var _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/flex-layout/flex */
      "VDRc");
      /* harmony import */


      var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/toolbar */
      "l0rg");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/menu */
      "rJgo");
      /* harmony import */


      var _angular_material_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/card */
      "PDjf");
      /* harmony import */


      var _angular_material_divider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/divider */
      "BSbQ");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/paginator */
      "5QHs");

      function ProductDetailsComponent_div_118_Template(rf, ctx) {
        if (rf & 1) {
          var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 45);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-card", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ProductDetailsComponent_div_118_Template_mat_card_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);

            var productdata_r2 = ctx.$implicit;

            var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r3.saveData(productdata_r2);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 47);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 48);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 49);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-card-content", 50);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 51);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "strong", 53);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "mat-divider", 54);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 55);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 56);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, " location_on");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 56);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-icon");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "date_range");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 57);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "strong");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](26, "date");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var productdata_r2 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("matToolTip", productdata_r2.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", productdata_r2.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" \u20B9", productdata_r2.productPrice, "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r2.productName);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](productdata_r2.sellerState);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](26, 6, productdata_r2.productdate));
        }
      }

      var _c0 = function _c0() {
        return [4];
      };

      var ProductDetailsComponent = /*#__PURE__*/function () {
        function ProductDetailsComponent(productdetailsService, recommendationService, dom) {
          _classCallCheck(this, ProductDetailsComponent);

          this.productdetailsService = productdetailsService;
          this.recommendationService = recommendationService;
          this.dom = dom;
          this.allProducts = [];
          this.lowValue = 0;
          this.highValue = 4;
        }

        _createClass(ProductDetailsComponent, [{
          key: "getProductDetails",
          value: function getProductDetails() {
            var _this15 = this;

            this.productdetailsService.getDetail().subscribe(function (response) {
              console.log(response);
              _this15.product = response;
              console.log("product", _this15.product);
              _this15.product.image = _this15.dom.bypassSecurityTrustResourceUrl("data:image/jepg;base64," + _this15.product.image);
            });
          }
        }, {
          key: "getAllProductDetails",
          value: function getAllProductDetails() {
            var _this16 = this;

            this.productdetailsService.getByProductCategory().subscribe(function (response) {
              console.log(response);
              var size = response.length;

              for (var i = 0; i < size; i++) {
                _this16.allProducts.push(response[i]);

                _this16.allProducts[i].image = 'data:image/jpeg;base64,' + _this16.allProducts[i].image;
              } // response.forEach((element: any) => {
              //   this.allProducts.push(element);
              //   for (var i = 0; i < this.allProducts.length; i++) {
              //     this.allProducts[i].image =
              //       'data:image/jpeg;base64,' + this.allProducts[i].image;
              //   }
              // });
              // this.allProducts=response;
              // console.log(this.allProducts);
              // this.allProducts.image=this.dom.bypassSecurityTrustResourceUrl('data:image/jepg;base64,'+this.allProducts.image);

            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.getProductDetails();
            this.getAllProductDetails();
          } // used to build a slice of papers relevant at any given time

        }, {
          key: "getPaginatorData",
          value: function getPaginatorData(event) {
            this.lowValue = event.pageIndex * event.pageSize;
            this.highValue = this.lowValue + event.pageSize;
            return event;
          }
        }, {
          key: "saveData",
          value: function saveData(data) {
            localStorage.setItem("sellerEmail", data.sellerEmail);
            localStorage.setItem("productId", data.productId);
            localStorage.setItem("category", data.category);
          }
        }, {
          key: "contactSeller",
          value: function contactSeller() {
            localStorage.setItem("PRODUCT_ID_FOR_BUYER_UI", this.product.productId);
            localStorage.setItem("SELLER_EMAIL_FOR_BUYER_CHAT_UI", this.product.sellerEmail);
            localStorage.setItem("ROLE", "Buyer");
          }
        }]);

        return ProductDetailsComponent;
      }();

      ProductDetailsComponent.ɵfac = function ProductDetailsComponent_Factory(t) {
        return new (t || ProductDetailsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_service_recommendation_recommendation_service_service__WEBPACK_IMPORTED_MODULE_2__["RecommendationServiceService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"]));
      };

      ProductDetailsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: ProductDetailsComponent,
        selectors: [["app-product-details"]],
        decls: 122,
        vars: 27,
        consts: [["fxLayout", "row wrap", "fxLayout.xs", "column", "fxLayoutAlign", "center center", 1, "content"], [1, "navbar", "navbar", "fixed-top"], ["fxLayoutAlign", "space-between center"], ["mat-button", "", 3, "routerLink"], ["src", "assets/obj1.png", "routerLink", "/", "width", "50", "height", "50", "alt", "logo", 1, "d-inline-block", "navbar-brand"], ["routerLink", "", 1, "Title"], ["mat-fab", "", "routerLink", "/addProduct", "color", "primary", "aria-label", "Example icon button with a delete icon", 1, "sellicon"], ["mat-raised-button", "", "routerLink", "/addProduct", "color", "primary", 1, "sellc"], ["mat-button", "", 3, "matMenuTriggerFor"], [1, "icon"], [1, "menu"], ["menu", "matMenu"], ["mat-menu-item", "", "routerLink", "/profile"], ["mat-menu-item", "", "routerLink", "/showProduct"], ["mat-menu-item", "", "routerLink", "/myProducts"], ["mat-menu-item", "", "routerLink", "/chat"], ["mat-menu-item", "", "routerLink", "/login"], [1, "container", "img-details"], ["fxLayout", "row wrap", "fxLayout.xs", "column", "fxLayoutAlign", "space-around enter", "fxLayoutGap", "10px grid"], ["fxFlex", "50%", "fxLayoutAlign", "center center", 1, "flex"], [1, "image"], ["alt", "Image", 1, "w-100", 3, "src"], [1, "cardi"], [1, "nap"], [1, "name"], [1, "tab"], ["fxLayout", "row", "fxLayout.xs", "column", "fxLayoutAlign", "center center", "fxLayoutGap", "10px", 1, "content"], ["fxFlex", "", 1, "flex"], ["fxLayout", "row", "fxLayoutAlign", "space-between center"], [1, "profile"], [1, "account_circle"], [1, "seller"], [1, "sellerEmail"], ["fxLayout", "row", "fxflex", "30%", "fxLayoutAlign", "center center"], ["fxflex", "30%"], [1, "address"], ["fxLayoutAlign", "end end"], ["mat-raised-button", "", 1, "contact-seller-button", 3, "routerLink", "click"], [1, "pDescription"], ["fxLayout", "row", "fxLayoutAlign", "space-between center", 1, "similar"], [1, "Divider"], ["fxLayout", "row wrap", "fxLayoutGap", "20px grid", "fxLayoutAlign", "start center", 1, "con"], ["fxFlex", "25%", "fxFlex.xs", "100%", "fxFlex.sm", "50%", 4, "ngFor", "ngForOf"], [1, "paginator"], ["showFirstLastButtons", "false", 2, "padding-bottom", "20px", "background-color", "inherit", 3, "length", "pageSizeOptions", "page"], ["fxFlex", "25%", "fxFlex.xs", "100%", "fxFlex.sm", "50%"], ["routerLink", "/detailss", 1, "example-card", 3, "matToolTip", "click"], ["fxLayout", "row", "fxLayoutGap", "10px;"], ["fxFlex", "90%", "fxLayoutAlign", "center center"], ["mat-card-image", "", "alt", "Pic of Mobile", 1, "img", 3, "src"], [1, "text"], ["id", "title", "fxLayout", "column", "fxLayoutAlign", "center start"], [2, "font-size", "25px"], [2, "color", "#9E9E9E"], [1, "divider"], ["fxLayout", "row", "fxLayoutAlign", "space-between", 1, "locationAndDate"], ["fxLayout", "row", "fxLayoutAlign", "center center"], [2, "padding-left", "5px"]],
        template: function ProductDetailsComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-toolbar", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-toolbar-row", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "SwapOn ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-icon");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "add");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "a", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "SELL");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-icon", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-menu", 10, 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "button", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "My Profile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "All Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "button", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "My Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "My Chats");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "button", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Log Out");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "img", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "mat-card", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "h1", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "table", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "Brand ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "Price ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, "Purchase Date ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](62, "date");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "Product Condition ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](72, "Additional Details ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "mat-card");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "div", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "mat-icon", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "account_circle");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](87);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](88, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](91);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "mat-icon", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](94, "location_on");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "b", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](96);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "div", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "button", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ProductDetailsComponent_Template_button_click_98_listener() {
              return ctx.contactSeller();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, "Contact Seller");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "mat-card");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "mat-card-header");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "mat-card-title-group");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "mat-card-title");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "h1");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](109, " Description ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "mat-card-content", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](111);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "div", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "h2");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "b");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](115, "Similar Products");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](116, "mat-divider", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "div", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](118, ProductDetailsComponent_div_118_Template, 27, 8, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](119, "slice");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "mat-paginator", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("page", function ProductDetailsComponent_Template_mat_paginator_page_121_listener($event) {
              return ctx.getPaginatorData($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", "/");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matMenuTriggerFor", _r0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.product.image, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", ctx.product.productName, " (", ctx.product.brand, ")");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("\u20B9", ctx.product.productPrice, "");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.product.brand);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("\u20B9", ctx.product.productPrice, "");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](62, 20, ctx.product.purchaseDate));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.product.productCondition);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.product.additionalDetails);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.product.sellerName);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.product.sellerEmail);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", ctx.product.sellerState, ",", ctx.product.pincode, "");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", "/chat");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.product.productDescription, " ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind3"](119, 22, ctx.allProducts, ctx.lowValue, ctx.highValue));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("length", ctx.allProducts.length)("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](26, _c0));
          }
        },
        directives: [_angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_4__["DefaultLayoutDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_4__["DefaultLayoutAlignDirective"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbar"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_5__["MatToolbarRow"], _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterLink"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_8__["MatIcon"], _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatAnchor"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterLinkWithHref"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuTrigger"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenu"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuItem"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_4__["DefaultLayoutGapDirective"], _angular_flex_layout_flex__WEBPACK_IMPORTED_MODULE_4__["DefaultFlexDirective"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCard"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardHeader"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardTitleGroup"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardTitle"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardContent"], _angular_material_divider__WEBPACK_IMPORTED_MODULE_11__["MatDivider"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgForOf"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_13__["MatPaginator"], _angular_material_card__WEBPACK_IMPORTED_MODULE_10__["MatCardImage"]],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["SlicePipe"]],
        styles: [".Title[_ngcontent-%COMP%] {\r\n  \r\n  font-size: 220%;\r\n  \r\n  \r\n}\r\n.img-details[_ngcontent-%COMP%]{\r\n  margin-top: 5rem;\r\n}\r\n.content[_ngcontent-%COMP%]{\r\n  margin-top: 10px;\r\n}\r\n.pDescription[_ngcontent-%COMP%]{\r\n  margin-left: 2rem;\r\n}\r\n.logo[_ngcontent-%COMP%]{\r\n    padding: 0px 5px;\r\n    font-size: 20px;\r\n}\r\n.navbar[_ngcontent-%COMP%]{\r\n    background: #383a48;\r\n    \r\n    \r\n    color: white;\r\n}\r\n.flex[_ngcontent-%COMP%]{\r\n    margin-bottom: 10px;\r\n    \r\n}\r\n\r\n.image[_ngcontent-%COMP%]{\r\n    margin-top: 1rem;\r\n    margin-left: 1rem;\r\n    align-items: center;\r\n    -o-object-fit: cover;\r\n       object-fit: cover;\r\n    width: 80%;\r\n    height: 100%;\r\n    \r\n}\r\n.cardi[_ngcontent-%COMP%]{\r\n    margin-top: 10px;\r\n    align-items: center;\r\n    -o-object-fit: cover;\r\n       object-fit: cover;\r\n    width: 100%;\r\n    height: 100%;\r\n}\r\nmat-card[_ngcontent-%COMP%]{\r\n    align-items: center;\r\n    background: rgb(248, 242, 242);\r\n\r\n}\r\n.similar-card[_ngcontent-%COMP%]{\r\n    margin-left: 1rem;\r\n}\r\n.seller[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{\r\n  margin-left: 25px;\r\n  font-size: 18px;\r\n  \r\n}\r\n.sellerEmail[_ngcontent-%COMP%]{\r\n    opacity: 0.7;\r\n    \r\n}\r\n.address[_ngcontent-%COMP%]{\r\n  font-size: 18px;\r\n}\r\n.account_circle[_ngcontent-%COMP%]{\r\n    font-size:xx-large;\r\n     \r\n}\r\n.contact-seller-button[_ngcontent-%COMP%]{\r\n    \r\n    color: rgb(193, 232, 85);\r\n    font-size: 20px;\r\n    height: 40px;\r\n    background-color: #ed5537;\r\n}\r\n.button2[_ngcontent-%COMP%]{\r\n  background: #383a48;\r\n  color: white;\r\n  font-size: 20px;\r\n}\r\n\r\n.sellicon[_ngcontent-%COMP%]{\r\n  margin-right:1px;\r\n  z-index: 1;\r\n}\r\n.example-card[_ngcontent-%COMP%] {\r\n    border: black 2px solid;\r\n    border-radius: 10px;\r\n    }\r\n.img[_ngcontent-%COMP%]{\r\n        width: auto;\r\n        height:150px;\r\n        size: auto;\r\n        margin: auto;\r\n        text-align: center;\r\n        padding: 10px;\r\n        margin-bottom: 10px;\r\n      }\r\n.locationAndDate[_ngcontent-%COMP%]{\r\n        padding-top: 35px;\r\n        font-size: 15px;\r\n      }\r\n#title[_ngcontent-%COMP%]{\r\n        height:20px;\r\n        justify-content: center;\r\n      }\r\n.divider[_ngcontent-%COMP%]{\r\n        margin-top: 25px;\r\n      }\r\n.locDate[_ngcontent-%COMP%]{\r\n        padding-right: 15px;\r\n      }\r\n.text[_ngcontent-%COMP%]{\r\n        padding-top:30px;\r\n      }\r\n\r\n.icon[_ngcontent-%COMP%]{\r\n        height:20px;\r\n        display:inline-block;\r\n        font-size: 43px;\r\n        margin-bottom: 20px;\r\n      }\r\n.paginator[_ngcontent-%COMP%]{\r\n        opacity: 1;\r\n      }\r\n.profile[_ngcontent-%COMP%]{\r\n        margin-left: 25px;\r\n      }\r\n.tab[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{\r\n        padding:10px;\r\n        \r\n        \r\n        font-size: 150%;\r\n    }\r\n.name[_ngcontent-%COMP%]{\r\n      font-size: 30px;\r\n      margin-left: 15px;\r\n      padding-bottom: 10px;\r\n    }\r\n.nap[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n      margin-left: 15px;\r\n      font-size: 30px;\r\n    }\r\n.Divider[_ngcontent-%COMP%]{\r\n      margin-bottom: 10px;\r\n      \r\n    }\r\n.similar[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n      margin-left: 45px;\r\n    }\r\n.sellc[_ngcontent-%COMP%]{\r\n      right: 6px;\r\n      \r\n    }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtZGV0YWlscy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztHQUVHO0FBQ0g7RUFDRSw4Q0FBOEM7RUFDOUMsZUFBZTtFQUNmLHdCQUF3QjtFQUN4QixzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFDQTtJQUNJLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxtQkFBbUI7SUFDbkIsaUJBQWlCO0lBQ2pCLHFCQUFxQjtJQUNyQixZQUFZO0FBQ2hCO0FBRUE7SUFDSSxtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCO0FBQ0E7O0dBRUc7QUFDSDtJQUNJLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsbUJBQW1CO0lBQ25CLG9CQUFpQjtPQUFqQixpQkFBaUI7SUFDakIsVUFBVTtJQUNWLFlBQVk7SUFDWixzQkFBc0I7QUFDMUI7QUFDQTtJQUNJLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsb0JBQWlCO09BQWpCLGlCQUFpQjtJQUNqQixXQUFXO0lBQ1gsWUFBWTtBQUNoQjtBQUNBO0lBQ0ksbUJBQW1CO0lBQ25CLDhCQUE4Qjs7QUFFbEM7QUFHQTtJQUNJLGlCQUFpQjtBQUNyQjtBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZiwwQkFBMEI7QUFDNUI7QUFFQTtJQUNJLFlBQVk7SUFDWix3QkFBd0I7QUFDNUI7QUFDQTtFQUNFLGVBQWU7QUFDakI7QUFFQTtJQUNJLGtCQUFrQjtLQUNqQjttQkFDYztBQUNuQjtBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLHdCQUF3QjtJQUN4QixlQUFlO0lBQ2YsWUFBWTtJQUNaLHlCQUF5QjtBQUM3QjtBQUNBO0VBQ0UsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixlQUFlO0FBQ2pCO0FBQ0E7O0dBRUc7QUFFSDtFQUNFLGdCQUFnQjtFQUNoQixVQUFVO0FBQ1o7QUFFQTtJQUNJLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkI7QUFFQTtRQUNJLFdBQVc7UUFDWCxZQUFZO1FBQ1osVUFBVTtRQUNWLFlBQVk7UUFDWixrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLG1CQUFtQjtNQUNyQjtBQUVBO1FBQ0UsaUJBQWlCO1FBQ2pCLGVBQWU7TUFDakI7QUFFQTtRQUNFLFdBQVc7UUFDWCx1QkFBdUI7TUFDekI7QUFDQTtRQUNFLGdCQUFnQjtNQUNsQjtBQUNBO1FBQ0UsbUJBQW1CO01BQ3JCO0FBQ0E7UUFDRSxnQkFBZ0I7TUFDbEI7QUFDQTs7OztTQUlHO0FBRUg7UUFDRSxXQUFXO1FBQ1gsb0JBQW9CO1FBQ3BCLGVBQWU7UUFDZixtQkFBbUI7TUFDckI7QUFFQTtRQUNFLFVBQVU7TUFDWjtBQUNBO1FBQ0UsaUJBQWlCO01BQ25CO0FBQ0E7UUFDRSxZQUFZO1FBQ1osaUNBQWlDO1FBQ2pDLCtCQUErQjtRQUMvQixlQUFlO0lBQ25CO0FBQ0E7TUFDRSxlQUFlO01BQ2YsaUJBQWlCO01BQ2pCLG9CQUFvQjtJQUN0QjtBQUNBO01BQ0UsaUJBQWlCO01BQ2pCLGVBQWU7SUFDakI7QUFDQTtNQUNFLG1CQUFtQjtNQUNuQixxQkFBcUI7SUFDdkI7QUFFQTtNQUNFLGlCQUFpQjtJQUNuQjtBQUNBO01BQ0UsVUFBVTs7SUFFWjtBQUlKOzs7R0FHRyIsImZpbGUiOiJwcm9kdWN0LWRldGFpbHMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIC5jb250YWluZXJ7XHJcbiAgICBwYWRkaW5nLXRvcDogMnJlbTtcclxufSAqL1xyXG4uVGl0bGUge1xyXG4gIC8qIGZvbnQtZmFtaWx5OiAnUnViaWsgRGlzdHJlc3NlZCcsIGN1cnNpdmU7ICovXHJcbiAgZm9udC1zaXplOiAyMjAlO1xyXG4gIC8qIG1hcmdpbi1yaWdodDogMjBweDsgKi9cclxuICAvKiBtYXJnaW4tbGVmdDogMHB4OyAqL1xyXG59XHJcbi5pbWctZGV0YWlsc3tcclxuICBtYXJnaW4tdG9wOiA1cmVtO1xyXG59XHJcbi5jb250ZW50e1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuLnBEZXNjcmlwdGlvbntcclxuICBtYXJnaW4tbGVmdDogMnJlbTtcclxufVxyXG4ubG9nb3tcclxuICAgIHBhZGRpbmc6IDBweCA1cHg7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuLm5hdmJhcntcclxuICAgIGJhY2tncm91bmQ6ICMzODNhNDg7XHJcbiAgICAvKiB3aWR0aDogMTAwJTsgKi9cclxuICAgIC8qIG1hcmdpbi1sZWZ0OiAwcHggKi9cclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmZsZXh7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgLyogd2lkdGg6IDkwJTsgKi9cclxufVxyXG4vKiBwe1xyXG4gICAgZm9udC1zaXplOiAzNXB4O1xyXG59ICovXHJcbi5pbWFnZXtcclxuICAgIG1hcmdpbi10b3A6IDFyZW07XHJcbiAgICBtYXJnaW4tbGVmdDogMXJlbTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAvKiBtYXgtaGVpZ2h0OiA4MHB4OyAqL1xyXG59XHJcbi5jYXJkaXtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG5tYXQtY2FyZHtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2IoMjQ4LCAyNDIsIDI0Mik7XHJcblxyXG59XHJcblxyXG5cclxuLnNpbWlsYXItY2FyZHtcclxuICAgIG1hcmdpbi1sZWZ0OiAxcmVtO1xyXG59XHJcbi5zZWxsZXIgc3BhbntcclxuICBtYXJnaW4tbGVmdDogMjVweDtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgLyogcGFkZGluZy1ib3R0b206IDMwcHg7ICovXHJcbn1cclxuXHJcbi5zZWxsZXJFbWFpbHtcclxuICAgIG9wYWNpdHk6IDAuNztcclxuICAgIC8qIHBhZGRpbmctbGVmdDogMjBweDsgKi9cclxufVxyXG4uYWRkcmVzc3tcclxuICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbi5hY2NvdW50X2NpcmNsZXtcclxuICAgIGZvbnQtc2l6ZTp4eC1sYXJnZTtcclxuICAgICAvKiB3aWR0aDogMTBweDtcclxuICAgIGhlaWdodDogMTBweDsgKi9cclxufVxyXG5cclxuLmNvbnRhY3Qtc2VsbGVyLWJ1dHRvbntcclxuICAgIC8qIGJhY2tncm91bmQ6ICMzODNhNDg7ICovXHJcbiAgICBjb2xvcjogcmdiKDE5MywgMjMyLCA4NSk7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWQ1NTM3O1xyXG59XHJcbi5idXR0b24ye1xyXG4gIGJhY2tncm91bmQ6ICMzODNhNDg7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG4vKiAuc2ltaWxhcntcclxuICBwYWRkaW5nLXRvcDogMXB4O1xyXG59ICovXHJcblxyXG4uc2VsbGljb257XHJcbiAgbWFyZ2luLXJpZ2h0OjFweDtcclxuICB6LWluZGV4OiAxO1xyXG59XHJcblxyXG4uZXhhbXBsZS1jYXJkIHtcclxuICAgIGJvcmRlcjogYmxhY2sgMnB4IHNvbGlkO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIH1cclxuXHJcbiAgICAuaW1ne1xyXG4gICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgICAgIGhlaWdodDoxNTBweDtcclxuICAgICAgICBzaXplOiBhdXRvO1xyXG4gICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAubG9jYXRpb25BbmREYXRle1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzNXB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgXHJcbiAgICAgICN0aXRsZXtcclxuICAgICAgICBoZWlnaHQ6MjBweDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgfVxyXG4gICAgICAuZGl2aWRlcntcclxuICAgICAgICBtYXJnaW4tdG9wOiAyNXB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5sb2NEYXRle1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICAgIH1cclxuICAgICAgLnRleHR7XHJcbiAgICAgICAgcGFkZGluZy10b3A6MzBweDtcclxuICAgICAgfVxyXG4gICAgICAvKiAuY29ue1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjIwcHg7XHJcbiAgICAgICAgcGFkZGluZzozMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9ICovXHJcbiAgICAgIFxyXG4gICAgICAuaWNvbntcclxuICAgICAgICBoZWlnaHQ6MjBweDtcclxuICAgICAgICBkaXNwbGF5OmlubGluZS1ibG9jaztcclxuICAgICAgICBmb250LXNpemU6IDQzcHg7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgLnBhZ2luYXRvcntcclxuICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICB9XHJcbiAgICAgIC5wcm9maWxle1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyNXB4O1xyXG4gICAgICB9XHJcbiAgICAgIC50YWIgdHIgdGR7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4O1xyXG4gICAgICAgIC8qIGJvcmRlcjogMC40cHggc29saWQgIzM4M2E0ODsgKi9cclxuICAgICAgICAvKiBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlOyAqL1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTUwJTtcclxuICAgIH1cclxuICAgIC5uYW1le1xyXG4gICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgIH1cclxuICAgIC5uYXAgcHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIH1cclxuICAgIC5EaXZpZGVye1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAvKiBmb250LXNpemU6IDE1cHg7ICovXHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5zaW1pbGFyIGgye1xyXG4gICAgICBtYXJnaW4tbGVmdDogNDVweDtcclxuICAgIH1cclxuICAgIC5zZWxsY3tcclxuICAgICAgcmlnaHQ6IDZweDtcclxuICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgXHJcblxyXG4vKiAudy0xMDB7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBoZWlnaHQ6IDgwJTtcclxufSAqLyJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProductDetailsComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: "app-product-details",
            templateUrl: "./product-details.component.html",
            styleUrls: ["./product-details.component.css"]
          }]
        }], function () {
          return [{
            type: _service_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]
          }, {
            type: _service_recommendation_recommendation_service_service__WEBPACK_IMPORTED_MODULE_2__["RecommendationServiceService"]
          }, {
            type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"]
          }];
        }, null);
      })();
      /***/

    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.error(err);
      });
      /***/

    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map