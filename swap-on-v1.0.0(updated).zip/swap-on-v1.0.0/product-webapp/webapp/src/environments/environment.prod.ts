export const environment = {
  
  // apiUrl: 'http://localhost:9000',
  production: true,
  local:'production',
  apiBaseUrl: 'http://13.235.163.216:8080',

};


