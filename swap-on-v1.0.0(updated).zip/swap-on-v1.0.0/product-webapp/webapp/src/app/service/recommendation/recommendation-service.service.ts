import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RecommendationServiceService {

  constructor(private httpClient: HttpClient) { }

  getAllProduct(){
    return this.httpClient.get('http://localhost:8085/api/v1/productByCategory/'+localStorage.getItem("category"));
  }

}
