import { getMultipleValuesInSingleSelectionError } from '@angular/cdk/collections';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ChatMessage } from 'src/app/model/chat/chat-message.model';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  constructor(private http: HttpClient) { }

  apiBaseurl = "https://swapon.stackroute.io/chat-service/chats/"

  // apiBaseurl = "http://localhost:8084/chats/"

  getChatApi(productId:string, sellerEmail:string) {
    return this.http.get(this.apiBaseurl + 'message/' + productId + "/" + sellerEmail);
  }

  
  getBuyers(sellerEmail:string) {
    return this.http.get(this.apiBaseurl + 'seller/' + sellerEmail);
  }


  getProductsOfBuyer(buyerEmail:string) {
    return this.http.get(this.apiBaseurl + "buyer/" + buyerEmail);
  }

  getSpecificChat(buyerEmail:string,productId:string)
  {
    console.log("sending http request to back-end with URL "+this.apiBaseurl+buyerEmail+'/'+productId)
    return this.http.get(this.apiBaseurl+buyerEmail+'/'+productId);
  }
  sendMessage(chatMessage:ChatMessage) {
    return this.http.post(this.apiBaseurl+"message", chatMessage);
  }

  videoApi(){
    return this.http.get<any>(
      "http://127.0.0.1:62719/video-chat.component.html"
    );
  }


  // getspecificchat(buyerEmail,productId)
  // {
  //   return this.http.get(this.apiBaseurl+buyerEmail+'/'+productId)
  // }

  // createNewBuyer(){
  //   return this.http.post(this.apiBaseurl+'message')
  // }

  // updateChats(){
  //   return this.http.post(this.apiBaseurl+'reply')
  // }

  // getAllUsers(productId){
  //   return this.http.get(this.apiBaseurl+'/'+productId)
  // }
  // newBuyer()
  // {
  //   return this.http.post(this.apiBaseurl+'/message');
  // }

  // updateChat()
  // {
  //   return this.http.post(this.apiBaseurl+'/reply');
  // 
  

}
