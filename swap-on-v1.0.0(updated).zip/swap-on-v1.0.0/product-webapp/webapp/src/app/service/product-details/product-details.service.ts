import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { pid } from 'process';
// import { Observable } from 'rxjs';
// import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailsService {

  constructor(private httpClient: HttpClient) { }
   
  //  getProductDetailsById(productId:any){
  //  return this.httpClient.get<Product>(this.url +"/productservice/api/v1/product/" + productId)
  // }
  // getProductDetailsByEmail(pemail:any){
  //   return this.httpClient.get<Product[]>(this.url+ "/productservice/api/v1/productavailablebyemail/" + pemail)
  //  }
// updateProductNotAvailable(productId:any){
//   return this.httpClient.put( this.url+ "/productservice/api/v1/products/"+`${productId}`,productId);
// }

getDetail(){
  return this.httpClient.get('http://localhost:8085/api/v1/product/productId/'+localStorage.getItem("productId"));
}



}