
// export class Product {
    // public productId:string;
    //  productName:string;
    //  productPrice:Number;
    //  productCondition:string;
    //  additionalDetails:string;
    //  productDescription:string;
    //  sellerName:string;
    //  pincode:string;
    //  sellerEmail:string;
    //  sellerState:string;
    //  brand:String;
    //  color:string;
    //  yearsOfUse:string;
    //  warranty:string;
    //  productDefects:string;
    //  pstatus:any;
    //  image:any;
    //  purchaseDate:Date;



//      constructor(){


//     }
    
// }
