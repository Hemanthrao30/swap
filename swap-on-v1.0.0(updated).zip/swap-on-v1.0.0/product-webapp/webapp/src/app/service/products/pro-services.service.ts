import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from 'src/app/model/login/user';
import { UserRegistration } from '../register/user-registration';
@Injectable({
  providedIn: 'root'
})
export class ProServicesService {
  getByEmailApi(emailId: any) {
    throw new Error("Method not implemented.");
  }

  constructor(private http :HttpClient) { }

  baseUrl :"https://swapon.stackroute.io/"

  registerApi(regData: UserRegistration) {
    return this.http.post<any>(
      "http://localhost:8080/authentication-service/api/v1/register",
      regData
    );
  }

  loginApi(loginData: User) {
    return this.http.post<any>(
      "http://localhost:8080/authentication-service/api/v1/login",
      loginData
    );
  }

  postProduct(data) {
    return this.http.post(
      "http://localhost:8080/product-service/api/v1/addproduct",
      data
    );
  }

  getproducts() {
    return this.http.get<any>(
      "http://localhost:8080/product-service/api/v1/product"
    );
  }

  getDetail() {
    return this.http.get(
      "http://localhost:8080/product-service/api/v1/product/productId/" +
        localStorage.getItem("productId")
    );
  }

  getMyProducts() {
    return this.http.get<any>(
      "http://localhost:8080/product-service/api/v1/product/sellerEmail/" +
        localStorage.getItem("buyerEmail")
    );
  }

  deleteMyProduct(productId: any) {
    return this.http.delete<any>(
      "http://localhost:8080/product-service/api/v1/delete/" + productId
    );
  }
  

  getAllProduct() {
    return this.http.get(
      
      this.baseUrl+"recommendation-service/api/v1/productByCategory/" +
        localStorage.getItem("catagory")
    );
  }
  getByCategory(category){
     return this.http.get(this.baseUrl+"api/v1/productByCategory/"+category)
  }

  getByState(sellerState){
    return this.http.get(this.baseUrl+"api/v1/productByCategory/"+sellerState)
 }
  getbyEmailApi(emailId){
     return this.http.get(this.baseUrl+"api/v1/product/sellerEmail/"+emailId)
  }
  // url :string = "http://localhost:8085/api/v1/product";
  // getproducts(){
  //   return this.http.get<any>(this.url);
  // }

  // url3 :string = "http://localhost:8085/api/v1/product/sellerEmail/"+localStorage.getItem("loginEmail");
  // getMyProducts(){
  //   return this.http.get<any>(this.url3);
  // }

  // url2 :string = "http://localhost:8085/api/v1/addproduct";
  // postProduct(data){
  //   return this.http.post(this.url2,data);
  // }
  
  // url4:string ="http://localhost:8086/api/v1/productByStateAndCategory/"
  // getByFilter(){
  //    return this.http.get<any>(this.url4+localStorage.getItem('sellerState')+"/"+localStorage.getItem('category'));
  // }
  
  // deleteMyProduct(productId : any){
  //   return this.http.delete<any>("http://localhost:8085/api/v1/delete/"+productId);
  // }
  

}
