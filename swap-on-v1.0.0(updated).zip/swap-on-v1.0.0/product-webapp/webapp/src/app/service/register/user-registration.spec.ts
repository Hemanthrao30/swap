import { UserRegistration } from './user-registration';

describe('UserRegistration', () => {
  it('should create an instance', () => {
    expect(new UserRegistration()).toBeTruthy();
  });
});
