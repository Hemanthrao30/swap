export class UserRegistration {

  firstname: String;
    email: String;
    contactNo: String;
    password: String;
    cpassword: String;
    street: String;
    city: String;
    state: String;
    pincode: string;
    image: any;
   
  
    constructor() {
      
      
    }
  }
  