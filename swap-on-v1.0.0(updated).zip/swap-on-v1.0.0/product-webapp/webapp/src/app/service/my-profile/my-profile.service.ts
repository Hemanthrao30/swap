import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { UserRegistration } from "../register/user-registration";

@Injectable({
  providedIn: "root",
})
export class MyProfileService {
  constructor(private httpClient: HttpClient) {}

  userProfile() {
    return this.httpClient.get(
      "https://swapon.stackroute.io/authentication-service/api/v1/byEmail/" +
        localStorage.getItem("buyerEmail")
    );
  }

  updateProfile(regData: UserRegistration) {
    return this.httpClient.put<any>(
      "https://swapon.stackroute.io/authentication-service/api/v1/update/" +
        localStorage.getItem("buyerEmail"),
      regData
    );
  }
}
