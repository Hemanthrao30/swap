import { Message } from "./message.model";

export class BuyersChat {
    buyersEmailId: string;
    message: Message[];
}
