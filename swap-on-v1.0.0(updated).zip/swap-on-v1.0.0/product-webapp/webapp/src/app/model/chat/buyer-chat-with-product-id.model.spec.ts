import { BuyerChatWithProductId } from './buyer-chat-with-product-id.model';

describe('BuyerChatWithProductId', () => {
  it('should create an instance', () => {
    expect(new BuyerChatWithProductId()).toBeTruthy();
  });
});
