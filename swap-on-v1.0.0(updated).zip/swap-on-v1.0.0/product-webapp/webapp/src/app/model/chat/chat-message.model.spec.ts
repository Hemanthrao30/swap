import { ChatMessage } from './chat-message.model';

describe('ChatMessage', () => {
  it('should create an instance', () => {
    expect(new ChatMessage()).toBeTruthy();
  });
});
