import { BuyersChat } from "./buyers-chat.model";

export class ChatMessage {
    productId: string;
    sellerEmail: string;
    buyersChat: BuyersChat[];
}
