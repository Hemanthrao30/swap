export class Message {
    message: string;
    messageSendBy: string;
    messageSendOn: number
}
