import { BuyersChat } from './buyers-chat.model';

describe('BuyersChat', () => {
  it('should create an instance', () => {
    expect(new BuyersChat()).toBeTruthy();
  });
});
