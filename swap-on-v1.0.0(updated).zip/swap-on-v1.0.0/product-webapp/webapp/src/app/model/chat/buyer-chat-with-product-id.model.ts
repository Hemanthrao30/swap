import { BuyersChat } from "./buyers-chat.model";

export class BuyerChatWithProductId {
    productId: string;
    buyersChat: BuyersChat;
}
