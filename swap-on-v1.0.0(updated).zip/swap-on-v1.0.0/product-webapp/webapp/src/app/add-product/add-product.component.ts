import { Component, OnInit, Output } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { DialogExampleComponent } from "./dialog-example/dialog-example.component";
import { HttpClient } from "@angular/common/http";
import { AddProductService } from "../service/add-product.service";
import { MyProfileService } from "../service/my-profile/my-profile.service";
import { AppService } from "../service/app.service";
import Swal from "sweetalert2";


@Component({
  selector: "app-add-product",
  templateUrl: "./add-product.component.html",
  styleUrls: ["./add-product.component.css"],
})
export class AddProductComponent implements OnInit {
  constructor(
    private myProfile: MyProfileService,
    private _formBuilder: FormBuilder,
    private http: HttpClient,
    private productService: AppService
  ) {}

  today= new Date();
  url: any = "";
  selectedFile: any;
  allProducts: any = [];
  productsList: any = [];
  product: any;
  proImage: any;
  productTosend: any;

  profile:any;

  myProfileDetails(){
    this.myProfile.userProfile().subscribe((response)=>{
      console.log("This is logged in User Details", response);
      
      this.details = response;
      console.log(this.details);

    this.sellerDetails.patchValue({
      sellerEmail: this.details.email,
      sellerMobile: this.details.contactNo,
      sellerName:this.details.firstname
    });
    })}

  isEditable = true;

  ngOnInit(): void {
    this.myProfileDetails();
  }

  addProduct = new FormGroup({
    productName: new FormControl(null, Validators.required),
    productPrice: new FormControl(null, Validators.required),
    productBrand: new FormControl(null, Validators.required),
    purchaseDate: new FormControl(""),
    category: new FormControl(null, Validators.required),
  });

  get productName() {
    return this.addProduct.controls["productName"];
  }
  get productPrice() {
    return this.addProduct.controls["productPrice"];
  }
  get productBrand() {
    return this.addProduct.controls["productBrand"];
  }
  get purchaseDate() {
    return this.addProduct.controls["productDate"];
  }
  get category() {
    return this.addProduct.controls["category"];
  }

  addProductDescription = new FormGroup({
    productCondition: new FormControl(null, Validators.required),
    productDetails: new FormControl(""),
    productDesc: new FormControl(null, [
      Validators.required,
      Validators.maxLength(700),
    ]),
    file: new FormControl(""),
  });

  get productCondition() {
    return this.addProductDescription.controls["productCondition"];
  }
  get productDetails() {
    return this.addProductDescription.controls["productDetails"];
  }
  get productDesc() {
    return this.addProductDescription.controls["productDesc"];
  }
  get file() {
    return this.addProductDescription.controls["file"];
  }

  sellerDetails = new FormGroup({
    sellerName: new FormControl({disabled:true}, Validators.required),
    sellerPincode: new FormControl(null, Validators.required),
    sellerState: new FormControl(null, Validators.required),
    sellerEmail: new FormControl({disabled:true}, [Validators.required, Validators.email]),
    sellerMobile: new FormControl({disabled:true}, [
      Validators.required,
    ]),
    city: new FormControl(null, Validators.required),
  });

  get sellerName() {
    return this.sellerDetails.controls["sellerName"];
  }
  get sellerPincode() {
    return this.sellerDetails.controls["sellerPincode"];
  }
  get sellerState() {
    return this.sellerDetails.controls["sellerState"];
  }
  get sellerEmail() {
    return this.sellerDetails.controls["sellerEmail"];
  }
  get sellerMobile() {
    return this.sellerDetails.controls["sellerMobile"];
  }
  get city() {
    return this.sellerDetails.controls["city"];
  }

  myFile(data: any) {
    this.selectedFile = data.target.files[0];
  }
  saveData() {
    console.log(this.addProduct.value);
    console.log(this.addProductDescription.value);
    console.log(this.sellerDetails.value);
  }

  postProducts() {
    this.product = {
      productName: this.addProduct.value.productName,
      productPrice: this.addProduct.value.productPrice,
      purchaseDate: this.addProduct.value.purchaseDate,
      productCondition: this.addProductDescription.value.productCondition,
      additionalDetails: this.addProductDescription.value.productDetails,
      productDescription: this.addProductDescription.value.productDesc,
      sellerName: this.sellerDetails.value.sellerName,
      pincode: this.sellerDetails.value.sellerPincode,
      sellerEmail: this.sellerDetails.value.sellerEmail,
      sellerState: this.sellerDetails.value.sellerState,
      sellerMobile:this.sellerDetails.value.sellerMobile,
      brand: this.addProduct.value.productBrand,
      category: this.addProduct.value.category,
      city: this.sellerDetails.value.city,
    };

    this.productsList.push(this.product);
    this.proImage = {
      file: this.selectedFile,
    };
    this.productsList.push(this.proImage);
  }

  postImage() {}
  OnSubmit() {
    this.postProducts();
    var formData = new FormData();
    formData.append("image", this.selectedFile);
    formData.append("Product", JSON.stringify(this.product));
    this.productService.postProduct(formData).subscribe((a) => {
      Swal.fire("Successfully done !!", "Product is Added ", "success");
      console.log(a);
      location.reload();
    });
    
  }
  details:any;
  getUserDetails(email){
    this.myProfile.updateProfile(email).subscribe((response)=>{
      console.log("This is user",response);
      console.log(response[0].name);
      this.details = response;
      this.sellerDetails.patchValue({
        email: this.details[0].email,
        firstname: this.details[0].firstname,
        contactNo: this.details[0].contactNo
        
      });
  
    });

  }
}
