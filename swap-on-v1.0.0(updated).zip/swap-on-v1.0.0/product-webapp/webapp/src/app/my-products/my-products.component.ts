import { Component, OnInit } from "@angular/core";
import { PageEvent } from "@angular/material/paginator";
import { AppService } from "../service/app.service";

@Component({
  selector: "app-my-products",
  templateUrl: "./my-products.component.html",
  styleUrls: ["./my-products.component.css"],
})
export class MyProductsComponent implements OnInit {
  constructor(private rs: AppService) {}

  product: any = [];
  response: any;

  pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;

  ngOnInit(): void {

  
    this.rs.getMyProducts().subscribe(
      (response: any) => {
        console.log(response);

        let size = response.length;
        for (var i = 0; i < size; i++) {
          // console.log(response.productId[i])

          this.product.push(response[i]);

          this.product[i].image =
            "data:image/jpeg;base64," + this.product[i].image;
          console.log(this.product[0].productId);
          localStorage.setItem("productId", this.product[0].productId);
        }

        //  for(var i=0;i<this.product.length;i++)
        //   {
        //     this.product[i].image = 'data:image/jpeg;base64,' + this.product[i].image;

        //   }
        console.log(this.product);
      },
      (error) => {
        console.log("Error Occured" + error);
      }
    );
  }

  saveData(data: any) {
    localStorage.setItem("productId", data.productId);
    localStorage.setItem("productCategory", data.productCategory);
    localStorage.setItem("productCity", data.city);
  }

  showIcon: boolean = true;
  changeIcon() {
    this.showIcon = !this.showIcon;
  }
  
  ngOnChanges(){
    window.location.reload();
    }

  lowValue: number = 0;
  highValue: number = 10;

  // used to build a slice of papers relevant at any given time
  public getPaginatorData(event: PageEvent): PageEvent {
    this.lowValue = event.pageIndex * event.pageSize;
    this.highValue = this.lowValue + event.pageSize;
    return event;
  }

  deleteItem(items: any) {
    console.log(items);
    this.rs.deleteMyProduct(items).subscribe((resp: any) => console.log(resp));
    console.log("product Deleted seccessfully");
    location.reload();
  }
}
