import { Component, OnInit } from "@angular/core";
import { MyProfileService} from "../service/my-profile/my-profile.service";
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { UserRegistration } from "../service/register/user-registration";

@Component({
  selector: "app-my-profile",
  templateUrl: "./my-profile.component.html",
  styleUrls: ["./my-profile.component.css"],
})
export class MyProfileComponent implements OnInit {

  search : String ="";
menu: any;
  // dom: any;

  details:any;
  reg:UserRegistration = new UserRegistration();
  profileForm: any;
  

  constructor(private myProfile:MyProfileService,private formBuilder: FormBuilder,private dom:DomSanitizer) {}

  profile:any;

  myProfileDetails(){
    this.myProfile.userProfile().subscribe((response)=>{
      console.log("This is logged in User Details", response);
      
      this.details = response;
      console.log(this.details);

    this.profileFormGroup.patchValue({
      email: this.details.email,
      firstname: this.details.firstname,
      contactNo: this.details.contactNo,
      street: this.details.street,
      city: this.details.city,
      state: this.details.state,
      pincode: this.details.pincode,
    });
      // this.profile.image=this.dom.bypassSecurityTrustResourceUrl('data:image/jepg;base64,'+this.profile.image);
    })}




profileFormGroup=new FormGroup({
  image: new FormControl(""),
  firstname: new FormControl(""),
  contactNo: new FormControl(""),
  email: new FormControl(""),
  street: new FormControl(""),
  city: new FormControl(""),
  state: new FormControl(""),
  pincode: new FormControl(""),
});

onProfile(): void{
  console.log(this.profileFormGroup.value);
  console.log(this.profileFormGroup.value.email);

  this.profileForm=this.profileFormGroup.value;

  this.reg.firstname=this.profileFormGroup.value.firstname;
  this.reg.contactNo=this.profileFormGroup.value.contactNo;
  this.reg.email=this.profileFormGroup.value.email;
  this.reg.street=this.profileFormGroup.value.street;
  this.reg.city=this.profileFormGroup.value.city;
  this.reg.state=this.profileFormGroup.value.state;
  this.reg.pincode=this.profileFormGroup.value.pincode;

  console.log(this.reg.email);

  this.myProfile.updateProfile(this.reg).subscribe((response)=>{
    console.log(response);
  })
}


ngOnInit(): void {
  this.myProfileDetails();
}

ngOnChanges(){
  window.location.reload();
  }


getUserDetails(email){
  this.myProfile.updateProfile(email).subscribe((response)=>{
    console.log("This is user",response);
    console.log(response[0].name);
    this.details = response;
    this.profileFormGroup.patchValue({
      email: this.details[0].email,
      firstname: this.details[0].firstname,
      contactNo: this.details[0].contactNo,
      street: this.details[0].street,
      city: this.details[0].city,
      state: this.details[0].state,
      pincode: this.details[0].pincode,
    });

  });
}



}