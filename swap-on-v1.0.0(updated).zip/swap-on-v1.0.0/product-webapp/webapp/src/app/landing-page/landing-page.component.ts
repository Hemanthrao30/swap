import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

interface Language {
  value: string;
  viewValue: string;
}




@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

 

  control=new FormControl('')

  constructor() { }

  ngOnInit(): void {
  }

  languages: Language[]=[
    {value: 'HINDI-1', viewValue: 'HINDI'},
    {value: 'ENGLISH-0', viewValue:'ENGLISH'},
    {value: 'HINDI-1', viewValue: 'HINDI'},
  ];

  color="accent";
  color1="accent";
  color2="accent"

  scrollToTop() {
    window.scroll({
      top: 0, 
      left: 0, 
      behavior: 'smooth' 
    });
  }
  scrollToDown() {
    window.scroll({
      top: 5000, 
      left: 0, 
      behavior: 'smooth' 
    });
  }
  scrollToBottom() {
    window.scroll({
      top: 1650, 
      left: 0, 
      behavior: 'smooth' 
    });
  }

}

