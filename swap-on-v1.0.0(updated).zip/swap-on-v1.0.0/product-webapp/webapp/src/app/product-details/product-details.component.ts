import { Component, OnInit } from "@angular/core";
import { PageEvent } from "@angular/material/paginator";
import { DomSanitizer } from "@angular/platform-browser";
import { element } from "protractor";
import { AppService } from "../service/app.service";
import { ProductDetailsService } from "../service/product-details/product-details.service";
import { RecommendationServiceService } from "../service/recommendation/recommendation-service.service";

@Component({
  selector: "app-product-details",
  templateUrl: "./product-details.component.html",
  styleUrls: ["./product-details.component.css"],
})
export class ProductDetailsComponent implements OnInit {
  allProducts: any = [];
  pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;

  constructor(
    private productdetailsService: AppService,
    private recommendationService: RecommendationServiceService,
    private dom: DomSanitizer
  ) {}
  product: any;
  getProductDetails() {
    this.productdetailsService.getDetail().subscribe((response) => {
      console.log(response);
      this.product = response;
      console.log("product", this.product);
      this.product.image = this.dom.bypassSecurityTrustResourceUrl(
        "data:image/jepg;base64," + this.product.image
      );
    });
  }

  getAllProductDetails() {
    this.productdetailsService.getByProductCategory().subscribe((response: any) => {
      console.log(response);

      let size=response.length;

      for (var i=0;i<size;i++) {
        this.allProducts.push(response[i])
            this.allProducts[i].image = 'data:image/jpeg;base64,' + this.allProducts[i].image;
              
          }



          

      // response.forEach((element: any) => {
      //   this.allProducts.push(element);

      //   for (var i = 0; i < this.allProducts.length; i++) {
      //     this.allProducts[i].image =
      //       'data:image/jpeg;base64,' + this.allProducts[i].image;
      //   }
      // });

      // this.allProducts=response;
      // console.log(this.allProducts);
      // this.allProducts.image=this.dom.bypassSecurityTrustResourceUrl('data:image/jepg;base64,'+this.allProducts.image);
    });
  }

  ngOnInit(): void {
    this.getProductDetails();
    this.getAllProductDetails();
  }
  lowValue: number = 0;
  highValue: number = 4;

  // used to build a slice of papers relevant at any given time
  public getPaginatorData(event: PageEvent): PageEvent {
    this.lowValue = event.pageIndex * event.pageSize;
    this.highValue = this.lowValue + event.pageSize;
    return event;
  }

  saveData(data: any) {
    localStorage.setItem("sellerEmail", data.sellerEmail);
    localStorage.setItem("productId", data.productId);
    localStorage.setItem("category", data.category);
  }

  contactSeller() {
    localStorage.setItem("PRODUCT_ID_FOR_BUYER_UI",this.product.productId);
    localStorage.setItem("SELLER_EMAIL_FOR_BUYER_CHAT_UI",this.product.sellerEmail);
    localStorage.setItem("ROLE","Buyer");
  }

}
