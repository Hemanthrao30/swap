import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-bot',
  templateUrl: './chat-bot.component.html',
  styleUrls: ['./chat-bot.component.css']
})
export class ChatBotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  showChat=true;

  showChatOption(){
    this.showChat = !this.showChat;
  }

}

