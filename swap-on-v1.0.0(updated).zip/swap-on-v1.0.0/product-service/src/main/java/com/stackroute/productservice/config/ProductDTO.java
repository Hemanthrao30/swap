package com.stackroute.productservice.config;

public class ProductDTO {
}
