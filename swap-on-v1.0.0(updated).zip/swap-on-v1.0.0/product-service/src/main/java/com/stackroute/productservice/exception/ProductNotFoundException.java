package com.stackroute.productservice.exception;

public class ProductNotFoundException extends Exception {
}
