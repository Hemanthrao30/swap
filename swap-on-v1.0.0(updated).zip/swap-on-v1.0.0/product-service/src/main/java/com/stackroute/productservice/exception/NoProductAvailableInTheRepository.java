package com.stackroute.productservice.exception;

public class NoProductAvailableInTheRepository extends Exception{
}
