package com.stackroute.productservice.exception;

public class NoProductExistsInTheRepository extends Exception{

}
