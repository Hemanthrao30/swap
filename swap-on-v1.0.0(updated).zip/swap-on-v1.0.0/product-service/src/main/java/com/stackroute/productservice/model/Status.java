package com.stackroute.productservice.model;

public enum Status {
       AVAILABLE,
     NOTAVAILABLE

}
