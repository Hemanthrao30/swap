package com.stackroute.productservice.exception;

public class ProductAlreadyExistException extends Exception{

}
