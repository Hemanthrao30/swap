package com.stackroute.productservice.exception;

public class ProvideProperProductDetails extends Exception{
}
