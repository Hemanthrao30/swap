package com.stackroute.productservice.controller;

import com.stackroute.productservice.service.ProductServiceImpl;

public class ProductControllerTest {
    private ProductServiceImpl pservice;
    private ProductController controller;


}
