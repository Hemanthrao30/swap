package com.stackroute.productservice.service;

import com.stackroute.productservice.Repository.ProductRepository;
import com.stackroute.productservice.exception.ProductNotFoundException;
import com.stackroute.productservice.model.Product;
import org.junit.jupiter.api.Test;

public class ProductServiceImplTest {
    ProductRepository productRepository;
    ProductServiceImpl productService;

    @Test
    public void ProductIdShouldReturnProduct() throws ProductNotFoundException{
//        Product prod = new Product("101" ,"laptop" , 1000.00,"","",);
//        Optional<Product>

    }




}
