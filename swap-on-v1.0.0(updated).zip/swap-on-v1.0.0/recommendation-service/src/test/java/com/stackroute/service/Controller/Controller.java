package com.stackroute.service.Controller;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Controller {
}
