package com.stackroute.Exception;

public class ProductAlreadyExistException extends Exception{
}
