package com.stackroute.Exception;

public class ProductNotFoundException extends Exception {
}
