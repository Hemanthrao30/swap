package com.stackroute.authenticationservice.exception;

public class UserAlreadyExistException extends Exception{

}