package com.stackroute.authenticationservice.service;
import com.stackroute.authenticationservice.domain.User;
import com.stackroute.authenticationservice.exception.UserAlreadyExistException;
import com.stackroute.authenticationservice.exception.UserNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public interface UserService {

    public User saveUser(User user) throws UserAlreadyExistException;

    public User login (User user) throws UserNotFoundException;
    public User loadUserByUsername(String username) throws UserNotFoundException;

    public List<User> allUsers();

    public String deleteUserById(String username) throws UserNotFoundException;

    public User update(User user) ;

//    public User uploadImg(String email, MultipartFile file) throws UserNotFoundException;

}
